package io.socket;



import org.json.JSONObject;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.hupu.games.handler.ISocketCallBack;

public class SocketIoHandler implements IOCallback{
	private Handler handler;
	private static final int SUCCESS_MESSAGE = 0;
	private static final int FAILURE_MESSAGE = 1;
	private static final int CONNECT_MESSAGE = 2;
	private static final int DISCONNECT_MESSAGE = 3;

	public SocketIoHandler(ISocketCallBack call) {
		callBack = call;
		if (Looper.myLooper() != null) {
			handler = new Handler() {
				public void handleMessage(Message msg) {
					SocketIoHandler.this.handleMessage(msg);
				}
			};
		}
	}

	private ISocketCallBack callBack;

	protected void handleMessage(Message msg) {
		if (callBack == null)
			return;
		switch (msg.what) {
		case SUCCESS_MESSAGE:
			callBack.onSocketResp((JSONObject) msg.obj);
			break;
		case FAILURE_MESSAGE:
			callBack.onSocketError((SocketIOException)msg.obj);
			break;
		case CONNECT_MESSAGE:
			callBack.onSocketConnect();
			break;
		case DISCONNECT_MESSAGE:
			callBack.onSocketDisconnect();
			break;
		}
	}

	protected Message obtainMessage(int responseMessage, Object response) {
		Message msg = null;
		if (handler != null) {
			msg = this.handler.obtainMessage(responseMessage, response);
		} else {
			msg = new Message();
			msg.what = responseMessage;
			msg.obj = response;
		}
		return msg;
	}

	protected void sendMessage(Message msg) {
		if (handler != null) {
			handler.sendMessage(msg);
		} else {
			handleMessage(msg);
		}
	}

	@Override
	public void onDisconnect() {
//		Log.i("SocketIoHandler", " onDisconnect  >>>>>>:::::");
		sendMessage(obtainMessage(DISCONNECT_MESSAGE, null));
	}

	@Override
	public void onConnect() {
//		Log.i("SocketIoHandler", "on onConnect  >>>>>>:::::");
		sendMessage(obtainMessage(CONNECT_MESSAGE, null));
	}

	@Override
	public void onMessage(String data, IOAcknowledge ack) {
//		Log.d("SocketIoHandler", "onMessage   >>>>>>:::::"+data);
	}

	@Override
	public void onMessage(JSONObject json, IOAcknowledge ack) {
//		Log.d("SocketIoHandler", "onMessage json   >>>>>>:::::"+json.toString());
	}

	@Override
	public void on(String event, IOAcknowledge ack, Object... args) {
//		Log.d("SocketIoHandler", "event   >>>>>>:::::"+event);
		if (args != null && args.length > 0)
			sendMessage(obtainMessage(SUCCESS_MESSAGE, (JSONObject) args[0]));
	}

	@Override
	public void onError(SocketIOException socketIOException) {
		Log.e("SocketIoHandler", "on err  >>>>>>:::::"+socketIOException.toString());
		sendMessage(obtainMessage(FAILURE_MESSAGE, socketIOException));
	}

}
