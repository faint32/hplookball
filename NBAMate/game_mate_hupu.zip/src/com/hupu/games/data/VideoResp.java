package com.hupu.games.data;

import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;

public class VideoResp extends BaseEntity {

	public LinkedList<VideoEntity> mList;
	public int nextDataExists;

	public long lastVId;
	@Override
	public void paser(JSONObject json) throws Exception {
		json =json.optJSONObject("result");
		JSONArray array = json.optJSONArray("data");
		if (array != null) {
			int size = array.length();
			mList = new LinkedList<VideoEntity>();
			VideoEntity temp;
			for (int i = 0; i < size; i++) {
				temp = new VideoEntity();
				temp.paser(array.getJSONObject(i));
				mList.add(temp);
				if(i==size -1)
					lastVId =temp.vid;
			}
		}
		nextDataExists =json.optInt("nextDataExists"   );
		
	}
}
