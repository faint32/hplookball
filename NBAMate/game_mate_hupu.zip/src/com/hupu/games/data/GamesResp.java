package com.hupu.games.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;

import com.hupu.games.common.HuPuRes;
import com.pyj.common.MyUtility;

public class GamesResp extends BaseEntity {

	public GamesResp(int t) {
		i_type = t;
	}

	/**
	 * Ϊ0ʱ�Ǹ���id��ȡ���������� Ϊ1ʱ�Ǹ������ڻ�ȡ�б��� 2 �ɷ�������ȡ����ı���������ȡǰ������� 3
	 * ����ָ�����ڻ�ȡ�����б�������ȡǰ������ 4 ����ָ�����ڻ�ȡ�����б�������ȡ������� 5ʵʱ�ӿ�
	 * */
	int i_type;
	public GameEntity gameEntity;

	public LinkedList<GameEntity> mGameList;

	public LinkedList<Integer> mGameIdList;
	/** ���������ʱ��� */
	public long l_game_day;
	public long l_server_day;
	public ArrayList<Long> preList;
	// ArrayList<String> preStrList;
	public ArrayList<Long> nextList;
	// ArrayList<String>nextStrList;

	public boolean isMatchDay;

	public String[] redirectors;
	
	@Override
	public void paser(JSONObject obj) throws Exception {

		if (i_type == HuPuRes.REQ_METHOD_GAMES_BY_GID) {
			gameEntity = new GameEntity();
			gameEntity.paser(obj.getJSONObject(KEY_RESULT));
			l_game_day = gameEntity.l_date_time;
		} else {

			JSONArray arr = null;
			if (i_type == HuPuRes.REQ_METHOD_GAMES_BY_DATE)
				arr = obj.getJSONArray(KEY_RESULT);
			else {
				obj = obj.getJSONObject(KEY_RESULT);
				arr = obj.getJSONArray("this");
				JSONArray servers =obj.optJSONArray("redirector");
				if(servers !=null )
				{
					redirectors =new String[servers.length()];
					for(int i=0;i<redirectors.length;i++)
						redirectors[i]=(String)servers.get(i);
				}
				if (i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER
						|| i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE)
					preList = getTimeList(obj.getJSONArray(KEY_PREV), true);
				if (i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER
						|| i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT)
					nextList = getTimeList(obj.getJSONArray(KEY_NEXT), false);

				// �ɷ��������ص��������
				if (i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER)
					l_server_day = obj.getLong(KEY_TODAY);

			}

			int size = arr.length();
			if (size > 0) {
				mGameList = new LinkedList<GameEntity>();
				mGameIdList = new LinkedList<Integer>();
			}
			for (int i = 0; i < size; i++) {
				gameEntity = new GameEntity();
				gameEntity.paser(arr.getJSONObject(i));
				mGameList.add(gameEntity);
				mGameIdList.add(gameEntity.i_gId);
				if (i == 0) {
					if (i_type == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER)
						isMatchDay = gameEntity.l_date_time == l_server_day;

					l_game_day = gameEntity.l_date_time;
					if (l_game_day == 0)
						l_game_day = MyUtility
								.getZeroTime(gameEntity.l_begin_time);

				}

			}
		}
	}

	private ArrayList<Long> getTimeList(JSONArray arr, boolean bPre)
			throws Exception {
		ArrayList<Long> list = new ArrayList<Long>();
		int size = arr.length();

		for (int i = 0; i < size; i++) {
			if (bPre)
				list.add(0, arr.getLong(i));
			else
				list.add(arr.getLong(i));
		}
		return list;
	}
}
