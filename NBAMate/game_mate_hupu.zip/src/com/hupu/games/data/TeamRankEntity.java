package com.hupu.games.data;

import java.io.Serializable;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class TeamRankEntity extends BaseEntity implements Serializable{

	public int i_tid;    //���ID
	public String str_name;//    �����
	public int i_win;   // ʤ����
	public int i_lost;   //�ܳ���
	public String str_win_rate; //  ʤ��
	public String str_strk;    //����
	public String i_gb;   // ʤ����
	@Override
	public void paser(JSONObject json) throws Exception {
		i_tid=json.optInt(KEY_TEAM_ID);    
		str_name=json.optString(KEY_NAME);    
		i_win=json.optInt("win");   
		i_lost=json.optInt("lost");   
		str_win_rate =json.optString("win_rate");    
		str_strk =json.optString("strk");    
		i_gb =json.optString("gb");   

	}

}
