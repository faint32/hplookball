package com.hupu.games.data;

import java.io.Serializable;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class CBAData extends BaseEntity implements Serializable{
	    public int i_gId;
		public long l_begin_time;
		public int round;
		public int i_home_tid;
		public int i_away_tid;
		public String str_home_name;
		public String str_away_name;
		public int i_home_score;
		public int i_away_score;
		public int byt_status;
		public String date;
		public String str_process;
		
		public final static byte STATUS_START=1;
		public final static byte STATUS_END=2;
		public final static byte STATUS_WAITING=0;
		public final static byte STATUS_CANCEL=3;
	@Override
	public void paser(JSONObject json) throws Exception {


		i_gId =json.optInt(KEY_GAME_ID);
//		System.out.println("gameId="+i_gId );
		l_begin_time=json.optLong(KEY_BEGIN_TIME);
		date=json.optString(KEY_DATE);
		i_home_tid=json.optInt(KEY_HOME_TID);
		str_home_name=json.optString(KEY_HOME_NAME, null);
		i_home_score=json.optInt(KEY_HOME_SCORE);
		i_away_tid=json.optInt(KEY_AWAY_TID);
		str_away_name=json.optString(KEY_AWAY_NAME);
		i_away_score=json.optInt(KEY_AWAY_SCORE);
		str_process  =json.optString(KEY_PROCESS);
		byt_status=(byte)json.optInt(KEY_STATUS);
	}

}
