package com.hupu.games.data;

import java.io.Serializable;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class LiveEntity extends BaseEntity implements Serializable{

//	public int i_pId;
//	public int i_gId;
	public String str_event;
	public int i_section;
	public String i_endTime;
	/**��Ϣ������ 0 all ,1 home,2 away */
	public byte byt_team;
	
	private String str_vs;
	
	public int i_home_score;
	
	public int i_away_score;
	
    /**����������ɫ��RGB16������ɫֵ����������*/
	public int i_color=-1 ;   
	/** ��������*/
	public String str_link;
	/**    ���ݸ���ͼƬ���Ե�ַ*/
	public String str_img_thumb ;
	/**   ���ݸ���ͼƬԭ��ַ*/
	public String str_img  ;
	
	@Override
	public void paser(JSONObject json) throws Exception {

//		 i_pId=json.optInt(KEY_PID);
//		i_gId=json.getInt(KEY_GAME_ID);
		str_event=json.optString(KEY_EVENT);
//		i_section=json.getInt(KEY_SECTION);
		i_endTime=json.optString(KEY_END_TIME);
		byt_team=(byte)json.optInt(KEY_TEAM);
//		str_vs =json.getString(KEY_VS);
//		if(str_vs.length()>2)
//		{
//			String [] ss =str_vs.split("-");
//			i_home_score=Integer.parseInt(ss[0]);
//			i_away_score=Integer.parseInt(ss[1]);
//		}
		String color=json.optString("color",null);
		if(color!=null)
		{
			i_color=Integer.parseInt(color, 16);
			i_color|=0xff000000;
		}
		str_link=json.optString("link",null);
		str_img_thumb=json.optString("img_thumb",null);
		str_img=json.optString("img",null);
	}

}
