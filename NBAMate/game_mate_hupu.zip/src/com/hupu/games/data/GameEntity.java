package com.hupu.games.data;

import java.io.Serializable;

import org.json.JSONObject;
/**
 * ��Ӽ����bean,
 * {"gid":"21994","date_time":"1349625600","begin_time":"1349625600","home_tid":"189",
 * "home_name":" \u7c73\u5170","home_score":"0","away_tid":"1","away_name":"\u51ef\u5c14\u7279\u4eba",
 * "away_score":"0","match_type":"2","process":"","status":"3"
 * */
@SuppressWarnings("serial")
public class GameEntity extends BaseEntity implements Serializable{

	/**
	 * ����id
	 * */
	public int i_gId;

	/**
	 * ��ʼʱ��
	 * */
	public long l_begin_time;
	public long l_date_time;
	/**
	 * �������ID
	 * */
	public int i_home_tid;
	public String str_home_name;
	public int i_home_score;
	/**
	 * �Ͷ����ID
	 * */
	public int i_away_tid;
	public String str_away_name;
	public int i_away_score;
	/**������*/
	public final static String TYPR_REGULAR="REGULAR";
    /**PLAYOFF��������*/
	public final static String TYPR_PLAYOFF="PLAYOFF";
	/**PRESEASON����ǰ��*/
	public final static String TYPR_PRESEASON="PRESEASON";
	public String str_match_type;
	
	public final static byte TYPE_REGULAR=1;
	public final static byte TYPE_PLAYOFF=2;
	public final static byte TYPE_PRESEASON=3;

	/**��������˵��*/
	public String str_process;
	/**״̬*/
	public byte byt_status;

	/**live*/
	public int i_live;
	
	public final static byte STATUS_START=2;
	public final static byte STATUS_END=1;
	public final static byte STATUS_WAITING=3;
	public final static byte STATUS_CANCEL=4;
	
	public int i_isFollow;
	

	@Override
	public void paser(JSONObject json) throws Exception {
		
		i_gId =json.optInt(KEY_GAME_ID);
//		System.out.println("gameId="+i_gId );
		l_begin_time=json.optLong(KEY_BEGIN_TIME);
		l_date_time=json.optLong(KEY_DATE_TIME);
		i_home_tid=json.optInt(KEY_HOME_TID);
		str_home_name=json.optString(KEY_HOME_NAME, null);
		i_home_score=json.optInt(KEY_HOME_SCORE);
		i_away_tid=json.optInt(KEY_AWAY_TID);
		str_away_name=json.optString(KEY_AWAY_NAME);
		i_away_score=json.optInt(KEY_AWAY_SCORE);
		str_match_type=json.optString(KEY_MATCH_TYPE);
		str_process=json.optString(KEY_PROCESS);
		byt_status=(byte)json.optInt(KEY_STATUS);
		i_isFollow =json.optInt(KEY_FOLLOW,0);
		i_live =json.optInt("live",0);
	}
}
