package com.hupu.games.data;
import com.hupu.games.R;

public class TeamValueEntity {

	/** ������� */
	public String str_name;
	public String str_name_en;
	/** ���ID */
	public int i_tid;
	/** �����ɫ */
	public int i_color;
	/** ���ͼ�� */
	public int i_logo;
	public int i_logo_small;
	public static final int[] ICON_RES = { R.drawable.logo1,
			R.drawable.logo2, R.drawable.logo3, R.drawable.logo4,
			R.drawable.logo5, R.drawable.logo6, R.drawable.logo7,
			R.drawable.logo8, R.drawable.logo9, R.drawable.logo10,
			R.drawable.logo11, R.drawable.logo12, R.drawable.logo13,
			R.drawable.logo14, R.drawable.logo15, R.drawable.logo16,
			R.drawable.logo17, R.drawable.logo18, R.drawable.logo19,
			R.drawable.logo20, R.drawable.logo21, R.drawable.logo22,
			R.drawable.logo23, R.drawable.logo24, R.drawable.logo25,
			R.drawable.logo26, R.drawable.logo27, R.drawable.logo28,
			R.drawable.logo29, R.drawable.logo30,
	};
	
	public static final int[] ICON_RES_SMALL = { R.drawable.logo1_60px,
		R.drawable.logo2_60px, R.drawable.logo3_60px, R.drawable.logo4_60px,
		R.drawable.logo5_60px, R.drawable.logo6_60px, R.drawable.logo7_60px,
		R.drawable.logo8_60px, R.drawable.logo9_60px, R.drawable.logo10_60px,
		R.drawable.logo11_60px, R.drawable.logo12_60px, R.drawable.logo13_60px,
		R.drawable.logo14_60px, R.drawable.logo15_60px, R.drawable.logo16_60px,
		R.drawable.logo17_60px, R.drawable.logo18_60px, R.drawable.logo19_60px,
		R.drawable.logo20_60px, R.drawable.logo21_60px, R.drawable.logo22_60px,
		R.drawable.logo23_60px, R.drawable.logo24_60px, R.drawable.logo25_60px,
		R.drawable.logo26_60px, R.drawable.logo27_60px, R.drawable.logo28_60px,
		R.drawable.logo29_60px, R.drawable.logo30,
};
	public static TeamValueEntity getDefault(int tid)
	{
		TeamValueEntity tv=new TeamValueEntity();
		tv.i_tid =tid;
		tv. i_logo=R.drawable.logo0;
		tv. i_color=0xffd7d7d7;
		tv.i_logo_small=R.drawable.logo0_60px;
		return tv;
	}
}
