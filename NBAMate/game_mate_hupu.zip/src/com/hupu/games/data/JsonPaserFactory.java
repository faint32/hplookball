package com.hupu.games.data;

import org.json.JSONObject;

import com.hupu.games.common.HuPuRes;

public class JsonPaserFactory {

	public static BaseEntity paserObj(String s, int type) {

//		if (s != null)
//			System.out.println(s);
		BaseEntity entity = null;
		switch (type) {
		case HuPuRes.REQ_METHOD_GAMES_BY_GID:
		case HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER:
		case HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE:
		case HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT:
		case HuPuRes.REQ_METHOD_GAMES_BY_DATE:
			entity = new GamesResp(type);
			break;
		case HuPuRes.REQ_METHOD_GET_PLAY_LIVE_ASC:
		case HuPuRes.REQ_METHOD_GET_PLAY_LIVE_DESC:
			entity = new LiveResp();
			break;
		case HuPuRes.REQ_METHOD_BOX_SCORE:
			entity = new BoxScoreResp();
			break;
		case HuPuRes.REQ_METHOD_CBA_BOX_SCORE:
			entity = new CBABoxScoreResp();
			break;
		case HuPuRes.REQ_METHOD_GET_RECAP:
			entity = new Recap();
			break;
		case HuPuRes.REQ_METHOD_FOLLOW_GAME:
		case HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL:
			entity = new FollowResp();
			break;
		case HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS:
			entity = new GetFollowTeamsResp();
			break;
		case HuPuRes.REQ_METHOD_FOLLOW_TEAM_CANCEL:
		case HuPuRes.REQ_METHOD_FOLLOW_TEAM:
		case HuPuRes.REQ_METHOD_SET_FOLLOW_TEAMS:
			entity = new FollowResp();
			break;
		case HuPuRes.REQ_METHOD_REDIRECTOR:
			entity = new AdressEntity();
			break;
		case HuPuRes.REQ_METHOD_GET_STANDINGS:
			entity = new StandingsResp();
			break;
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
			
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT:
			entity = new VideoResp();
			break;
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_PRE:
			
		case HuPuRes.REQ_METHOD_GET_CBA_NEWS:
		case HuPuRes.REQ_METHOD_GET_CBA_NEWS_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_NEWS_PRE:
			entity = new NewsResp();
			break;
		
		case HuPuRes.REQ_METHOD_CBA_NEXT:
		case HuPuRes.REQ_METHOD_CBA_PREV:
			entity = new CBAResp();
			break;
		case HuPuRes.REQ_METHOD_CBA_BY_ID:
			entity = new SingleCBAData();
			break;
		case HuPuRes.REQ_METHOD_GET_NBA_DETAIL:
		case HuPuRes.REQ_METHOD_GET_CBA_DETAIL:
			entity = new NewsDetailEntity();
			break;
			
		case HuPuRes.REQ_METHOD_NBA_CHAT:
		case HuPuRes.REQ_METHOD_NBA_CHAT_MORE:
		case HuPuRes.REQ_METHOD_NBA_CHAT_NEW:
			entity = new ChatResp();
			break;
		case HuPuRes.REQ_METHOD_SENT_CHAT:
			entity = new SendMsgResp();
			break;
		}
		if (entity != null)
			try {
				if (type == HuPuRes.REQ_METHOD_REDIRECTOR) {
					((AdressEntity) entity).paser(s);
				} else {
					JSONObject jsonObject = new JSONObject(s);
					switch (type) {
					case HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS:
						entity.paser(jsonObject);
						break;
					default:
						//������Ϣ
						entity.err = isErr(jsonObject);
						if (entity.err  == null) {
							if (!isNull(jsonObject))// �ǿյ����ݽ���
								entity.paser(jsonObject);
						}
						break;
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return entity;
	}

	private static String isErr(JSONObject jsonObject) {
		// ����ID������˵����������ڣ�resultֵ��Ч��
		return jsonObject.optString("error", null);
	}

	private static boolean isNull(JSONObject jsonObject) {
		String ss = jsonObject.optString(BaseEntity.KEY_RESULT, null);
		if (ss == null)
			return true;
		if (ss.equals("{}") || ss.equals("[]"))
			return true;
		return false;

	}
}
