package com.hupu.games.data;

import org.json.JSONObject;

import com.umeng.common.Log;

public class NewsEntity extends BaseEntity {

	public long nid;// ����ΨһID
	
	public String title;//  ���ű���
	public String summary;// ��ƵԴ��ַ
	public int replies;// ����ʱ��



	@Override
	public void paser(JSONObject json) throws Exception {
		nid = json.optLong("nid");
		title = json.optString(KEY_TITLE, null);
		summary = json.optString("summary", null);
		replies = json.optInt("replies");

	}

}
