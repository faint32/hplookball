package com.hupu.games.data;

import org.json.JSONObject;
/**����bean*/
public class NotificationEntity extends BaseEntity {

   public String strTitle;
   public String strContent;
   public int i_type;
   public String strUrl;

   public String strRoom;
   public String strSound;
   public int i_badge;
   public int i_id;
	@Override
	public void paser(JSONObject json) throws Exception {
		JSONObject aps =json.getJSONObject("aps");
		JSONObject alert =aps.getJSONObject("alert");
		strContent=alert.optString("body","");
		 strTitle =alert.optString("title","");
		strSound = aps.optString("sound",null);
		
        strUrl= json.optString("url",null);
       
        if(strUrl!=null)
        {
        	paserUrl(strUrl);
        }
	}

	private final static String ROOM_NBA_HOME="NBA_HOME";
	private final static String NBA_PLAYBYPLAY="NBA_PLAYBYPLAY";
	private final static String NBA_BOXSCORE="NBA_BOXSCORE";
	private final static String NBA_RECAP="NBA_RECAP";
	private final static String TYPE_HTTP="HTTP";
	private final static String NBA_NEWS="NBA_NEWS";
	
	
	private void paserUrl(String s)
	{
		try {
			int start=s.indexOf("app://");
			if (start >-1)
			{
				int end = s.indexOf('/',6);
				if(end>0)
					strRoom=s.substring(6, end) ;
				else
					strRoom=s.substring(6) ;
				if(ROOM_NBA_HOME.equals(strRoom))
					i_type=1;
				else if(NBA_PLAYBYPLAY.equals(strRoom))
					i_type=2;
				else if(NBA_BOXSCORE.equals(strRoom))
					i_type=3;
				else if(NBA_RECAP.equals(strRoom))
					i_type=4;
				else if(NBA_NEWS.equals(strRoom) )
					i_type=5;			
				start=end+1;
				i_id =Integer.parseInt(s.substring(start));
				System.out.println("room="+strRoom+"id="+i_id);
			}
			else
			{
				start=s.indexOf("http:");
				if(start<0)
					i_type=6;
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

	}
}
