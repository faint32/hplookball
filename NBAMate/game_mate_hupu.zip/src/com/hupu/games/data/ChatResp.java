package com.hupu.games.data;

import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;
/**�����б�ҳ*/
public class ChatResp extends BaseEntity {

	public LinkedList<ChatEntity> mList;


	public long lastVId;
	/**�������������µ�ƫ����*/
	public int pid;    
	/** �ն������ƫ����*/
	public int pid_old ;  
	
	public int i_scoreHome = -1;
	public int i_scoreAway = -1;

	public String str_process;
	/** ����ƫ�Ʒ���*/
	public String direc; 
	/**��������*/
	public String online;  
	
	public int size;
	
	@Override
	public void paser(JSONObject json) throws Exception {
		
		online =json.optString("online",null);
		direc =json.optString("direc", "");
		pid = json.optInt("pid");
		pid_old = json.optInt("pid_old",-1);
		json =json.optJSONObject("result");
		
		
		if (json.has(KEY_SCORE_BOARD)) {
			// �ȷ�������
			JSONObject o = json.getJSONObject(KEY_SCORE_BOARD);
			i_scoreHome = o.optInt(KEY_HOME_SCORE, -1);
			i_scoreAway = o.optInt(KEY_AWAY_SCORE, -1);
			str_process = o.optString(KEY_PROCESS, null);
		}
		
		
		JSONArray array = json.optJSONArray("data");
		
		
		if (array != null) {
			size = array.length();
			mList = new LinkedList<ChatEntity>();
			ChatEntity temp;
			for (int i = 0; i < size; i++) {
				temp = new ChatEntity();
				temp.paser(array.getJSONObject(i));
				if(!temp.username.equals(""))
					mList.add(temp);
			}
		}
		
	}

}
