package com.hupu.games.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

public class LiveResp extends BaseEntity {

	public ArrayList<LiveEntity> dataList;
	public int allCount;
	public int pageCount;
	public int page;
	public int i_scoreHome;
	public int i_scoreAway;

	// public int i_lastId;
	// public int i_fisrtId;
	public String str_process;
	// public int i_status;
	/** ����or���� */
	private int i_type;
	private int TYPE_DESC = 0;
	private int TYPE_ASC = 1;
	public boolean bHasData;

	public LinkedList<int[]> mListDel;
	public LinkedList<int[]> mListAdd;
	public LinkedList<LinkedList<LiveEntity>> mListMsg;

	public int i_pId;

	public String tvLink;
	
	public String people_num;
	@Override
	public void paser(JSONObject obj) throws Exception {
//		Log.d("LiveResp", obj.toString());
		if(obj.has(KEY_PID))
		{
			i_pId =obj.optInt(KEY_PID,-1);
			people_num =obj.optString("online",null);
			obj = obj.getJSONObject(KEY_RESULT);
			
		}
		else
		{
			obj = obj.getJSONObject(KEY_RESULT);
			i_pId =obj.optInt(KEY_PID,-1);
			tvLink =obj.optString(KEY_TV_LINK, "");
		}
	
		JSONArray arr = obj.optJSONArray(KEY_DATA);
		int size = 0;
		if(arr!=null)
		  size = arr.length();
		
		if (size > 0) {
			bHasData = true;
			LiveEntity entity;
			JSONObject dataObj;
			boolean bHttpMode = true;
			for (int i = 0; i < size; i++) {
				dataObj = arr.getJSONObject(i);
				if (i == 0) {
					if (dataObj.has("a")) {
						bHttpMode = false;
						mListDel = new LinkedList<int[]>();
						mListAdd = new LinkedList<int[]>();
						mListMsg = new LinkedList<LinkedList<LiveEntity>>();
					} else
					{
						dataList = new ArrayList<LiveEntity>();
					}
				}

				if (bHttpMode) {
					// http ���������
					entity = new LiveEntity();
					entity.paser(dataObj);
					dataList.add(entity);
				} else {
					paserSocketData(dataObj);
				}
			}
		}
		//�ȷ���
		if (obj.has(KEY_SCORE_BOARD)) {
			obj = obj.getJSONObject(KEY_SCORE_BOARD);
			i_scoreHome = obj.optInt(KEY_HOME_SCORE, -1);
			i_scoreAway = obj.optInt(KEY_AWAY_SCORE, -1);
			str_process = obj.optString(KEY_PROCESS, null);
		}

	}

	private void paserSocketData(JSONObject dataObj) throws Exception {
		// socket���������
		JSONArray arr;
		LiveEntity entity;
		int tempSize;
		if (dataObj.has("d")) {
			// ɾ����
			arr = dataObj.getJSONArray("d");
			tempSize = arr.length();
			if (tempSize > 0) {
				int[] tempArr= new int[tempSize];
				for (int j = 0; j < tempSize; j++)
				{
					tempArr[j]=arr.getInt(j) ;
//					Log.d("paserSocketData", "del index="+arr.getInt(j) );
				}
				mListDel.add(tempArr);
			}
		}
		if (dataObj.has("a")) {
			// ������
			arr = dataObj.getJSONArray("a");
			tempSize = arr.length();
			if (tempSize > 0) {
				int[] tempArr = new int[tempSize];
				LinkedList<LiveEntity> tempList2 = new LinkedList<LiveEntity>();
				JSONObject oo = null;
				for (int j = 0; j < tempSize; j++) {
					oo = arr.getJSONObject(j);
					tempArr[j]=oo.getInt("rowId");
					entity = new LiveEntity();
					entity.paser(oo.getJSONObject("content"));
					tempList2.add(entity);
				}

				mListAdd.add(tempArr);
				mListMsg.add(tempList2);
			}
		}
	}
}
