package com.hupu.games.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;

public class CBAResp extends BaseEntity {

	public LinkedHashMap<String, ArrayList<CBAData>> mMap;
	public ArrayList<String> mKeys;
	public int prevRound;   
	public String prevTitle;  //��һ��
	
	public int nextRound;   
	public String nextTitle;  //��һ��
	
	public int curRound;
	public String curTitle;
	
	@Override
	public void paser(JSONObject json) throws Exception {
		JSONObject result =json.getJSONObject(KEY_RESULT);
		
		JSONObject rounds =result.getJSONObject("rounds");
        
		JSONObject round =rounds.optJSONObject("prev");
	
		if(round!=null)
		{
			prevRound =round.optInt("round");
			prevTitle =round.optString("title");
		}
		round =rounds.optJSONObject("current");
		if(round!=null)
		{
			curRound =round.optInt("round");
			curTitle =round.optString("title");
		}
		round =rounds.optJSONObject("next");
		if(round!=null)
		{
			nextRound =round.optInt("round");
			nextTitle =round.optString("title");
		}
		rounds =null;
		round=null;
		
		JSONArray array =result.optJSONArray(KEY_DATA);
		if(array!=null)
		{
			String date =null;
			int size =array.length();
			CBAData data =null;
			mMap =new LinkedHashMap<String, ArrayList<CBAData>>();
			mKeys =new ArrayList<String>();
			ArrayList<CBAData> list =null;
			for(int i=0;i<size;i++)
			{
				data =new CBAData();
				data.paser(array.getJSONObject(i));
				if(!data.date .equals( date))
				{
					list =new ArrayList<CBAData>();
					mKeys.add(data.date);
					mMap.put(data.date, list);
					date =data.date;
				}
				list.add(data);				
			}
		}
	}

}
