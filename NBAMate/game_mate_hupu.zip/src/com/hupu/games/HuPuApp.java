package com.hupu.games;

import io.socket.SocketIO;
import io.socket.SocketIOException;
import io.socket.SocketIoHandler;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Currency;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeoutException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.hupu.games.activity.HupuBaseActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.common.SharedPreferencesMgr;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.FollowResp;
import com.hupu.games.data.JsonPaserFactory;
import com.hupu.games.data.TeamValueEntity;
import com.hupu.games.db.HuPuDBAdapter;
import com.hupu.games.handler.ISocketCallBack;
import com.hupu.games.service.HuPuGamemateService;
import com.hupu.games.service.HuPuGamemateService.MyServiceBinder;
import com.pyj.BaseApplication;
import com.pyj.common.DeviceInfo;
import com.pyj.http.AsyncHttpClient;
import com.pyj.http.AsyncHttpResponseHandler;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

public class HuPuApp extends BaseApplication implements ISocketCallBack {
	public AsyncHttpClient mHttpClient;
	private static LinkedList<Integer> mListFollowedTeam;
	// private static LinkedList<Integer> mListFollowedGames;
	private static HuPuApp instance;
	public String cachePath;

	public static boolean needNotify = true;

	Intent filter;
	public HuPuApp() {
		mHttpClient = new AsyncHttpClient();
		mListFollowedTeam = new LinkedList<Integer>();
		// mListFollowedGames =new LinkedList<Integer> ();
		instance = this;
		filter =new Intent("QUIT_NOTIFY");
		
	}

	
	@Override
	public void onCreate() {
		super.onCreate();
		bStart = true;
		SharedPreferencesMgr.init(this, "hupugamemate");
		initTeamDatas();

		needNotify = SharedPreferencesMgr.getBoolean("notify", true);
		
		IntentFilter ift =new IntentFilter();
		ift.addAction("QUIT_NOTIFY");
        registerReceiver(new AppReceiver(), ift);
        
		// bindService();
	}

	public void setNotify(boolean b) {
		needNotify = b;
		SharedPreferencesMgr.setBoolean("notify", needNotify);
	}

	/**
	 * �˳�
	 * */
	public static boolean bStart;

	public void quit() {
		// ��������������
		mHttpClient.cancelRequests(this, true);
		mHttpClient = null;
		// socketClient.disconnect();
		socketClient = null;
		// for test
		// Intent intent =new Intent(this,HuPuGamemateService.class);
		// stopService(intent);
		// test end
		bStart = false;
		onBackground();
		super.quit();
	}

	private String KEY_FIRST = "isFirst";

	public boolean isFirst() {
		// HuPuDBAdapter mDbAdapter = new HuPuDBAdapter(this);
		// mDbAdapter.insertIsFirst();
		// return mDbAdapter.isFirst();
		boolean b = SharedPreferencesMgr.getBoolean(KEY_FIRST, true);
		SharedPreferencesMgr.setBoolean(KEY_FIRST, false);
		// System.out.println("isfirst=" + b);
		return b;
	}

	public static LinkedList<Integer> getFollowTeams() {
		return mListFollowedTeam;
	}

	public LinkedList<Integer> loadFollowTeam() {
		HuPuDBAdapter mDbAdapter = new HuPuDBAdapter(this);
		mListFollowedTeam = mDbAdapter.getFollowTeams();
		return mListFollowedTeam;
	}

	public static String getFollowTeamsNames(LinkedList<Integer> list) {
		String ss = "";
		if (list == null)
			list = mListFollowedTeam;

		TeamValueEntity data = null;
		int size = list.size();
		for (int i = 0; i < size; i++) {

			data = getTeamData(list.get(i));
			ss += data.str_name;
			if (i == 1 && size == 2)
				break;
			if (i == 1 && size > 2) {
				ss += "��";
				break;
			}
			if (i != size - 1)
				ss += "��";
		}
		return ss;
	}

	/**
	 * ������ע��ӡ� ���ڹ�עҳ���Ѿ���finish�����Բ��ܰѸýӿ�д��BaseActivity�С�
	 * **/
	public void followTeams(LinkedList<Integer> list, Activity act) {
		RequestParams mParams = new RequestParams();
		StringBuffer sb = new StringBuffer();
		int size = list.size();
		for (int i = 0; i < size; i++) {
			sb.append(list.get(i));
			if (i != size - 1)
				sb.append(',');
		}
		mParams.put(BaseEntity.KEY_TEAM_IDS, sb.toString());
		mParams.put("client", DeviceInfo.getDeviceInfo(this));
		if (DeviceInfo.isNetWorkEnable(this)) {
			mHttpClient.get(this,
					HuPuRes.getUrl(HuPuRes.REQ_METHOD_SET_FOLLOW_TEAMS),
					mParams, new TeamsHandler(list),
					HuPuRes.REQ_METHOD_SET_FOLLOW_TEAMS);
		} else {
			// Toast.makeText(act, "û�����磬���Ժ����ԡ�", Toast.LENGTH_SHORT).show();
		}
	}

	public void insertTeamsToDB(LinkedList<Integer> listTeams) {
		mListFollowedTeam = listTeams;
		HuPuDBAdapter mDbAdapter = new HuPuDBAdapter(this);
		mDbAdapter.delTeams();
		mDbAdapter.insertTeams(listTeams);
	}

	/**
	 * ������ע���������Ӧhandle��
	 * 
	 * **/
	class TeamsHandler extends AsyncHttpResponseHandler {
		private LinkedList<Integer> listTeams;

		public TeamsHandler(LinkedList<Integer> list) {
			listTeams = list;
		}

		@Override
		public void onFinish() {
			super.onFinish();
		}

		@Override
		public void onSuccess(String content, int reqType) {
			super.onSuccess(content, reqType);
			FollowResp resp = (FollowResp) JsonPaserFactory.paserObj(content,
					reqType);
			if (resp.i_success == 1) {
				/** ���б��������ݿ��� */
				insertTeamsToDB(listTeams);
				// SharedPreferencesMgr.setBoolean("isFirst", false);
			}
		}

		@Override
		public void onFailure(Throwable error, String content, int reqType) {
			super.onFailure(error, content, reqType);
		}
	}

	// -------------------��ʼ���������------------------------------------------//
	private static HashMap<Integer, TeamValueEntity> mapTeams;

	/**
	 * ��ȡ��ӵĻ�������
	 * 
	 * @param tid
	 *            ��ӵ�id
	 * @return ��ӵĻ�������
	 * */
	public static TeamValueEntity getTeamData(int tid) {
		if (mapTeams.get(tid) != null)
			return mapTeams.get(tid);
		else {
			TeamValueEntity defaultTeams = TeamValueEntity.getDefault(tid);
			addToTeams(tid, defaultTeams);
			return defaultTeams;
		}
	}

	public static boolean hasTeam(int tid, String name) {
		if (mapTeams.get(tid) == null) {
			TeamValueEntity defaultTeams = TeamValueEntity.getDefault(tid);
			defaultTeams.str_name = name;
			addToTeams(tid, defaultTeams);
			return false;
		}
		return true;
	}

	/**
	 * ���ӷ�nba��ӵ�����б���
	 * */
	public static void addToTeams(int id, TeamValueEntity defaultTeams) {
		mapTeams.put(id, defaultTeams);
	}

	/**
	 * ��ʼ������nba��ӵ�����
	 * */
	private void initTeamDatas() {
		mapTeams = new HashMap<Integer, TeamValueEntity>();
		Resources res = getResources();
		String[] teamNames = res.getStringArray(R.array.team_names);
		String[] enNames = res.getStringArray(R.array.team_names_en);
		int[] color = res.getIntArray(R.array.team_color);
		TeamValueEntity entity;
		for (int i = 0; i < color.length; i++) {
			entity = new TeamValueEntity();
			// id ��1��ʼ
			entity.i_tid = i + 1;
			entity.i_color = color[i];
			entity.str_name = teamNames[i];
			entity.str_name_en = enNames[i];
			entity.i_logo = TeamValueEntity.ICON_RES[i];
			entity.i_logo_small = TeamValueEntity.ICON_RES_SMALL[i];
			mapTeams.put(entity.i_tid, entity);
		}
	}

	/**
	 * �����Ƿ���ǰ̨����
	 * 
	 * @return
	 */
	public boolean isAppOnForeground() {
		// Returns a list of application processes that are running on the
		// device

		ActivityManager activityManager = (ActivityManager) getApplicationContext()
				.getSystemService(Context.ACTIVITY_SERVICE);
		String packageName = getApplicationContext().getPackageName();

		List<RunningAppProcessInfo> appProcesses = activityManager
				.getRunningAppProcesses();

		if (appProcesses == null)
			return false;

		for (RunningAppProcessInfo appProcess : appProcesses) {
			// The name of the process that this object is associated with.
			if (appProcess.processName.equals(packageName)
					&& appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean treatErr(Throwable ex) {
		Intent intent = new Intent(getApplicationContext(),
				TabIndexActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.addCategory(Intent.CATEGORY_LAUNCHER);
		// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
				| Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
		startActivity(intent);
		return false;
	}

	private boolean bBackground=true;
	
    private long backgroundTime;
    
	public void onBackground() {
//		 Log.d("HuPuApp", "onBackground startService ");
		bBackground = true;
		if (needNotify) {
//			 Log.d("HuPuApp", "onBackground startService  >>>>>>:::::"+needNotify);
			Intent intent = new Intent(this, HuPuGamemateService.class);
			intent.putExtra("server1", HuPuRes.getDefaultServer());
			intent.putExtra("server2", HuPuRes.getBackUpServer());
			intent.putExtra("startCon", true);
			startService(intent);
		}
		// �����߼������е��������ʱ���Ͽ����ӡ�
		disconnect();
		backgroundTime =System.currentTimeMillis();
		//��Сʱ���Զ��˳���
		quitLater(QUIT_INTERVAL);
//		quitLater(10000);
		// if(socketClient!=null)
		// socketClient.clean();
		// leaveRoom();
		
	}

	class AppReceiver extends BroadcastReceiver 
	{
		@Override
		public void onReceive(Context context, Intent intent) {
			if(bBackground)
				quit();
//			Log.d("AppReceiver", "intent"+intent.getLongExtra("time", 0));			
		}		
	}
	
	private void cancelAlarm() {
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.cancel(getPendingIntent());
	}
	
	private static final long QUIT_INTERVAL=60000*20;
	
	/** ��ʱ�ر� */
	private void quitLater(long later) {
		cancelAlarm() ;
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		long firstWake = System.currentTimeMillis() + later;
		am.set(AlarmManager.RTC_WAKEUP, firstWake, getPendingIntent());
	}
	
	private PendingIntent getPendingIntent() {
	
		filter.putExtra("time", backgroundTime);
		return PendingIntent.getBroadcast(this, 0, filter, PendingIntent.FLAG_UPDATE_CURRENT);

	}
	
	public void onForeground() {
//		 Log.d("HuPuApp", "onForeground startService  >>>>>>:::::"+bBackground);
		if (bBackground) {
			cancelAlarm();
			Intent intent = new Intent(this, HuPuGamemateService.class);
			intent.putExtra("stop", true);
			startService(intent);
		}
		bBackground = false;
	}

	public void setServer(String server[]) {
		SharedPreferencesMgr.setString("default_server", server[0]);
		SharedPreferencesMgr.setString("backup_server", server[1]);
		HuPuRes.setServer(server[0], server[1]);
	}

	// ------------------------������ʵʱ�ӿ�---------------------//

	/** ------------socket---------------------- **/

	private SocketIO socketClient;
	private JSONObject jsonRoom;

	private SocketIoHandler mSocketHandler;
	protected boolean bSocketConnect;

	public int i_net_state;
	public final static int STATE_NO_NET = 1;
	/** ������ */
	public final static int STATE_CONNECTING = 3;

	/** ���ӳɹ� */
	public final static int STATE_CONNECTED = 4;

	/** ���ӶϿ� */
	public final static int STATE_DISCONNECT = 5;

	/** ���� */
	public final static int STATE_ON_LINE = 7;

	public final static int STATE_NET_ERR = 8;

	private HupuBaseActivity mAct;

	private ConcurrentHashMap<String, HupuBaseActivity> roomsMap;

	public boolean isSocketConn() {
		return bSocketConnect;
	}

	public void setNetState(int ns) {
		i_net_state = ns;
	}

	public void registActivity(String name, HupuBaseActivity a) {
		if (roomsMap == null)
			roomsMap = new ConcurrentHashMap<String, HupuBaseActivity>();
		// if(roomsMap.get(name)!=null)
		if (name != null)
			roomsMap.put(name, a);
		mAct = a;
	}

	public SocketIO getSocket() {
		try {
			if (socketClient == null) {
				if (HuPuRes.getDefaultServer() != null)
					socketClient = new SocketIO(HuPuRes.getDefaultServer());
			}
			initConn();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return socketClient;
	}

	/** ��ʼ��socketio������ */
	private void initConn() {
		// Log.d("HupuApp", "initConn  >>>>>>:::::");
		if (socketClient != null && socketClient.isConnected()) {
			return;
		}
		if (mSocketHandler == null)
			mSocketHandler = new SocketIoHandler(this);
		// i_net_state = STATE_CONNECTING;
		// updateNetState();
		try {
			socketClient = new SocketIO(HuPuRes.getDefaultServer());
			socketClient.connect(mSocketHandler);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	/** ��ʼ��socketio������ */
	public void joinRoom(JSONObject jRoom) {
//		Log.d("joinRoom", "jRoom="+jRoom);
		jsonRoom = jRoom;
		if (socketClient != null && socketClient.isConnected()) {
			socketClient.emit("join", jsonRoom);
		} else
			getSocket();
	}

	/** emit */
	public void emit(String emit, JSONObject Request) {

		if (socketClient != null && socketClient.isConnected()) {
			socketClient.emit(emit, Request);
		} else
			getSocket();
	}

	/** �뿪room */
	public void leaveRoom() {
		if (socketClient != null && socketClient.isConnected())
			socketClient.emit("leave", jsonRoom);
	}

	public void disconnect() {
		if (socketClient != null && socketClient.isConnected())
			socketClient.disconnect();
	}

	private final int RECON_INTEVAL = 60000;
	Handler handler = new Handler();

	/** ���߻����������������� */
	public void reconnect(boolean now) {
		if (bBackground)
			return;
		int interval;
		if (DeviceInfo.isNetWorkEnable(this)) {
			if (now)
				interval = 1000;
			else
				interval = 30000;// 30�������
		} else {
			interval = RECON_INTEVAL;
			i_net_state = STATE_NO_NET;// û�����磬60�������
		}
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				initConn();// ����
			}
		}, interval);
		// updateNetState();
	}

	public void onSocketConnect() {
		// System.out.println("on onConnect");
		i_net_state = STATE_CONNECTED;
		bSocketConnect = true;
		if (mAct != null && !mAct.isFinishing())
			mAct.onSocketConnect();
	}

	public void onSocketDisconnect() {
		// System.out.println("on onDisconnect bSocketConnect= " +
		// bSocketConnect);
		bSocketConnect = false;
		i_net_state = STATE_DISCONNECT;
		if (bBackground)
			return;
		if (mAct != null && !mAct.isFinishing())
			mAct.onSocketDisconnect();
	}

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	public void onSocketError(SocketIOException socketIOException) {
		// System.out.println("on err" + socketIOException.toString());
		bSocketConnect = false;
		i_net_state = STATE_NET_ERR;
		if (mAct != null && !mAct.isFinishing())
			mAct.onSocketError(socketIOException);

		UMENG_MAP.put("socket", "failed");
		MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NETWORK, UMENG_MAP);

	}

	public void onSocketResp(JSONObject obj) {
		// System.out.println("on===" + obj);
		i_net_state = STATE_ON_LINE;
		if (mAct != null && !mAct.isFinishing())
			mAct.onSocketResp(obj);
	}

	/** ����socket����״̬�� */
	public void updateNetState() {

		String ss;

		// Log.d("HupuApp", "updateNetState  >>>>>>:::::");

		switch (i_net_state) {
		case STATE_NO_NET:
			ss = "������";
			break;
		/** ������ */
		case STATE_CONNECTING:
			ss = "������";
			break;

		/** ���ӳɹ� */
		case STATE_CONNECTED:
			ss = "������";
			break;
		/** ���ӶϿ� */
		case STATE_DISCONNECT:
			ss = "����";
			break;
		/** ���� */
		case STATE_ON_LINE:
			ss = "����";
			break;
		case STATE_NET_ERR:
			ss = "���Ӵ���";
			break;
		}
	}

	private void bindService() {
		Intent intent = new Intent(this, HuPuGamemateService.class);
		bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
	}

	private ServiceConnection serviceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder iBinder) {
			// Log.d("HuPuApp", "onServiceConnected >>>>>>:::::");
			if (iBinder instanceof MyServiceBinder) {
				Log.d("HuPuApp", "iBinder >>>>>>:::::");
				gameService = ((MyServiceBinder) iBinder).getService();
				gameService.callStopConnection();
			}

		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			// Log.d("HuPuApp", "onServiceDisconnected >>>>>>:::::");
			gameService = null;
		}

	};

	private HuPuGamemateService gameService;
}
