package com.hupu.games.activity;

import io.socket.SocketIOException;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.adapter.GameDataListLandAdapter;
import com.hupu.games.adapter.HupuPagerAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.BoxScoreResp;
import com.hupu.games.data.ChatResp;
import com.hupu.games.data.FollowResp;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.LiveResp;
import com.hupu.games.data.PlayerEntity;
import com.hupu.games.data.Recap;
import com.hupu.games.data.SendMsgResp;
import com.hupu.games.fragment.CBAReportFragment;
import com.hupu.games.fragment.CBAStatisticFragment;
import com.hupu.games.fragment.LiveFragment;
import com.hupu.games.fragment.ChatFragment;
import com.hupu.games.fragment.ReportFragment;
import com.hupu.games.fragment.StatisticFragment;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.view.HupuViewPager;
import com.pyj.common.DeviceInfo;
import com.pyj.common.DialogRes;
import com.pyj.common.MyUtility;
import com.umeng.analytics.MobclickAgent;

/**
 * ��ʾֱ����ͳ������ҳ��
 * */
public class HupuDataActivity extends HupuBaseActivity {

	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"����:M��d�� H:mm", java.util.Locale.CHINESE);

	private TextView txtTitle;
	/** �ȷ��� */
	private TextView txtHomeScore1;
	private TextView txtHomeScore2;
	private TextView txtHomeScore3;

	private TextView txtAwayScore1;
	private TextView txtAwayScore2;
	private TextView txtAwayScore3;
	/** ����δ��ʼʱ��ʾ�Ŀ���ʱ�� */
	private TextView txtStartTime;
	/** ������ʼ����ʾ��ʱ�� */
	private TextView txtTime;

	/** ���Ӷ��� */
	private TextView txtTopHome;
	/** �ͶӶӶ��� */
	private TextView txtTopAway;
	// private ImageView imgHome;
	// private ImageView imgAway;
	/** ����״̬ */
	private int i_gameStatus;

	private final static int GAME_STATE_CANCEL = 4;
	private final static int GAME_STATE_ONGOING = 2;
	private final static int GAME_STATE_END = 1;
	private final static int GAME_STATE_NOT_START = 3;
	/** ������entity */
	private GameEntity mEntityGame;
	/** ��¼�ȷֵ�layoutĬ�ϲ���ʾ */
	private View mLayoutScore;

	/** �����ȷ֣������Ϣ������ʱ���layout */
	private View mLayoutScoreBar;

	private ImageButton btnThird;
	private ImageButton btnFirst;
	private ImageButton btnSecond;
	private ImageButton btnChat;

	/** ��ע������ť */
	private Button btnFollow;
	/** ��Ƶ���Ű�ť */
	private Button btnPlay;
	/** �Ƿ���ֱ������ */
	boolean bHasLiveData;
	/** �Ƿ���ͳ������ */
	boolean bHasStatisticData;
	/** �Ƿ����ս�� */
	boolean bHasReportData;

	// private HupuViewPager mPager;

	private HupuPagerAdapter mPageAdapter;
	/** ֱ��ҳ */
	private LiveFragment mFragmentLive;
	/** ͳ��ҳ */
	private StatisticFragment mFragmentStatistic;
	/** ս��ҳ */
	private ReportFragment mFragmentReport;

	/** ս��ҳ */
	private ChatFragment mFragmentChat;

	/** ��ǰ����ҳ���� */
	private int curIndex;

	private final static int INDEX_REPORT = 0;
	private final static int INDEX_LIVE = 2;
	private final static int INDEX_STATISTIC = 1;
	private final static int INDEX_CHAT = 3;
	/** ������ �� ������ ֱ����ͳ��ҳ���ڵ�λ�ò�ͬ��������Ҫ����Ӧ�Ĵ��� */
	private int i_liveIndex;

	private int i_staticIndex;
	/** �Ƿ��Ǳ����� */
	private boolean bMatchDay;

	private static String SORRY_NOTIFY = "��Ǹ��%s vs %s��������ʧ��";
	private static String SUCCESS_NOTIFY = "�������óɹ����������յ�%s vs %s������֪ͨ";
	private static String CANCEL_NOTIFY = "����ȡ���ɹ�";

	private static final int num_res[] = { R.drawable.num0, R.drawable.num1,
			R.drawable.num2, R.drawable.num3, R.drawable.num4, R.drawable.num5,
			R.drawable.num6, R.drawable.num7, R.drawable.num8, R.drawable.num9, };

	/** �ص���Ҫ��¼�ڴӱ����б�����ʱ�ǲ��ǹ�ע�˸ñ���������ʱ���Լ�ʱ����Ӧ���� */
	private int i_initFollow;

	private Intent mIntent;

	private int i_pos;

	/** ����ֱ��ҳ��ͳ��ҳ��Ҫ�г������ݲż���socket */
	private boolean bJoinRoom;

	private String movieUrl;
	/** �Ƿ���ˮƽģʽ */
	boolean isLandMode;
	/** ��ֱView */
	View vPortrait;
	/** ˮƽ��View */
	View vLandscape;
	/** �����Ƿ��Ѿ������� */
	public boolean bEnd;
	/** �����Ѿ��������ǲ��ǻ�ȡ�����ֱ������ */
	public boolean getLiveEndData;
	/** �����Ѿ��������ǲ��ǻ�ȡ�����ͳ������ */
	public boolean getBoxEndData;

	/***/
	private int lastLiveID;

	private int lastChatID;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// Log.d("HupuDataActivity",
		// "onCreate  >>>>>>:::::"+android.os.Process.myPid());
		if (savedInstanceState != null)
			savedInstanceState.clear();
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		setContentView(R.layout.layout_data);

		HuPuRes.setClient(DeviceInfo.getDeviceInfo(this.getApplicationContext()));
		// l_date =mIntent.getLongExtra("date", 0);
		mIntent = getIntent();
		mEntityGame = (GameEntity) mIntent.getSerializableExtra("game");
		if (mEntityGame == null) {
			finish();
		}
		i_pos = mIntent.getIntExtra("pos", 0);
		i_initFollow = mEntityGame.i_isFollow;
		bMatchDay = mIntent.getBooleanExtra("match", false);

		init();

	}

	public void onResume() {
		// Log.d("HupuDataActivity",
		// "onResume  >>>>>>:::::"+android.os.Process.myPid());
		super.onResume();
		MobclickAgent.onResume(this);

		if (bJoinRoom) {
			// �����Ҫ���뷿��
			if (DeviceInfo.isNetWorkEnable(this)) {
				// ����Ƿ�����
				if (curIndex == INDEX_LIVE) {
					joinRoom();
				} else if (curIndex == INDEX_CHAT) {
					// reqChatData(lastChatID);
					if (!mApp.isSocketConn())
						joinRoom();
				}

			} else {
				mApp.setNetState(HuPuApp.STATE_NO_NET);
				reconnect(false);
			}
		}

	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onDestroy() {
		// Log.d("HupuDataActivity",
		// "onDestroy  >>>>>>:::::"+android.os.Process.myPid());
		bJoinRoom = false;
		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (REQ_SEND_MSG == requestCode && resultCode == RESULT_OK) {

			String content = data.getStringExtra("content");
			String userName = data.getStringExtra("user");
			// Log.d("onActivityResult", "REQ_SEND_MSG" + content);
			sendChatMsg(userName, content);

		}
	}

	/** ������Ϣ */
	private void sendChatMsg(String name, String s) {
		// initParameter();
		// Log.d("HupuDataActivity", "name=" + name + " conten=" + s);
		mParams.put("type", "nba");
		mParams.put("username", name);
		mParams.put("content", s);
		mParams.put("gid", "" + mEntityGame.i_gId);
		reqHttp(HuPuRes.REQ_METHOD_SENT_CHAT);
		mFragmentChat.addData(name, s);
	}

	private GestureDetector gesture;
	private View.OnTouchListener gestureListener;

	/** ��ʼ�����ƣ���Ҫ����ͳ�������ܹ������ƶ� */
	private void initGesture() {
		gesture = new GestureDetector(this, new MyGestureDetector());
		gestureListener = new View.OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				if (gesture.onTouchEvent(event)) {
					return true;
				}
				return false;
			}
		};
	}

	FragmentManager fragmentManager;

	/** ��ʼ����Ƭ */
	private void initFragment() {
		// ��ʼ������Ҫ��Frame
		mFragmentReport = new ReportFragment();
		mFragmentLive = new LiveFragment(mEntityGame.i_home_tid,
				mEntityGame.i_away_tid);
		mFragmentStatistic = new StatisticFragment(mEntityGame.i_home_tid,
				mEntityGame.i_away_tid, gestureListener);
		mFragmentChat = new ChatFragment();

		// mPageAdapter = new HupuPagerAdapter(this);
		// mPageAdapter.addFragment(mFragmentReport);
		// mPageAdapter.addFragment(mFragmentStatistic);
		// mPageAdapter.addFragment(mFragmentLive);
		// mPager.setAdapter(mPageAdapter);

		fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();

		fragmentTransaction.add(R.id.nba_content, mFragmentReport);
		fragmentTransaction.add(R.id.nba_content, mFragmentStatistic);
		fragmentTransaction.add(R.id.nba_content, mFragmentLive);
		fragmentTransaction.add(R.id.nba_content, mFragmentChat);
		fragmentTransaction.hide(mFragmentReport);
		fragmentTransaction.hide(mFragmentStatistic);
		fragmentTransaction.hide(mFragmentLive);
		fragmentTransaction.hide(mFragmentChat);
		fragmentTransaction.commit();

	}

	private int lastShowIndex = -1;

	private void switchFragment(int show) {
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();

		switch (show) {
		case INDEX_REPORT:
			fragmentTransaction.show(mFragmentReport);
			break;
		case INDEX_LIVE:
			fragmentTransaction.show(mFragmentLive);
			break;
		case INDEX_STATISTIC:
			fragmentTransaction.show(mFragmentStatistic);
			break;
		case INDEX_CHAT:
			fragmentTransaction.show(mFragmentChat);
			break;
		}

		switch (lastShowIndex) {
		case INDEX_REPORT:
			fragmentTransaction.hide(mFragmentReport);
			break;
		case INDEX_LIVE:
			fragmentTransaction.hide(mFragmentLive);
			break;
		case INDEX_STATISTIC:
			fragmentTransaction.hide(mFragmentStatistic);
			break;
		case INDEX_CHAT:
			fragmentTransaction.hide(mFragmentChat);
			break;
		}

		lastShowIndex = show;
		fragmentTransaction.commit();
	}

	/** ��ʼ�� */
	private void init() {
		i_gameStatus = mEntityGame.byt_status;
		txtStartTime = (TextView) findViewById(R.id.txt_start_time);
		UMENG_MAP.clear();
		if (i_gameStatus == GAME_STATE_CANCEL) {
			txtStartTime.setText(R.string.canceled);
		} else {
			vPortrait = findViewById(R.id.layout_portrait);
			vLandscape = findViewById(R.id.layout_land);
			// mPager = (HupuViewPager) findViewById(R.id.pager_datas);
			initGesture();
			initFragment();

			mLayoutScore = findViewById(R.id.layout_score);
			mLayoutScoreBar = findViewById(R.id.layout_score_bar);
			txtTitle = (TextView) findViewById(R.id.txt_title);
			title = txtTitle.getText();
			txtHomeScore1 = (TextView) findViewById(R.id.txt_home_scrore1);
			txtHomeScore2 = (TextView) findViewById(R.id.txt_home_scrore2);
			txtHomeScore3 = (TextView) findViewById(R.id.txt_home_scrore3);

			txtAwayScore1 = (TextView) findViewById(R.id.txt_away_scrore1);
			txtAwayScore2 = (TextView) findViewById(R.id.txt_away_scrore2);
			txtAwayScore3 = (TextView) findViewById(R.id.txt_away_scrore3);
			txtTime = (TextView) findViewById(R.id.txt_proccess);
			btnThird = (ImageButton) findViewById(R.id.btn_third);
			btnSecond = (ImageButton) findViewById(R.id.btn_second);
			btnFirst = (ImageButton) findViewById(R.id.btn_first);
			btnChat = (ImageButton) findViewById(R.id.btn_chat);
			initParameter();
			setJosnObj(BaseEntity.KEY_GAME_ID, mEntityGame.i_gId);
			mParams.put(BaseEntity.KEY_GAME_ID, "" + mEntityGame.i_gId);
			mParams.put(BaseEntity.KEY_VERTICAL, "" + true);

			setViewByStatus(true);

			if (i_gameStatus == GAME_STATE_NOT_START) {
				// δ��ʼ
				txtStartTime.setText(MyUtility.getStartTime(
						mEntityGame.l_begin_time * 1000, sdf));
				// ��������
				// reqHttp(HuPuRes.REQ_METHOD_GET_PLAY_LIVE_DESC);
				// setRoomObj(HuPuRes.ROOM_PLAYBYPLAY);
				// bJoinRoom = true;
				treatClickEvent(R.id.btn_second);// ֱ��
				UMENG_MAP.put("tab", "playbyplay");
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_HOME_TAP_GAME,
						UMENG_MAP);
				setScreenLight(true);
			} else {
				mFragmentLive.isStart(true);
				mLayoutScore.setVisibility(View.VISIBLE);
				txtStartTime.setVisibility(View.GONE);
				setSore(mEntityGame.i_home_score, mEntityGame.i_away_score);
				txtTime.setText(mEntityGame.str_process);

				if (i_gameStatus == GAME_STATE_END)// �Ѿ�����
				{
					// mPager.setCurrentItem(0, false);
					// switchFragment(0);
					curIndex = -1;
					treatClickEvent(R.id.btn_first);// ս��
					UMENG_MAP.put("tab", "recap");
					MobclickAgent.onEvent(this,
							HuPuRes.UMENG_KEY_HOME_TAP_GAME, UMENG_MAP);

				} else if (i_gameStatus == GAME_STATE_ONGOING) // ������
				{
					// mPager.setCurrentItem(1, false);
					treatClickEvent(R.id.btn_second);// ֱ��
					UMENG_MAP.put("tab", "playbyplay");
					MobclickAgent.onEvent(this,
							HuPuRes.UMENG_KEY_HOME_TAP_GAME, UMENG_MAP);
					setScreenLight(true);
				}
			}

		}

		setTeamName();
		// test
		// reqHttp(HuPuRes.REQ_METHOD_GET_PLAY_LIVE);
		//
		setOnClickListener(R.id.btn_third);
		setOnClickListener(R.id.btn_second);
		setOnClickListener(R.id.btn_back);
		setOnClickListener(R.id.btn_first);
		setOnClickListener(R.id.btn_follow);
		setOnClickListener(R.id.btn_play);
		setOnClickListener(R.id.btn_land);
		setOnClickListener(R.id.btn_chat);
		setOnClickListener(R.id.btn_sent);

		btnFollow = (Button) findViewById(R.id.btn_follow);
		btnPlay = (Button) findViewById(R.id.btn_play);
		isFollow = mEntityGame.i_isFollow == 1;
		setFollowBtn();
	}

	/** ���ù�ע������UI״̬ */
	private void setFollowBtn() {
		if (i_gameStatus == GAME_STATE_ONGOING
				|| i_gameStatus == GAME_STATE_NOT_START) {

			findViewById(R.id.layout_title_btn).setVisibility(View.VISIBLE);
			if (isFollow) {
				// btnFollow.setImageResource(R.drawable.btn_txt_followed);
				// btnFollow.setImageResource(R.drawable.btn_dated_2);
				btnFollow.setBackgroundResource(R.drawable.btn_alarm_bright);
			} else {
				// btnFollow.setImageResource(R.drawable.btn_txt_follow);
				// btnFollow.setImageResource(R.drawable.btn_date_2);
				btnFollow.setBackgroundResource(R.drawable.btn_alarm_dark);
			}

		} else {
			btnFollow.setVisibility(View.GONE);
			btnPlay.setVisibility(View.GONE);
			findViewById(R.id.img_split).setVisibility(View.GONE);
			findViewById(R.id.layout_title_btn).setVisibility(View.GONE);
		}
	}

	/** ����������� */
	private void setTeamName() {
		// �������
		txtTopHome = (TextView) findViewById(R.id.txt_home);
		txtTopHome.setText(mEntityGame.str_home_name + " (��)");
		txtTopAway = (TextView) findViewById(R.id.txt_away);
		txtTopAway.setText(mEntityGame.str_away_name + " (��)");
		setIcon(txtTopHome, mEntityGame.i_home_tid);
		setIcon(txtTopAway, mEntityGame.i_away_tid);
		// imgHome=(ImageView) findViewById(R.id.img_home);
		// imgHome.setBackgroundResource(HuPuApp.getTeamData(mEntityGame.i_home_tid).i_logo);
		// imgAway=(ImageView) findViewById(R.id.img_away);
		// imgAway.setBackgroundResource(HuPuApp.getTeamData(mEntityGame.i_away_tid).i_logo);
	}

	/** �������logo */
	private void setIcon(TextView tv, int tid) {
		tv.setCompoundDrawablesWithIntrinsicBounds(0,
				HuPuApp.getTeamData(tid).i_logo, 0, 0);
	}

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (methodId == HuPuRes.REQ_METHOD_GET_PLAY_LIVE_ASC
				|| methodId == HuPuRes.REQ_METHOD_GET_PLAY_LIVE_DESC) {
			LiveResp data = (LiveResp) o;
			movieUrl = data.tvLink;
			if (!"".equals(movieUrl))
				btnPlay.setEnabled(true);
			if (i_gameStatus != GAME_STATE_NOT_START)
				mFragmentLive.isStart(true);
			if (data.dataList == null) {
				// û������
				if (i_gameStatus == GAME_STATE_NOT_START) {
					// showToast("����δ��ʼ");
				} else {
					showToast("����ֱ������");

				}
				mFragmentLive.addData(true);
				return;
			}

			mFragmentLive.setData(data.dataList);
			bHasLiveData = true;
			lastLiveID = data.i_pId;
			// Log.d("http back pid", ""+data.i_pId);

			// ����Ǳ���
			if (methodId == HuPuRes.REQ_METHOD_GET_PLAY_LIVE_DESC)
				setJosnObj(BaseEntity.KEY_PID, data.i_pId);
			if (i_gameStatus != GAME_STATE_END) {// �������δ������Ҫ���뷿��
				bJoinRoom = true;
				joinRoom(HuPuRes.ROOM_PLAYBYPLAY);
			} else {
				getLiveEndData = true;
			}

		} else if (methodId == HuPuRes.REQ_METHOD_BOX_SCORE) {
			BoxScoreResp data = (BoxScoreResp) o;
			if (data.mEntityHome == null) {
				// û������
				mFragmentStatistic.addData(true);
				showToast("����ͳ������");
				return;
			}
			mFragmentStatistic.setData(data, false);
			if (mBoxscoreData == null)
				mBoxscoreData = new BoxscoreDatas();
			mFragmentStatistic.updateBoxScoreData(mBoxscoreData);
			bHasStatisticData = true;
			setJosnObj("bid", data.i_bId);
			if (i_gameStatus != GAME_STATE_END) {
				joinRoom(HuPuRes.ROOM_NBA_BOXSCORE);
				bJoinRoom = true;
			} else {
				getBoxEndData = true;
			}

			if (isLandMode) {
				if (mDataLandAdapter == null)
					initLand();
				mDataLandAdapter.setData(mBoxscoreData);
			}

		} else if (methodId == HuPuRes.REQ_METHOD_GET_RECAP) {
			Recap data = (Recap) o;
			mFragmentReport.setData(data);
			bHasReportData = true;
		} else if (methodId == HuPuRes.REQ_METHOD_FOLLOW_GAME
				|| methodId == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL) {
			FollowResp resp = (FollowResp) o;
			if (resp == null || resp.i_success == 0) {
				// �ύʧ��
				showToast(String.format(SORRY_NOTIFY,
						mEntityGame.str_home_name, mEntityGame.str_away_name));
				isFollow = !isFollow;
				setFollowBtn();
			} else {
				if (isFollow)
					mEntityGame.i_isFollow = 1;
				else
					mEntityGame.i_isFollow = 0;
				if (methodId == HuPuRes.REQ_METHOD_FOLLOW_GAME)
					showToast(String.format(SUCCESS_NOTIFY,
							mEntityGame.str_home_name,
							mEntityGame.str_away_name));
				if (methodId == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL)
					showToast(CANCEL_NOTIFY);
			}

		} else if (methodId == HuPuRes.REQ_METHOD_SENT_CHAT) {
			SendMsgResp data = (SendMsgResp) o;
			if (data.err != null) {
				// Log.d("SendMsgResp", data.err);
				showToast(data.err);
			} else {
				mFragmentChat.setLastId(data.pid);
				lastChatID = data.pid;
				showToast("���ͳɹ�");
			}
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			cancelConnection();

			if (i_initFollow != mEntityGame.i_isFollow) {
				// System.out.println("onKeyDown pos "+i_pos);
				mIntent.putExtra("follow", mEntityGame.i_isFollow);
				mIntent.putExtra("date", mEntityGame.l_date_time);
				mIntent.putExtra("pos", i_pos);
				// setResult(RESULT_OK, mIntent);
			}
			// backToHome();
			finish();
		}
		return false;
	}

	private final int DIALOG_NOTIFY = 1314;

	@Override
	public void clickNegativeButton(int dialogId) {
		super.clickNegativeButton(dialogId);
		if (dialogId == DIALOG_NOTIFY) {
			if (mDialog != null)
				mDialog.cancel();
		}
	}

	@Override
	public void clickPositiveButton(int dialogId) {
		super.clickPositiveButton(dialogId);
		if (dialogId == DIALOG_NOTIFY) {
			// ��֪ͨ
			if (mDialog != null)
				mDialog.cancel();
			mApp.setNotify(true);
			followGame(mEntityGame.i_gId, (byte) 0);
			isFollow = !isFollow;
			setFollowBtn();
		}
	}

	private void setFollow() {
		if (isFollow) {

			followGame(mEntityGame.i_gId, (byte) 1);
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_UNFOLLOW);

		} else {
			if (mApp.needNotify) {
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_FOLLOW);
				followGame(mEntityGame.i_gId, (byte) 0);
			} else {
				showCustomDialog(DIALOG_NOTIFY, R.string.push_title,
						R.string.push_open_notify, 3, R.string.open_notify,
						R.string.cancel);
				return;
			}
		}
		// �����޸�
		isFollow = !isFollow;
		setFollowBtn();
	}

	@Override
	public void onErrResponse(Throwable error, String content) {

		super.onErrResponse(error, content);

	}

	private void setJosnObj(String key, int value) {
		JSONObject obj = getRoomObj();
		try {
			obj.put(key, value);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setJosnObj(String key, String value) {
		JSONObject obj = getRoomObj();
		try {
			obj.put(key, value);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/** ����Http���� */
	private void reqHttp(int repType) {

		sendRequest(repType, mParams, new HupuHttpHandler(this));
	}

	/** ֱ������������ˢ���������¼���room */
	public void reqFresh() {
		if (bJoinRoom && getRoom() != null)
			joinRoom();
		//
		mFragmentLive.stopLoad();
		MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_PLAY,
				HuPuRes.UMENG_KEY_REFRESH);
	}

	@Override
	protected void onStop() {
		super.onStop();
		// leaveRoom();
	}

	/** ���ݲ�ͬ�ı���״̬���л���ͬ����ʾ��ʽ */
	private void setViewByStatus(boolean init) {

		if (i_gameStatus != GAME_STATE_NOT_START) {
			// findViewById(R.id.layout_bottom).setVisibility(View.VISIBLE);
			// findViewById(R.id.txt_no_data).setVisibility(View.GONE);
			mFragmentLive.isStart(true);
		}
		if (i_gameStatus == GAME_STATE_END) {
			btnFirst.setVisibility(View.VISIBLE);
			leaveRoom();
			bJoinRoom = false;
			i_liveIndex = R.id.btn_third;
			i_staticIndex = R.id.btn_second;
			btnSecond.setImageResource(R.drawable.btn_statistics);
			btnThird.setImageResource(R.drawable.btn_live);
			if (!init)
				setBackgound(curIndex);
			setScreenLight(false);// game over

		} else if (i_gameStatus == GAME_STATE_ONGOING
				|| i_gameStatus == GAME_STATE_NOT_START) {
			i_liveIndex = R.id.btn_second;
			i_staticIndex = R.id.btn_third;
			btnSecond.setImageResource(R.drawable.btn_live_hover);

			btnThird.setImageResource(R.drawable.btn_statistics);
			if (i_gameStatus == GAME_STATE_ONGOING && !init) {
				mLayoutScore.setVisibility(View.VISIBLE);
				setSore(mEntityGame.i_home_score, mEntityGame.i_away_score);
				txtStartTime.setVisibility(View.GONE);
				txtTime.setText(mEntityGame.str_process);
				// mPager.setCurrentItem(INDEX_LIVE, false);
				switchFragment(INDEX_LIVE);
				setBackgound(INDEX_LIVE);
				setScreenLight(true);
			}
			if (i_gameStatus == GAME_STATE_NOT_START) {
				//
				btnThird.setVisibility(View.GONE);
			} else {
				btnThird.setVisibility(View.VISIBLE);
			}
		}
	}

	/** �����İ�ť�����仯 */
	private void setBackgound(int index) {
		int color = getResources().getColor(R.color.transform);
		switch (curIndex) {// ���ǰ
		case INDEX_REPORT:
			btnFirst.setBackgroundColor(color);
			btnFirst.setImageResource(R.drawable.btn_report);
			break;
		case INDEX_LIVE:
			if (i_liveIndex == R.id.btn_second)// ������
			{
				btnSecond.setBackgroundColor(color);
				btnSecond.setImageResource(R.drawable.btn_live);
			} else {
				btnThird.setBackgroundColor(color);
				btnThird.setImageResource(R.drawable.btn_live);
			}
			break;
		case INDEX_STATISTIC:
			if (i_staticIndex == R.id.btn_second) {
				btnSecond.setBackgroundColor(color);
				btnSecond.setImageResource(R.drawable.btn_statistics);
			} else {
				btnThird.setBackgroundColor(color);
				btnThird.setImageResource(R.drawable.btn_statistics);
			}
			findViewById(R.id.btn_land).setVisibility(View.GONE);
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
			break;
		case INDEX_CHAT:
			btnChat.setBackgroundColor(color);
			btnChat.setImageResource(R.drawable.btn_chat);
			findViewById(R.id.btn_sent).setVisibility(View.GONE);
			break;
		}

		switch (index) {// �����
		case INDEX_REPORT:
			mLayoutScoreBar.setVisibility(View.GONE);
			btnFirst.setBackgroundResource(R.drawable.btn_bg_bottom);
			btnFirst.setImageResource(R.drawable.btn_report_hover);
			break;
		case INDEX_LIVE:
			mLayoutScoreBar.setVisibility(View.VISIBLE);
			if (i_liveIndex == R.id.btn_second) {
				btnSecond.setBackgroundResource(R.drawable.btn_bg_bottom);
				btnSecond.setImageResource(R.drawable.btn_live_hover);
			} else {
				btnThird.setBackgroundResource(R.drawable.btn_bg_bottom);
				btnThird.setImageResource(R.drawable.btn_live_hover);
			}
			if (i_gameStatus == GAME_STATE_ONGOING
					|| i_gameStatus == GAME_STATE_NOT_START) {
				findViewById(R.id.layout_title_btn).setVisibility(View.VISIBLE);
			}
			break;
		case INDEX_STATISTIC:
			mLayoutScoreBar.setVisibility(View.VISIBLE);
			if (i_staticIndex == R.id.btn_second) {
				btnSecond.setBackgroundResource(R.drawable.btn_bg_bottom);
				btnSecond.setImageResource(R.drawable.btn_statistics_hover);
			} else {
				btnThird.setBackgroundResource(R.drawable.btn_bg_bottom);
				btnThird.setImageResource(R.drawable.btn_statistics_hover);
			}
			findViewById(R.id.btn_land).setVisibility(View.VISIBLE);
			findViewById(R.id.layout_title_btn).setVisibility(View.GONE);
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			break;
		case INDEX_CHAT:
			mLayoutScoreBar.setVisibility(View.VISIBLE);
			btnChat.setBackgroundResource(R.drawable.btn_bg_bottom);
			btnChat.setImageResource(R.drawable.btn_chat_hover);
			findViewById(R.id.layout_title_btn).setVisibility(View.GONE);
			findViewById(R.id.btn_sent).setVisibility(View.VISIBLE);
			break;
		}
	}

	/**
	 * �Ƿ�Ϊ��ע�������ñ�������ʱ���ã���Ϊ��ע��ȡ����������ʱ������ֻ�����ݳɹ����غ󣬲�����ʵ����� ����ʧ�ܣ��������
	 */
	private boolean isFollow;
	private CharSequence title;

	@Override
	public void treatClickEvent(int id) {
		super.treatClickEvent(id);
		UMENG_MAP.clear();
		if (id == i_liveIndex) {
			if (curIndex != INDEX_LIVE) {
				txtTitle.setText(R.string.title_live);
				title = txtTitle.getText();
				setBackgound(INDEX_LIVE);
				// mPager.setCurrentItem(INDEX_LIVE, true);
				switchFragment(INDEX_LIVE);
				if (!bHasLiveData || (bEnd && !getLiveEndData)) {
					// ���ν����ҳ����Ҫ��ȡȫ����ʵʱ������Ϣ
					if (i_gameStatus == GAME_STATE_ONGOING)// ������
					{
						mParams.put("sort", "desc");
						reqHttp(HuPuRes.REQ_METHOD_GET_PLAY_LIVE_DESC);
					} else {
						mParams.put("sort", "asc");
						reqHttp(HuPuRes.REQ_METHOD_GET_PLAY_LIVE_ASC);
					}
				} else if (i_gameStatus != GAME_STATE_END) {
					bJoinRoom = true;
					// ����ǰ�������һ����Ϣid
					setJosnObj(BaseEntity.KEY_PID, lastLiveID);
					joinRoom(HuPuRes.ROOM_PLAYBYPLAY);
				}
				UMENG_MAP.put("tab", "playbyplay");
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_TAP_TAB,
						UMENG_MAP);
			}
			curIndex = INDEX_LIVE;

		} else if (id == i_staticIndex) {
			if (curIndex != INDEX_STATISTIC) {
				txtTitle.setText(R.string.title_statistic);
				title = txtTitle.getText();
				// mPager.setCurrentItem(INDEX_STATISTIC, true);
				switchFragment(INDEX_STATISTIC);
				if (!bHasStatisticData || (bEnd && !getBoxEndData))
					reqHttp(HuPuRes.REQ_METHOD_BOX_SCORE);
				else if (i_gameStatus != GAME_STATE_END) {
					joinRoom(HuPuRes.ROOM_NBA_BOXSCORE);
					bJoinRoom = true;
				}
				setBackgound(INDEX_STATISTIC);

				UMENG_MAP.put("tab", "boxscore");
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_TAP_TAB,
						UMENG_MAP);

				findViewById(R.id.btn_land).setVisibility(View.VISIBLE);
				if (i_gameStatus == GAME_STATE_ONGOING
						|| i_gameStatus == GAME_STATE_NOT_START)
					findViewById(R.id.layout_title_btn)
							.setVisibility(View.GONE);
				// mFragmentStatistic.entry();
			}
			curIndex = INDEX_STATISTIC;
		}

		switch (id) {
		case R.id.btn_first:
			if (curIndex != INDEX_REPORT) {
				txtTitle.setText(R.string.title_report);
				title = txtTitle.getText();
				// mPager.setCurrentItem(INDEX_REPORT, true);
				switchFragment(INDEX_REPORT);
				if (bMatchDay || !bHasReportData)
					reqHttp(HuPuRes.REQ_METHOD_GET_RECAP);
				setBackgound(INDEX_REPORT);
				UMENG_MAP.put("tab", "playbyplay");
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_TAP_TAB,
						UMENG_MAP);
			}
			curIndex = INDEX_REPORT;
			break;
		case R.id.btn_chat:
			if (curIndex != INDEX_CHAT) {
				txtTitle.setText(R.string.title_chat);
				title = txtTitle.getText();
				// mPager.setCurrentItem(INDEX_REPORT, true);
				switchFragment(INDEX_CHAT);
				setBackgound(INDEX_CHAT);
				UMENG_MAP.put("tab", "chat");
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_GAME_TAP_TAB,
						UMENG_MAP);
				mFragmentChat.reqNewDataDelay(false);
				bJoinRoom = true;
				// һֱ����
				setScreenLight(true);
			}
			curIndex = INDEX_CHAT;
			break;
		case R.id.btn_back:
			finish();
			break;
		case R.id.btn_follow:
			setFollow();
			break;
		case R.id.btn_play:
			if (movieUrl == null || movieUrl.equals(""))
				showToast("������Ƶֱ��");
			else {
				Intent in = new Intent(this, WebViewActivity.class);
				in.putExtra("url", movieUrl);
				startActivity(in);
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_TV_OPEN);
			}
			break;
		case R.id.btn_home_land:
			if (mDataLandAdapter != null) {
				mDataLandAdapter.changeMode(0);
				if (mDataLandAdapter.getCount() > 0)
					mListLandPlayer.setSelection(0);
			}
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			btnHome.setBackgroundColor(clrOn);
			btnAway.setBackgroundColor(clrOff);
			if(txtTeamName!=null && mEntityGame!=null&&mEntityGame.str_home_name!=null)
				txtTeamName.setText(mEntityGame.str_home_name);
			break;
		case R.id.btn_away_land:
			if (mDataLandAdapter != null) {
				mDataLandAdapter.changeMode(1);
				if (mDataLandAdapter.getCount() > 0)
					mListLandPlayer.setSelection(0);
			}
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			btnHome.setBackgroundColor(clrOff);
			btnAway.setBackgroundColor(clrOn);
			if(txtTeamName!=null && mEntityGame!=null&&mEntityGame.str_away_name!=null)
				txtTeamName.setText(mEntityGame.str_away_name);
			break;
		case R.id.btn_land:
			// setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
			// switchToLandMode();
			// showToast("��ת�鿴");
			showTipsDialog();
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_TIPS,
					HuPuRes.UMENG_KEY_GAMEBOX_H2V);
			break;
		case R.id.btn_close:
			closeDialog();
			break;
		case R.id.btn_sent:
			Intent in = new Intent(this, ChatInputActivity.class);
			startActivityForResult(in, REQ_SEND_MSG);

			break;
		}
	}

	private static final int REQ_SEND_MSG = 1000;
	Dialog mTipsDialog;

	/** ��ʾһ��dialog�������û����Է�ת��Ļʹ�� */
	private void showTipsDialog() {
		View v = LayoutInflater.from(this).inflate(R.layout.dialog_rotation,
				null);
		v.findViewById(R.id.btn_close).setOnClickListener(click);

		mTipsDialog = new Dialog(this, R.style.MyDialog);

		mTipsDialog.setContentView(v);
		int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.9);
		int h = (int) (getResources().getDisplayMetrics().density * 330);
		mTipsDialog.getWindow().setLayout(w, h);
		mTipsDialog.show();
	}

	/** �رո�dialog */
	private void closeDialog() {
		if (mTipsDialog != null && mTipsDialog.isShowing()) {
			mTipsDialog.dismiss();
			mTipsDialog = null;
		}

	}

	/** ������ӱȷ� ��Ҫ���ƣ�����߼�����Ҫ���жϱȷֵı任�ˡ� */
	private void setSore(int homeScore, int awayScore) {
		if (homeScore < 0)
			return;
		int hundred = homeScore / 100;
		int tens = (homeScore % 100) / 10;
		int single = homeScore % 10;

		if (hundred > 0) {
			txtHomeScore1.setVisibility(View.VISIBLE);
			txtHomeScore1.setBackgroundResource(num_res[hundred]);
		} else
			txtHomeScore1.setVisibility(View.GONE);
		if (homeScore >= 10) {
			txtHomeScore2.setVisibility(View.VISIBLE);
			txtHomeScore2.setBackgroundResource(num_res[tens]);
		} else
			txtHomeScore2.setVisibility(View.GONE);
		txtHomeScore3.setBackgroundResource(num_res[single]);

		hundred = awayScore / 100;
		tens = (awayScore % 100) / 10;
		single = awayScore % 10;
		if (hundred > 0) {
			txtAwayScore1.setVisibility(View.VISIBLE);
			txtAwayScore1.setBackgroundResource(num_res[hundred]);
		} else
			txtAwayScore1.setVisibility(View.GONE);
		if (awayScore >= 10) {
			txtAwayScore2.setVisibility(View.VISIBLE);
			txtAwayScore2.setBackgroundResource(num_res[tens]);
		} else
			txtAwayScore2.setVisibility(View.GONE);
		txtAwayScore3.setBackgroundResource(num_res[single]);

	}

	/** ���±������̵ı�����Ϣ */
	private void updateProccess(String s) {
		if (s != null)
			txtTime.setText(s);
	}

	/** �����������ݣ�ÿҳ20�� */
	public void reqChatData(int id) {

		setJosnObj("type", "nba");
		setJosnObj("num", 20);
		if (id > 0) {
			setJosnObj("pid", id);
			setJosnObj("direc", "prev");

		} else {
			// ���»�ȡ���µ������¼������ƫ����
			setJosnObj("pid", "");
			setJosnObj("direc", "next");

		}
		joinRoom(HuPuRes.ROOM_NBA_CHAT);
	}

	@Override
	public void onSocketConnect() {
		// Log.d("HupuDataActivity", "onSocketConnect  >>>>>>:::::");
		super.onSocketConnect();
		// ���ӳɹ��ˣ�����room��
		joinRoom();
		mApp.setNetState(HuPuApp.STATE_CONNECTED);
		setNetTitle();
	}

	@Override
	public void onSocketDisconnect() {
		// Log.d("HupuDataActivity", "onSocketDisconnect  >>>>>>:::::"
		// + android.os.Process.myPid());
		super.onSocketDisconnect();
		mApp.setNetState(HuPuApp.STATE_DISCONNECT);
		setNetTitle();
		if (bJoinRoom)
			reconnect(false);
		updateNetState();
	}

	@Override
	public void onSocketError(SocketIOException socketIOException) {
		// Log.d("HupuDataActivity", "onSocketError  >>>>>>:::::"
		// + socketIOException.toString());
		super.onSocketError(socketIOException);

		if (curIndex == INDEX_LIVE) {
			mFragmentLive.stopLoad();
		} else if (curIndex == INDEX_CHAT) {
			mFragmentChat.stopLoad();
		}
		mApp.setNetState(HuPuApp.STATE_NET_ERR);
		setNetTitle();
		reconnect(false);

	}

	@Override
	public void onSocketResp(JSONObject obj) {
		// Log.d("HupuDataActivity", "onSocketResp  >>>>>>:::::");

		if (obj != null) {
			try {
				String room = obj.optString("room");
				int status = obj.optInt(BaseEntity.KEY_STATUS, -1);
				// Log.d("HupuDataActivity", "onSocketResp  >>>>>>::::: status"
				// + status);
				if (status > -1 && status != i_gameStatus) {
					i_gameStatus = status;
					setViewByStatus(false);

				}

				if (HuPuRes.ROOM_NBA_BOXSCORE.equals(room)) {
					if (i_gameStatus == GAME_STATE_END) {
						bEnd = true;
						getBoxEndData = true;
					}
					// ͳ��
					BoxScoreResp data = new BoxScoreResp();
					data.paser(obj);
					int bid = obj.optInt("bid", -1);
					// ������Ϣid
					if (bid > 0)
						setJosnObj("bid", bid);
					setSore(data.i_scoreHome, data.i_scoreAway);
					updateProccess(data.str_process);
					mFragmentStatistic.updateData(data);

					mFragmentStatistic.updateBoxScoreData(mBoxscoreData);
					if (isLandMode)
						mDataLandAdapter.setData(mBoxscoreData);

				} else if (HuPuRes.ROOM_PLAYBYPLAY.equals(room)) {
					if (i_gameStatus == GAME_STATE_END) {
						bEnd = true;
						getLiveEndData = true;
					}

					// ����
					LiveResp data = new LiveResp();
					data.paser(obj);
					
					// Log.d("socket back pid", "" + data.i_pId);
					// Log.d("ROOM_PLAYBYPLAY", "size="+data.mListDel.size());
					// mFragmentLive.appendData(data.dataList);
					if (curIndex == INDEX_LIVE && data.people_num != null)
						txtTitle.setText("ֱ��(" + data.people_num + "��)");
					mFragmentLive.stopLoad();
					if (data.bHasData) {
						if (lastLiveID != data.i_pId && data.i_pId > -1)
							mFragmentLive.updateData(data);
					}
					if (data.i_pId > -1) {
						lastLiveID = data.i_pId;
						// ������Ϣid
						setJosnObj(BaseEntity.KEY_PID, data.i_pId);
					}
					setSore(data.i_scoreHome, data.i_scoreAway);
					updateProccess(data.str_process);

				} else if (HuPuRes.ROOM_NBA_CHAT.equals(room)) {
					ChatResp data = new ChatResp();
					data.paser(obj);
					mFragmentChat.stopLoad();
					if (data.mList != null) {
						mFragmentChat.setData(data);
					}
					lastChatID = mFragmentChat.getLastId();
					if (curIndex == INDEX_CHAT && data.online != null)
						txtTitle.setText("����(" + data.online + "��)");
					setSore(data.i_scoreHome, data.i_scoreAway);
					updateProccess(data.str_process);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		mApp.setNetState(HuPuApp.STATE_ON_LINE);
		setNetTitle();
	}

	/** ����ʱͳ���б��ı��� **/
	private TextView[] txtHeaders;
	/** ����ʱͳ���б� **/
	private ListView mListLandPlayer;
	/** ����ʱͳ���б��������� **/
	private GameDataListLandAdapter mDataLandAdapter;
	/** ����ʱ�������� **/
	TextView txtHome;
	/** ����ʱ�Ͷ��� **/
	TextView txtAway;
	/** ����ʱ����logo **/
	ImageView imgHome;
	/** ����ʱ�Ͷ�logo **/
	ImageView imgAway;
	/** ����ʱ���ӷָ��� **/
	View lineHome;
	/** ����ʱ�Ͷӷָ��� **/
	View lineAway;
	/** ����ʱ���Ӱ�ť **/
	View btnHome;
	/** ����ʱ�ͶӰ�ť **/
	View btnAway;

	/** ����ʱ�б������������ **/
	private TextView txtTeamName;
	/** ��ɫֵ **/
	private int clrOn;

	private int clrOff;

	/** Ϊ�˴�����Ļ��ת�¼� */
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// Log.d("onConfigurationChanged", "ORIENTATION=" +
		// newConfig.orientation);
		super.onConfigurationChanged(newConfig);
		switch (newConfig.orientation) {
		case Configuration.ORIENTATION_PORTRAIT:
			// taking action on event
			lockScreenRotation(Configuration.ORIENTATION_PORTRAIT);
			// Log.d("onConfigurationChanged", "ORIENTATION_PORTRAIT");
			break;
		case Configuration.ORIENTATION_LANDSCAPE:
			// taking action on event
			lockScreenRotation(Configuration.ORIENTATION_LANDSCAPE);
			// Log.d("onConfigurationChanged", "ORIENTATION_LANDSCAPE");
			break;
		case Configuration.ORIENTATION_SQUARE:
			// taking action on event
			lockScreenRotation(Configuration.ORIENTATION_SQUARE);
			// Log.d("onConfigurationChanged", "ORIENTATION_SQUARE");
			break;
		}

	}

	private int getOrientation() {
		// ͨ��Configuration���� ȷ�ϵ�ǰ��ʾ����
		Configuration conf = getResources().getConfiguration();
		return conf.orientation;
	}

	/** �ô��봦����Ļ��ת���߼� */
	private void lockScreenRotation(int orientation) {
		// Stop the screen orientation changing during an event
		switch (orientation) {

		case Configuration.ORIENTATION_PORTRAIT:
			// setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
			if (isLandMode) {
				switchToPortraitMode();
				// setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			}
			break;
		case Configuration.ORIENTATION_LANDSCAPE:
			if (curIndex == INDEX_STATISTIC) {
				if (!isLandMode) {
					switchToLandMode();
					MobclickAgent.onEvent(this,
							HuPuRes.UMENG_KEY_GAMEBOX_SCORE,
							HuPuRes.UMENG_KEY_V2H);
				}
				setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			}
			break;
		default:
			this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
			break;
		}
	}

	/** �л���ˮƽģʽ **/
	private void switchToLandMode() {
		isLandMode = true;
		vPortrait.setVisibility(View.GONE);
		vLandscape.setVisibility(View.VISIBLE);
		closeDialog();

		if (txtHome == null) {
			txtHome = (TextView) findViewById(R.id.txt_home_land);

			txtAway = (TextView) findViewById(R.id.txt_away_land);

			imgHome = (ImageView) findViewById(R.id.img_home_land);
			imgAway = (ImageView) findViewById(R.id.img_away_land);
			btnHome = findViewById(R.id.btn_home_land);
			btnAway = findViewById(R.id.btn_away_land);
			setOnClickListener(R.id.btn_home_land);
			setOnClickListener(R.id.btn_away_land);

			txtHome.setText(mEntityGame.str_home_name);
			txtAway.setText(mEntityGame.str_away_name);
			lineHome = findViewById(R.id.line_home);
			lineAway = findViewById(R.id.line_away);
			lineHome.setBackgroundColor(HuPuApp
					.getTeamData(mEntityGame.i_home_tid).i_color);
			lineAway.setBackgroundColor(HuPuApp
					.getTeamData(mEntityGame.i_away_tid).i_color);

			imgHome.setBackgroundResource(HuPuApp
					.getTeamData(mEntityGame.i_home_tid).i_logo);
			imgAway.setBackgroundResource(HuPuApp
					.getTeamData(mEntityGame.i_away_tid).i_logo);

			clrOn = getResources().getColor(R.color.dark_gray);
			clrOff = getResources().getColor(R.color.list_item_bg);

		}
		if (txtHeaders == null)
			initLand();
		if (mBoxscoreData != null) {
			mDataLandAdapter.setData(mBoxscoreData);
		}

		setFullScreen();
	}

	/** ͳ������ **/
	public BoxscoreDatas mBoxscoreData;

	/** �л�����ֱģʽ **/
	public static class BoxscoreDatas {
		public LinkedList<PlayerEntity> mListPLay;
		public LinkedList<String> mListPLayerNames;
		public LinkedList<String> mListKeys;
		public LinkedList<String> mTitles;
		public int i_homeSize;

		public LinkedHashMap<String, String> mMapHomeTotal;

		public LinkedHashMap<String, String> mMapAwayTotal;
		// ����������
		public String str_home_fg;
		public String str_home_tp;
		public String str_home_ft;
		// �Ͷ�������
		public String str_away_fg;
		public String str_away_tp;
		public String str_away_ft;

	}

	/** ��ʼ��ˮƽ״̬��һЩview **/
	private void initLand() {
		// if (curIndex == INDEX_STATISTIC) {
		// findViewById(R.id.btn_land).setVisibility(View.VISIBLE);
		// findViewById(R.id.layout_title_btn).setVisibility(View.GONE);
		// } else {
		// findViewById(R.id.btn_land).setVisibility(View.GONE);
		// findViewById(R.id.layout_title_btn).setVisibility(View.VISIBLE);
		// }
		if (txtHeaders == null && mBoxscoreData != null) {
			txtTeamName = (TextView) findViewById(R.id.txt_name_land);
			LinearLayout headView = (LinearLayout) findViewById(R.id.layout_header_land);
			headView.setVisibility(View.VISIBLE);
			txtHeaders = new TextView[mBoxscoreData.mListKeys.size()];
			LinearLayout.LayoutParams llp = null;
			LayoutInflater in = LayoutInflater.from(this);
			String key = null;
			for (int i = 0; i < txtHeaders.length; i++) {
				View title = in.inflate(R.layout.static_header_land, null);

				txtHeaders[i] = (TextView) title
						.findViewById(R.id.txt_title_land);
				txtHeaders[i].setText(mBoxscoreData.mTitles.get(i));
				key = mBoxscoreData.mListKeys.get(i);
				// ������
				if (key.equals("fg") || key.equals("ft") || key.equals("tp"))
					llp = new LinearLayout.LayoutParams(0, -1, 10);
				else if (key.equals("mins") || key.equals("pts"))
					llp = new LinearLayout.LayoutParams(0, -1, 7);
				else
					llp = new LinearLayout.LayoutParams(0, -1, 5);
				headView.addView(title, llp);
			}
			mListLandPlayer = (ListView) findViewById(R.id.list_players_land);
			mDataLandAdapter = new GameDataListLandAdapter(this);
			mListLandPlayer.setAdapter(mDataLandAdapter);
			txtTeamName.setText(mEntityGame.str_home_name);
		}
	}

	/** �л�����ֱģʽ **/
	private void switchToPortraitMode() {

		isLandMode = false;
		vPortrait.setVisibility(View.VISIBLE);
		vLandscape.setVisibility(View.GONE);

		quitFullScreen();
	}

	/** ����Ϊȫ�� **/
	private void setFullScreen() {
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().getDecorView().invalidate();
	}

	/** �˳�ȫ��ģʽ **/
	private void quitFullScreen() {
		final WindowManager.LayoutParams attrs = getWindow().getAttributes();
		attrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setAttributes(attrs);
		getWindow()
				.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
	}

	/** ���Ƽ����� */
	class MyGestureDetector extends SimpleOnGestureListener {

		private static final int SWIPE_MIN_DISTANCE = 50;
		private static final int SWIPE_MAX_OFF_PATH = 250;
		private static final int SWIPE_THRESHOLD_VELOCITY = 60;

		// Touch�˻���һ������upʱ����
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {
			// Log.i("MyGesture", "onFling");
			if (e2 == null) {
				// Log.i("MyGesture", "e2==null");
				return false;
			}
			if (e1 == null) {

				return false;
			}

			if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
					&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
				mFragmentStatistic.showNextPage();
				return true;

			} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
					&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
				mFragmentStatistic.showPrePage();
				return true;
			}
			return super.onFling(e1, e2, velocityX, velocityY);

		}

		/*
		 * ��������������Touch Down����û�л���(onScroll)����û�г���(onLongPress)��Ȼ��Touch Upʱ����
		 * ���һ�·ǳ����(������)Touch Up: onDown->onSingleTapUp->onSingleTapConfirmed
		 * ���һ����΢�����(������)Touch Up:
		 * onDown->onShowPress->onSingleTapUp->onSingleTapConfirmed
		 */
		public boolean onSingleTapConfirmed(MotionEvent e) {
			// TODO Auto-generated method stub
			return super.onSingleTapConfirmed(e);
		}

		// ˫���ĵڶ���Touch downʱ����
		public boolean onDoubleTap(MotionEvent e) {
			// Log.i("MyGesture", "onDoubleTap");
			return super.onDoubleTap(e);
		}

		// ˫���ĵڶ���Touch down��up���ᴥ��������e.getAction()����
		public boolean onDoubleTapEvent(MotionEvent e) {
			// Log.i("MyGesture", "onDoubleTapEvent");
			return super.onDoubleTapEvent(e);
		}

		// Touch downʱ����
		public boolean onDown(MotionEvent e) {
			// Log.i("MyGesture", "onDown");
			return super.onDown(e);
		}

		// Touch�˲��ƶ�һֱTouch downʱ����
		public void onLongPress(MotionEvent e) {
			// Log.i("MyGesture", "onLongPress");
			super.onLongPress(e);
		}

		// Touch�˻���ʱ����
		public boolean onScroll(MotionEvent e1, MotionEvent e2,
				float distanceX, float distanceY) {
			// Log.i("MyGesture", "onScroll");
			return super.onScroll(e1, e2, distanceX, distanceY);
		}

		/*
		 * Touch�˻�û�л���ʱ���� (1)onDownֻҪTouch Downһ�����̴��� (2)Touch
		 * Down���һ��û�л����ȴ���onShowPress�ٴ���onLongPress So: Touch Down��һֱ��������onDown
		 * -> onShowPress -> onLongPress���˳�򴥷���
		 */
		public void onShowPress(MotionEvent e) {
			// Log.i("MyGesture", "onShowPress");
			super.onShowPress(e);
		}

		public boolean onSingleTapUp(MotionEvent e) {
			// Log.i("MyGesture", "onSingleTapUp");
			return super.onSingleTapUp(e);
		}
	}

	DecimalFormat df = new DecimalFormat("0.0");

	private String getPeopleNum(int p) {
		if (p < 10000)
			return "" + p;
		else {
			return df.format((float) p / 10000) + "��";
		}
	}
}
