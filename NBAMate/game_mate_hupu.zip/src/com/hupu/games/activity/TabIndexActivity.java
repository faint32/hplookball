package com.hupu.games.activity;

import io.socket.SocketIOException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.adapter.HupuPagerAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.CBAResp;
import com.hupu.games.data.FollowResp;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.data.JsonPaserFactory;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.fragment.CBAGameFragment;
import com.hupu.games.fragment.NbaGameHomeFragment;
import com.hupu.games.fragment.NewsFragment;
import com.hupu.games.fragment.StandingFragment;
import com.hupu.games.fragment.VideoFragment;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.view.HupuViewPager;
import com.pyj.common.DeviceInfo;
import com.pyj.common.DialogRes;
import com.pyj.common.MyUtility;
import com.pyj.http.AsyncHttpResponseHandler;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.NotificationType;
import com.umeng.fb.UMFeedbackService;
import com.umeng.update.UmengUpdateAgent;

/** ������ҳ */
public class TabIndexActivity extends HupuBaseActivity {

	/** �����б�ҳ */
	private NbaGameHomeFragment indexFragment;
	/** ����ҳ�� */
	private StandingFragment standingFragment;
	/** ��Ƶҳ�� */
	private VideoFragment videoFragment;

	/** ��Ƶҳ�� */
	private NewsFragment newsFragment;

	/** ��Ƶҳ�� */
	private CBAGameFragment cbaFragment;
	
	
	/** ��ǰ����ı��������� */
	private long l_curDay;

	/** ����ı����б��Ķ��У���Ҫ�������ظ�����ͬһ��ı��� */
	private ArrayList<String> mListReqQue;
	/** �����ǲ��Ǳ����� */
	private boolean bMatchDay;

	/** �л���ֱ��ҳ��ʱ����Ҫ�õ�һЩ�������� */
	private final static int REQ_LIVE = 10;

	/** ������ť */
	private ImageButton mBtnGame;
	/** ���а�ť */
	private ImageButton mBtnStanding;
	/** ��Ƶҳ�� */
	private ImageButton mBtnVido;

	private ImageButton mBtnNews;

	private ImageButton mBtnCBA;
	
	HupuPagerAdapter mPageAdapter;

	HupuViewPager mPager;

	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"yyyy-MM-dd", java.util.Locale.CHINESE);

	private static String SORRY_NOTIFY = "��Ǹ��%s vs %s��������ʧ��";

	private static String SUCCESS_NOTIFY = "�������óɹ����������յ�%s vs %s������֪ͨ";

	private static String CANCEL_NOTIFY = "����ȡ���ɹ�";

	private int curFrame;

	private final static int FRAME_GAMES = 0;
	private final static int FRAME_STANDINGS = 3;
	private final static int FRAME_VIDEO = 2;
	private final static int FRAME_NEWS = 1;
	private final static int FRAME_CBA =4;
	boolean bShowQuit;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		if (savedInstanceState != null)
			savedInstanceState.clear();
		super.onCreate(savedInstanceState);

		setContentView(R.layout.layout_tab_index);
		UmengUpdateAgent.update(this);
		Intent in = getIntent();
		if (in.getBooleanExtra("click", false)) {
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NOTIFICATION_CLICK);
		}
		init();
		UMFeedbackService.enableNewReplyNotification(this, NotificationType.AlertDialog);
	}



	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onResume() {

		super.onResume();

		if (bMatchDay)
			joinRoom();
		// ������������ӹ�ע������ÿ�ζ��������������ݡ�
		req(l_curDay, 0);
		MobclickAgent.onResume(this);
	}

	@Override
	public void onCancelDialog(int dialogId) {
		super.onCancelDialog(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			bShowQuit = false;
	}

	@Override
	public void clickNegativeButton(int dialogId) {
		super.clickNegativeButton(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			bShowQuit = false;
	}

	@Override
	public void clickPositiveButton(int dialogId) {
		super.clickPositiveButton(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			quit();
	}

	/** ������������ */
	private void reqStandings() {
		initParameter();
		sendRequest(HuPuRes.REQ_METHOD_GET_STANDINGS, mParams,
				new HupuHttpHandler(this));
	}

	/** ������Ƶ���� */
	public void reqVideoData(int reqid, long vid, String type) {
		initParameter();
		mParams.put("type", type);
		if (vid > 0)
			mParams.put("vid", "" + vid);
		switch (reqid) {
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
			mParams.put("direc", "next");
			break;
		}
		sendRequest(reqid, mParams, new HupuHttpHandler(this));
	}
	/** ������������ */
	public void reqNewsData(int reqId, long nId) {
		initParameter();
		if (nId > 0)
			mParams.put("nid", "" + nId);
		switch (reqId) {
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT:
			mParams.put("direc", "next");
			break;
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_PRE:
			mParams.put("direc", "prev");
			break;
		}
		sendRequest(reqId, mParams, new HupuHttpHandler(this));
	}

	public void reqCBA(int reqId,int round)
	{
		initParameter();
		if(round>0)
			mParams.put("round", ""+round);
		sendRequest(reqId, mParams, new HupuHttpHandler(this));
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQ_LIVE) {
			if (resultCode == RESULT_OK) {

				long date = data.getLongExtra("date", 0);
				int pos = data.getIntExtra("pos", 0);
				int follow = data.getIntExtra("follow", 0);
				indexFragment.updateFollow(date, pos, follow);
			}
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if (!bShowQuit) {
				showDialog(DialogRes.DIALOG_QUIT_PROMPT);
				bShowQuit = true;
				return true;
			}
		}
		return false;
	}

	/**
	 * ����http�����б�����
	 * */
	public void req(long date, int direct) {
		if (mListReqQue.contains(date + ""))
			return;
		int reqType;
		initParameter();
		// ����ʱ����Ϣ��ȡ���һ�����Ϣ
		if (date > 0) {
			l_curDay = date;
			mParams.put(BaseEntity.KEY_DATE, "" + date);
			if (direct > 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_NEXT);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT;
			} else if (direct < 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_PREV);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE;
			} else
				reqType = HuPuRes.REQ_METHOD_GAMES_BY_DATE;
		} else
			reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER;
		// mParams.put(BaseEntity.KEY_DATE, "" + 1340294400);
		if (sendRequest(reqType, mParams, new HupuHttpHandler(this)))
			mListReqQue.add(date + "");
		else
			mListReqQue.clear();
	}

	/**
	 * ��ʼ��
	 * */
	private void init() {
		setRoomObj(HuPuRes.ROOM_NBA_HOME);
		mListReqQue = new ArrayList<String>();

		mBtnGame = (ImageButton) findViewById(R.id.btn_game);
		mBtnStanding = (ImageButton) findViewById(R.id.btn_standing);
		mBtnVido = (ImageButton) findViewById(R.id.btn_video);
		mBtnNews = (ImageButton) findViewById(R.id.btn_news);
		mBtnCBA = (ImageButton) findViewById(R.id.btn_cba);
		
		indexFragment = new NbaGameHomeFragment();
		standingFragment = new StandingFragment();
		videoFragment = new VideoFragment();
		newsFragment = new NewsFragment();
		cbaFragment =new CBAGameFragment();
		
		mPageAdapter = new HupuPagerAdapter(this);

		mPageAdapter.addFragment(indexFragment);
		mPageAdapter.addFragment(newsFragment);
		mPageAdapter.addFragment(videoFragment);
		mPageAdapter.addFragment(standingFragment);
		mPageAdapter.addFragment(cbaFragment);
		
		// mPageAdapter.addFragment();
		mPager = (HupuViewPager) findViewById(R.id.pager_parent);
		mPager.setOffscreenPageLimit(5);
		mPager.setAdapter(mPageAdapter);

		setOnClickListener(R.id.btn_game);
		setOnClickListener(R.id.btn_standing);
		setOnClickListener(R.id.btn_video);
		setOnClickListener(R.id.btn_news);
		setOnClickListener(R.id.btn_cba);
		//
		// setOnClickListener(R.id.btn_setup);

		HuPuRes.setClient(DeviceInfo.getDeviceInfo(getApplicationContext()));

		// mTabHost.setCurrentTab(0);
	}

	public void setOnClick(View v) {
		if (v != null)
			v.setOnClickListener(click);
	}

	/**
	 * �л�ҳ��
	 * */
	private void switchFrame(int frame) {
		int color = getResources().getColor(R.color.transform);
		if (frame == curFrame)
			return;
		switch (curFrame) {
		case FRAME_GAMES:
			mBtnGame.setImageResource(R.drawable.btn_game);
			mBtnGame.setBackgroundColor(color);
			break;
		case FRAME_STANDINGS:
			mBtnStanding.setImageResource(R.drawable.btn_standings);
			mBtnStanding.setBackgroundColor(color);
			break;
		case FRAME_VIDEO:
			mBtnVido.setImageResource(R.drawable.btn_video);
			mBtnVido.setBackgroundColor(color);
			break;
		case FRAME_NEWS:
			mBtnNews.setImageResource(R.drawable.btn_news);
			mBtnNews.setBackgroundColor(color);
			break;
		case FRAME_CBA:
			mBtnCBA.setImageResource(R.drawable.btn_cba);
			mBtnCBA.setBackgroundColor(color);		
			break;
		}
		curFrame = frame;
		switch (frame) {
		case FRAME_GAMES:
			mPager.setCurrentItem(FRAME_GAMES,false);
			mBtnGame.setImageResource(R.drawable.btn_game_hover);
			mBtnGame.setBackgroundResource(R.drawable.btn_bg_bottom);
			break;
		case FRAME_STANDINGS:
			mBtnStanding.setImageResource(R.drawable.btn_standings_hover);
			mBtnStanding.setBackgroundResource(R.drawable.btn_bg_bottom);
			mPager.setCurrentItem(FRAME_STANDINGS,false);
			reqStandings();
			break;
		case FRAME_VIDEO:
			mBtnVido.setImageResource(R.drawable.btn_video_hover);
			mBtnVido.setBackgroundResource(R.drawable.btn_bg_bottom);
			mPager.setCurrentItem(FRAME_VIDEO,false);
			videoFragment.entry();
			break;
		case FRAME_NEWS:
			mBtnNews.setImageResource(R.drawable.btn_news_hover);
			mBtnNews.setBackgroundResource(R.drawable.btn_bg_bottom);
			mPager.setCurrentItem(FRAME_NEWS,false);
			newsFragment.entry();
			break;
		case FRAME_CBA:
			mBtnCBA.setImageResource(R.drawable.btn_cba_hover);
			mBtnCBA.setBackgroundResource(R.drawable.btn_bg_bottom);
			mPager.setCurrentItem(FRAME_CBA,false);
			cbaFragment.entry();
			break;
		}

	}

	@Override
	public void treatClickEvent(int id) {
		super.treatClickEvent(id);
		switch (id) {
		case R.id.btn_follow:
			break;
		case R.id.btn_setup:
			Intent in = new Intent(this, SetupActivity.class);
			startActivity(in);
			break;
		case R.id.btn_game:
			if (curFrame != FRAME_GAMES) {
				switchFrame(FRAME_GAMES);
				MobclickAgent.onEvent(this,
						HuPuRes.UMENG_KEY_INDEX_TAB_ACTIONS,
						HuPuRes.UMENG_KEY_NBA_GAMES);
			}
			break;
		case R.id.btn_standing:
			if (curFrame != FRAME_STANDINGS) {
				switchFrame(FRAME_STANDINGS);

				MobclickAgent.onEvent(this,
						HuPuRes.UMENG_KEY_INDEX_TAB_ACTIONS,
						HuPuRes.UMENG_KEY_NBA_STANDINGS);
			}
			break;
		case R.id.btn_video:
			if (curFrame != FRAME_VIDEO) {
				switchFrame(FRAME_VIDEO);

				MobclickAgent.onEvent(this,
						HuPuRes.UMENG_KEY_INDEX_TAB_ACTIONS,
						HuPuRes.UMENG_KEY_VIDEO);
			}
			break;
		case R.id.btn_news:
			if (curFrame != FRAME_NEWS) {
				switchFrame(FRAME_NEWS);

				MobclickAgent.onEvent(this,
						HuPuRes.UMENG_KEY_INDEX_TAB_ACTIONS,
						HuPuRes.UMENG_KEY_NEWS);
			}
			break;
		case R.id.btn_cba:
			if (curFrame != FRAME_CBA) {
				switchFrame(FRAME_CBA);

				MobclickAgent.onEvent(this,
						HuPuRes.UMENG_KEY_INDEX_TAB_ACTIONS,
						HuPuRes.UMENG_KEY_CBA);
			}
		
			break;
		}

	}

	/**
	 * �л���ʵʱҳ��
	 * */
	public void switchToLive(GameEntity en, int pos) {
		HuPuApp.hasTeam(en.i_home_tid, en.str_home_name);
		HuPuApp.hasTeam(en.i_away_tid, en.str_away_name);
		Intent in = new Intent(this, HupuDataActivity.class);
		in.putExtra("game", en);
		in.putExtra("match", bMatchDay);
		in.putExtra("pos", pos);
		startActivityForResult(in, REQ_LIVE);
		// startActivity(in);
	}

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (o == null)
			return;
		switch (methodId) {
		case HuPuRes.REQ_METHOD_GET_STANDINGS:
			StandingsResp resp = (StandingsResp) o;
			standingFragment.setData(resp);
			return;
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
			videoFragment.stopLoad(false);
			if (o != null)
				videoFragment.setData(methodId, o);
			break;

		case HuPuRes.REQ_METHOD_GET_NBA_NEWS:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_PRE:
			newsFragment.stopLoad(false);
			if (o != null)
				newsFragment.setData(methodId, o);
			break;
		case HuPuRes.REQ_METHOD_CBA_NEXT:
		case HuPuRes.REQ_METHOD_CBA_PREV:
			
			cbaFragment.setData((CBAResp)o);
			break;
		default:
			// �����б�������
			GamesResp entity = null;
			entity = (GamesResp) o;
			indexFragment.setData(methodId, entity);
			if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER) {
				if(entity.redirectors!=null)
					mApp.setServer(entity.redirectors);
				if (bMatchDay = entity.isMatchDay) {
					joinRoom();// ����Ǳ����գ���ʼsocket����
					if (entity.mGameList.size() > 0
							&& entity.mGameList.get(0).byt_status == 2)
						setScreenLight(true);
					else
						setScreenLight(false);
				}
			} else {
				if (entity.mGameList != null) {
					mListReqQue
							.remove("" + entity.mGameList.get(0).l_date_time);
					// return;
				}
			}
			break;
		}

	}

	@Override
	public void onErrResponse(Throwable error, String content) {
		super.onErrResponse(error, content);
		mListReqQue.clear();

		if (curFrame == FRAME_VIDEO) {
			if (videoFragment != null)
				videoFragment.stopLoad(false);
		} else if (curFrame == FRAME_NEWS) {
			if (newsFragment != null)
				newsFragment.stopLoad(false);
		}
	}

	/** ��ע��ȡ������ */
	public void setFollowGame(GameEntity entity) {
		byte unFollow = (byte) (entity.i_isFollow > 0 ? 0 : 1);
		UMENG_MAP.clear();
		UMENG_MAP.put("date",
				MyUtility.getStartTime(entity.l_date_time * 1000, sdf));
		if (unFollow == 1) {
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_HOME_FOLLOW,
					UMENG_MAP);
		} else {
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_HOME_UNFOLLOW,
					UMENG_MAP);
		}
		followGame(entity.i_gId, unFollow, new HttpHandler(entity));
	}

	class HttpHandler extends AsyncHttpResponseHandler {

		private GameEntity mEntity;

		public HttpHandler(GameEntity entity) {
			mEntity = entity;
		}

		@Override
		public void onSuccess(String content, int reqType) {
			super.onSuccess(content, reqType);

			if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME
					|| reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL) {

				FollowResp resp = (FollowResp) JsonPaserFactory.paserObj(
						content, reqType);
				if (resp == null || resp.i_success == 0) {
					// �ύʧ��
					showToast(String.format(SORRY_NOTIFY,
							mEntity.str_home_name, mEntity.str_away_name));
					indexFragment.updateFollow(mEntity.l_date_time,
							mEntity.i_gId, mEntity.i_isFollow > 0 ? 0 : 1);
				} else {
					if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME)
						showToast(String.format(SUCCESS_NOTIFY,
								mEntity.str_home_name, mEntity.str_away_name));
					if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL)
						showToast(CANCEL_NOTIFY);
				}
			}
		}

		@Override
		public void onFailure(Throwable error, String content, int reqType) {
			super.onFailure(error, content, reqType);

		}
	}

	@Override
	public void onSocketConnect() {
		// ���ӳɹ��ˣ�����room��
		joinRoom();
	}

	@Override
	public void onSocketDisconnect() {


	}

	@Override
	public void onSocketError(SocketIOException socketIOException) {

		// ��������������
		if (bMatchDay)
			reconnect(false);

		if (curFrame == FRAME_VIDEO) {
			if (videoFragment != null)
				videoFragment.stopLoad(false);
		} else if (curFrame == FRAME_NEWS) {
			if (newsFragment != null)
				newsFragment.stopLoad(false);
		}
	}

	@Override
	public void onSocketResp(JSONObject obj) {
		// System.out.println("indexact on===" + obj);
		if (obj != null) {
			GamesResp entity = new GamesResp(HuPuRes.REQ_METHOD_GAMES_BY_DATE);
			try {
				entity.paser(obj);
				indexFragment.setData(entity.l_game_day, entity, true);
				if (entity.mGameList.size() > 0
						&& entity.mGameList.get(0).byt_status == 2)
					setScreenLight(true);
				else
					setScreenLight(false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		// leaveRoom();
	}

}
