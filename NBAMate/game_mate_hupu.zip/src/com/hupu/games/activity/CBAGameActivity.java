package com.hupu.games.activity;

import java.text.SimpleDateFormat;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.activity.HupuDataActivity.BoxscoreDatas;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BoxScoreResp;
import com.hupu.games.data.CBABoxScoreResp;
import com.hupu.games.data.CBAData;
import com.hupu.games.data.SingleCBAData;
import com.hupu.games.fragment.CBAReportFragment;
import com.hupu.games.fragment.CBAStatisticFragment;
import com.hupu.games.handler.HupuHttpHandler;
import com.pyj.common.MyUtility;

public class CBAGameActivity extends HupuBaseActivity {

	private CBAData data;

	/** �ȷ��� */
	private TextView txtHomeScore1;
	private TextView txtHomeScore2;
	private TextView txtHomeScore3;

	private TextView txtAwayScore1;
	private TextView txtAwayScore2;
	private TextView txtAwayScore3;

	/** ����δ��ʼʱ��ʾ�Ŀ���ʱ�� */
	private TextView txtStartTime;
	/** ������ʼ����ʾ��ʱ�� */
	private TextView txtProcess;

	/** ���Ӷ��� */
	private TextView txtTopHome;
	/** �ͶӶӶ��� */
	private TextView txtTopAway;
	
	private TextView txtTitle;

	private View scoreView;
	private final static int GAME_STATE_CANCEL = 3;
	private final static int GAME_STATE_ONGOING = 1;
	private final static int GAME_STATE_END = 2;
	private final static int GAME_STATE_NOT_START = 0;

	FragmentManager fragmentManager;

	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"����:M��d�� H:mm", java.util.Locale.CHINESE);

	CBAReportFragment reportFragment;

	CBAStatisticFragment statisticFragment;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		Intent in = getIntent();
		data = (CBAData) in.getSerializableExtra("data");

		setContentView(R.layout.layout_cba_game);
		txtTitle =(TextView) findViewById(R.id.txt_title);
		txtTitle.setText(R.string.title_live);
		txtStartTime = (TextView) findViewById(R.id.txt_start_time);
		txtProcess = (TextView) findViewById(R.id.txt_proccess);
		setTeamName(data.str_home_name, data.str_away_name);
		if (data.byt_status == GAME_STATE_END ||data.byt_status == GAME_STATE_ONGOING) {
			// �������������ʾ���
			scoreView = findViewById(R.id.layout_score);
			scoreView.setVisibility(View.VISIBLE);
			txtStartTime.setVisibility(View.GONE);
			txtHomeScore1 = (TextView) findViewById(R.id.txt_home_scrore1);
			txtHomeScore2 = (TextView) findViewById(R.id.txt_home_scrore2);
			txtHomeScore3 = (TextView) findViewById(R.id.txt_home_scrore3);

			txtAwayScore1 = (TextView) findViewById(R.id.txt_away_scrore1);
			txtAwayScore2 = (TextView) findViewById(R.id.txt_away_scrore2);
			txtAwayScore3 = (TextView) findViewById(R.id.txt_away_scrore3);
			setSore(data.i_home_score, data.i_away_score);
			updateProccess(data.str_process);
		} 
//		else if (data.byt_status == GAME_STATE_ONGOING) {
//			// ��ʾ������
//			txtStartTime.setText("������");			
//		} 
		else if (data.byt_status == GAME_STATE_NOT_START) {
			txtStartTime.setText(MyUtility.getStartTime(
					data.l_begin_time * 1000, sdf));
		} else {
			txtStartTime.setText("��ȡ��");
		}

		fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();

		reportFragment = new CBAReportFragment();
		statisticFragment = new CBAStatisticFragment(data.str_home_name,
				data.str_away_name);
		fragmentTransaction.add(R.id.cba_content, reportFragment);
		fragmentTransaction.add(R.id.cba_content, statisticFragment);
		fragmentTransaction.hide(statisticFragment);
		fragmentTransaction.commit();

		req(0);

		btnLive = (ImageButton) findViewById(R.id.btn_live);
		btnStatistic = (ImageButton) findViewById(R.id.btn_statistic);

		mLayoutScoreBar = findViewById(R.id.layout_score);

		setOnClickListener(R.id.btn_back);
		setOnClickListener(R.id.btn_live);
		setOnClickListener(R.id.btn_statistic);
	}

	@Override
	public void treatClickEvent(int id) {

		super.treatClickEvent(id);
		if (id == R.id.btn_back) {
			finish();
		} else if (id == R.id.btn_live) {
			if (curIndex != 0) {
				setBackgound(0 );
				curIndex =0;
				switchFragment();
			}
			txtTitle.setText(R.string.title_live);
		} else if (id == R.id.btn_statistic) {
			if (curIndex != 1) {
				setBackgound(1);
				curIndex =1;
				switchFragment();
				if(!bHasStatisticData)
					req(1);
			}
			txtTitle.setText(R.string.title_statistic);
		}
	}

	private void switchFragment() {
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		if (curIndex == 0)
		{
//			fragmentTransaction.replace(R.id.cba_content, reportFragment);
			fragmentTransaction.show(reportFragment);
			fragmentTransaction.hide(statisticFragment);
		}		
		else
		{
//			fragmentTransaction.replace(R.id.cba_content, statisticFragment);
			fragmentTransaction.show(statisticFragment);
			fragmentTransaction.hide(reportFragment);
		}

		fragmentTransaction.commit();
	}

	private void showBottomBar() {
		findViewById(R.id.layout_bottom).setVisibility(View.VISIBLE);
	}

	private int curIndex;
	ImageButton btnLive;
	ImageButton btnStatistic;
	View mLayoutScoreBar;

	/** �����İ�ť�����仯 */
	private void setBackgound(int index) {
		int color = getResources().getColor(R.color.transform);
		switch (curIndex) {// ���ǰ
		case 0:
			btnLive.setBackgroundColor(color);
			btnLive.setImageResource(R.drawable.btn_live);
			break;
		case 1:
			btnStatistic.setBackgroundColor(color);
			btnStatistic.setImageResource(R.drawable.btn_statistics);
			break;
		}
		switch (index) {// �����
		case 0:
//			mLayoutScoreBar.setVisibility(View.GONE);
			btnLive.setBackgroundResource(R.drawable.btn_bg_bottom);
			btnLive.setImageResource(R.drawable.btn_live_hover);
			break;
		case 1:
//			mLayoutScoreBar.setVisibility(View.VISIBLE);
			btnStatistic.setBackgroundResource(R.drawable.btn_bg_bottom);
			btnStatistic.setImageResource(R.drawable.btn_statistics_hover);
			break;
		}
	}

	boolean bHasStatisticData;

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (o == null)
			return;
	


		if (methodId == HuPuRes.REQ_METHOD_CBA_BOX_SCORE) {
			CBABoxScoreResp d = (CBABoxScoreResp) o;
			if (d.mEntityHome == null) {
				// û������
				statisticFragment.addData(true);
				showToast("����ͳ������");
				return;
			}
			statisticFragment.setData(d);
			bHasStatisticData = true;
		}
		else 
		{
			SingleCBAData data = (SingleCBAData) o;
			if (data.bs > 0)
				showBottomBar();
			reportFragment.setData(data);
			if (data.byt_status == GAME_STATE_END)
				setSore(data.i_home_score, data.i_away_score);
		}

		// updateProccess(data.str_content) ;
	}

	/** ����������� */
	private void setTeamName(String home, String away) {
		// �������
		txtTopHome = (TextView) findViewById(R.id.txt_home);
		txtTopHome.setText(home + " (��)");
		txtTopAway = (TextView) findViewById(R.id.txt_away);
		txtTopAway.setText(away + " (��)");

	}

	private static final int num_res[] = { R.drawable.num0, R.drawable.num1,
			R.drawable.num2, R.drawable.num3, R.drawable.num4, R.drawable.num5,
			R.drawable.num6, R.drawable.num7, R.drawable.num8, R.drawable.num9, };

	/** ������ӱȷ� ��Ҫ���ƣ�����߼�����Ҫ���жϱȷֵı任�ˡ� */
	private void setSore(int homeScore, int awayScore) {
		if (homeScore < 0)
			return;
		int hundred = homeScore / 100;
		int tens = (homeScore % 100) / 10;
		int single = homeScore % 10;

		if (hundred > 0) {
			txtHomeScore1.setVisibility(View.VISIBLE);
			txtHomeScore1.setBackgroundResource(num_res[hundred]);
		} else
			txtHomeScore1.setVisibility(View.GONE);
		if (homeScore >= 10) {
			txtHomeScore2.setVisibility(View.VISIBLE);
			txtHomeScore2.setBackgroundResource(num_res[tens]);
		} else
			txtHomeScore2.setVisibility(View.GONE);
		txtHomeScore3.setBackgroundResource(num_res[single]);

		hundred = awayScore / 100;
		tens = (awayScore % 100) / 10;
		single = awayScore % 10;
		if (hundred > 0) {
			txtAwayScore1.setVisibility(View.VISIBLE);
			txtAwayScore1.setBackgroundResource(num_res[hundred]);
		} else
			txtAwayScore1.setVisibility(View.GONE);
		if (awayScore >= 10) {
			txtAwayScore2.setVisibility(View.VISIBLE);
			txtAwayScore2.setBackgroundResource(num_res[tens]);
		} else
			txtAwayScore2.setVisibility(View.GONE);
		txtAwayScore3.setBackgroundResource(num_res[single]);

	}

	/** ���±������̵ı�����Ϣ */
	private void updateProccess(String s) {
		if (s != null)
			txtProcess.setText(s);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	private void req(int type) {
		initParameter();
		mParams.put("gid", "" + data.i_gId);
		if (type == 0)
			sendRequest(HuPuRes.REQ_METHOD_CBA_BY_ID, mParams,
					new HupuHttpHandler(this));
		else
			sendRequest(HuPuRes.REQ_METHOD_CBA_BOX_SCORE, mParams,
					new HupuHttpHandler(this));
	}

	@Override
	protected void onPause() {
		super.onStop();
	}

}
