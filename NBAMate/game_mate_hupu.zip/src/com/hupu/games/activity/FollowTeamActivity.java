package com.hupu.games.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.adapter.TeamsListAdapter;
import com.umeng.analytics.MobclickAgent;

public class FollowTeamActivity extends HupuBaseActivity {

	private ListView mLvTeams;
	private TeamsListAdapter mAdapterTeams;
	boolean bFromSetup;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
			setContentView(R.layout.layout_follow_team);
			init();
	}

	private void init() {
		mAdapterTeams = new TeamsListAdapter(this,0);
		
		mAdapterTeams.initData(HuPuApp.getFollowTeams());

		mLvTeams = (ListView) findViewById(R.id.list_team);
		mLvTeams.setAdapter(mAdapterTeams);
		setOnClickListener(R.id.btn_setup);
		setOnItemClick(mLvTeams);
	}

	@Override
	public void treatClickEvent(int id) {
		switch (id) {
		case R.id.btn_setup:
			end();
			break;
		}
		super.treatClickEvent(id);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			end();
		}
		return false;
	}
	
	private void end()
	{
		mApp.followTeams (mAdapterTeams.getSelectList(),this);
		Intent in =new Intent();
		in.putExtra("follow", HuPuApp.getFollowTeamsNames(mAdapterTeams.getSelectList()));
		setResult(RESULT_OK, in);
		finish();
	}
	
	@Override
	public void treatItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {		
		mAdapterTeams.clickItem( pos);
	}

	private final int DIALOG_NOTIFY=1136; 
	@Override
	public void clickNegativeButton(int dialogId) {
		super.clickNegativeButton(dialogId);
		if (dialogId == DIALOG_NOTIFY) {
			if(mDialog!=null)
				mDialog.cancel();
		}
	}

	@Override
	public void clickPositiveButton(int dialogId) {
		super.clickPositiveButton(dialogId);
		if (dialogId == DIALOG_NOTIFY) {
			// ��֪ͨ
			if(mDialog!=null)
				mDialog.cancel();
			mApp.setNotify(true);
			mAdapterTeams.clickItem();
		}
	}
	
	public void onResume() {
	    super.onResume();
	    MobclickAgent.onResume(this);
	}
	public void onPause() {
	    super.onPause();
	    MobclickAgent.onPause(this);
	}
}
