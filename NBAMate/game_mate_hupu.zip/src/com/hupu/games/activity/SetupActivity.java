package com.hupu.games.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.GetFollowTeamsResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.UMFeedbackService;

public class SetupActivity extends HupuBaseActivity {

	private TextView txtFollows;
	private TextView txtVersion;

	private ToggleButton tgNotify;
	
	private final int DIALOG_NOTIFY=1314; 
	
	boolean byMan;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_setup);
		setOnClickListener(R.id.layout_about);
		setOnClickListener(R.id.layout_feedback);
		setOnClickListener(R.id.layout_reward);
		setOnClickListener(R.id.layout_follow);
		setOnClickListener(R.id.btn_back);
		txtFollows = (TextView) findViewById(R.id.txt_follow_teams);
		txtVersion = (TextView) findViewById(R.id.txt_version);
		tgNotify =(ToggleButton)findViewById(R.id.toggle_notify);

		tgNotify.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked && !byMan)
				{
					MobclickAgent.onEvent(SetupActivity.this, HuPuRes.UMENG_KEY_SETTING, HuPuRes.UMENG_KEY_NOTIFICATIONS_OPEN);
				}
				if( !isChecked && !byMan)
				{
					showCustomDialog(DIALOG_NOTIFY, R.string.push_title, R.string.push_notify,3,R.string.cancel , R.string.close_notify);
					buttonView.setChecked(true);
				}
				byMan =false;
				
			}
		});
		
		
		txtVersion.setText(mApp.getVerName());
		canClick = false;
		loadFollowData();
	
	}

	
	@Override
	protected void onStop() {
		super.onStop();
        mApp.setNotify(tgNotify.isChecked());
	}


	@Override
	public void clickPositiveButton(int dialogId) {
		
		super.clickPositiveButton(dialogId);
		if(dialogId ==DIALOG_NOTIFY)
		{
			mDialog.cancel();
			tgNotify.setChecked(true);
		}
		
	}

	@Override
	public void clickNegativeButton(int dialogId) {
		super.clickNegativeButton(dialogId);
		mDialog.cancel();
		if(dialogId ==DIALOG_NOTIFY)
		{
			mDialog.cancel();
			byMan =true;
			tgNotify.setChecked(false);
			
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_SETTING, HuPuRes.UMENG_KEY_NOTIFICATIONS_CLOSE);
		}
	}

	private boolean canClick;

	@Override
	public void treatClickEvent(int id) {
		switch (id) {
		case R.id.layout_follow:
			if (canClick) {
				Intent in = new Intent(this, FollowTeamActivity.class);
				startActivityForResult(in, 10);
			}
			break;
		case R.id.layout_about:
			break;
		case R.id.layout_feedback:
			// UMFeedbackService.setGoBackButtonVisible();
			UMFeedbackService.openUmengFeedbackSDK(this);
			break;
		case R.id.layout_reward:
			break;
		case R.id.btn_back:
			finish();
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 10) {
			if (resultCode == RESULT_OK) {
				String s = data.getStringExtra("follow");
				txtFollows.setText(s);
			}
		}
	}

	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
		if(!mApp.needNotify)
			byMan=true;
		tgNotify.setChecked(mApp.needNotify);
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	/** �����û���ע������б� */
	private void loadFollowData() {
		mApp.loadFollowTeam();
		if (mApp.loadFollowTeam().size() == 0)
			getTeamsFromWeb();
		else
			setTeamNames();

	}

	private void setTeamNames() {
		findViewById(R.id.pBar).setVisibility(View.GONE);
		canClick=true;
		txtFollows.setText(HuPuApp.getFollowTeamsNames(null));
	}

	/** ����������ȡ�û�����ע������б� */
	private void getTeamsFromWeb() {
		initParameter();
		sendRequest(HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS, mParams,
				new HupuHttpHandler(this));
	}

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);

		if (methodId == HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS) {
			GetFollowTeamsResp entity = (GetFollowTeamsResp) o;
			if (entity != null && entity.mListTeams != null) {
				mApp.insertTeamsToDB( entity.mListTeams );
				setTeamNames();
			}

		}
	}
}
