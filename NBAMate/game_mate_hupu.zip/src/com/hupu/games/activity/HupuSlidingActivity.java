package com.hupu.games.activity;

import io.socket.SocketIOException;

import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.json.JSONObject;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.TextView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.R.layout;
import com.hupu.games.adapter.LeftMenuAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.common.SharedPreferencesMgr;
import com.hupu.games.data.CBAResp;
import com.hupu.games.data.FollowResp;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.data.JsonPaserFactory;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.fragment.CBAGameFragment;
import com.hupu.games.fragment.NbaGameFragment;
import com.hupu.games.fragment.NewsFragment;
import com.hupu.games.fragment.StandingFragment;
import com.hupu.games.fragment.VideoFragment;
import com.hupu.games.handler.HupuHttpHandler;
import com.pyj.common.DeviceInfo;
import com.pyj.common.DialogRes;
import com.pyj.common.MyUtility;
import com.pyj.http.AsyncHttpResponseHandler;
import com.pyj.http.RequestParams;
import com.slidingmenu.lib.SlidingMenu;
import com.slidingmenu.lib.SlidingMenu.OnClosedListener;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.NotificationType;
import com.umeng.fb.UMFeedbackService;
import com.umeng.update.UmengUpdateAgent;

public class HupuSlidingActivity extends HupuBaseActivity {

	private ExpandableListView leftMenu;

	/** nba�����б�ҳ */
	// private NbaGameHomeFragment nbaGameFragment;
	private NbaGameFragment nbaGameFragment;

	/** nba����ҳ�� */
	private StandingFragment nbaStandingFragment;

	/** nba��Ƶҳ�� */
	private VideoFragment nbaVideoFragment;
	/** cba��Ƶҳ�� */
	private VideoFragment cbaVideoFragment;

	/** nba����ҳ�� */
	private NewsFragment nbaNewsFragment;

	private NewsFragment cbaNewsFragment;

	/** cba�����б�ҳ */
	private CBAGameFragment cbaGameFragment;

	/** ��˵� */
	private SlidingMenu menu;

	TextView mTitle;

	private static String SORRY_NOTIFY = "��Ǹ��%s vs %s��������ʧ��";

	private static String SUCCESS_NOTIFY = "�������óɹ����������յ�%s vs %s������֪ͨ";

	private static String CANCEL_NOTIFY = "����ȡ���ɹ�";

	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"yyyy-MM-dd", java.util.Locale.CHINESE);

	boolean bShowQuit;

	LeftMenuAdapter menuAdapter;

//	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		if (savedInstanceState != null)
			savedInstanceState.clear();
		super.onCreate(savedInstanceState);

//		Log.d("HupuSlidingActivity", "onCreate");
		setContentView(R.layout.layout_tab_index);
		UmengUpdateAgent.update(this);
		Intent in = getIntent();
		if (in.getBooleanExtra("click", false)) {
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NOTIFICATION_CLICK);
		}
		init();
		UMFeedbackService.enableNewReplyNotification(this,
				NotificationType.AlertDialog);
	}

	View mEmptyView;
	/** ��ʼ����˵� */
	private void initMenu() {
		// configure the SlidingMenu
		menu = new SlidingMenu(this);
		menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		// menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
		menu.setShadowWidthRes(R.dimen.shadow_width);
		menu.setBehindOffsetRes(R.dimen.slidingmenu_offset);
		menu.setFadeDegree(0.35f);
		menu.attachToActivity(this, SlidingMenu.SLIDING_CONTENT);
		menu.setMenu(R.layout.menu_frame_left);
		menu.showMenu();
		if( SharedPreferencesMgr.getBoolean("guide", true))
		{
			menu.setOnClosedListener(new OnClosedListener() {

				@Override
				public void onClosed() {
					if(curFragmentIndex<1)
					{
						showGuide();
						menu.setOnClosedListener(null);
						SharedPreferencesMgr.setBoolean("guide", false);
					}					
				}
			});
		}
		
		menuAdapter = new LeftMenuAdapter(this);
		leftMenu = (ExpandableListView) findViewById(R.id.list_menu);
		leftMenu.setAdapter(menuAdapter);
		leftMenu.setOnChildClickListener(new MenuClick());
		leftMenu.expandGroup(0);
		leftMenu.expandGroup(1);
		leftMenu.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

			@Override
			public void onGroupCollapse(int groupPosition) {
				leftMenu.expandGroup(groupPosition);
				
			}
		});
		mTitle = (TextView) findViewById(R.id.txt_title);

	}

	boolean showGuide;
	private void showGuide()
	{
		 
		 WindowManager.LayoutParams lp = new WindowManager.LayoutParams();  
        lp.flags |= (LayoutParams.FLAG_NOT_FOCUSABLE);  
        lp.format = PixelFormat.TRANSPARENT;  
        lp.width = LayoutParams.FILL_PARENT;  
        lp.height = LayoutParams.FILL_PARENT;  
        lp.type = LayoutParams.TYPE_APPLICATION;  
        mEmptyView =LayoutInflater.from(this).inflate(R.layout.guide_1, null);
        mEmptyView.setOnClickListener(click);
        showGuide =true;

        getWindowManager().addView(mEmptyView, lp);  
	}
	
	
	private void stopGuide()
	{
		if(showGuide)
		{
			getWindowManager().removeView(mEmptyView);  
			showGuide = false;  
		}
	}
	private void init() {
		setContentView(R.layout.layout_content_frame);
		HuPuRes.setClient(DeviceInfo.getDeviceInfo(getApplicationContext()));
		setRoomObj(HuPuRes.ROOM_NBA_HOME);
		initMenu();
		// ��һ�ν���ֱ�ӽ���NBA�����б�
		// nbaGameFragment = new NbaGameFragment();
		// addContent(nbaGameFragment) ;
		replaceContent(INDEX_NBA_GAME);
		nbaGameFragment.entry();
		setOnClickListener(R.id.btn_setup);
		setOnClickListener(R.id.btn_menu);

		// menu.setFadeEnabled(true);
//		menu.postInvalidateDelayed(200);
	}

	private final static int INDEX_NBA_GAME = 0;
	private final static int INDEX_NBA_NEWS = 1;
	private final static int INDEX_NBA_VIDEO = 2;
	private final static int INDEX_NBA_STANDINGS = 3;

	private final static int INDEX_CBA_GAME = 4;
	private final static int INDEX_CBA_NEWS = 5;
	private final static int INDEX_CBA_VIDEO = 6;
	private final static int INDEX_CBA_STANDINGS = 7;

	private void replaceContent(Fragment fragment) {
		FragmentTransaction transaction = getSupportFragmentManager()
				.beginTransaction();
		transaction.replace(R.id.content_frame, fragment);
		transaction.addToBackStack(null);
		transaction.commit();

	}

	private int curFragmentIndex = -1;

	private void replaceContent(int index) {
		if (curFragmentIndex == index)
			return;
		Fragment fragment = null;

		switch (index) {
		case INDEX_NBA_GAME:
			if (nbaGameFragment == null)
				nbaGameFragment = new NbaGameFragment();
			fragment = nbaGameFragment;

			break;
		case INDEX_NBA_NEWS:
			if (nbaNewsFragment == null)
				nbaNewsFragment = new NewsFragment();
			fragment = nbaNewsFragment;
			break;
		case INDEX_NBA_VIDEO:
			if (nbaVideoFragment == null)
				nbaVideoFragment = new VideoFragment();
			fragment = nbaVideoFragment;
			break;
		case INDEX_NBA_STANDINGS:
			if (nbaStandingFragment == null)
				nbaStandingFragment = new StandingFragment();
			fragment = nbaStandingFragment;
			break;
		case INDEX_CBA_GAME:
			if (cbaGameFragment == null)
				cbaGameFragment = new CBAGameFragment();
			fragment = cbaGameFragment;
			break;
		case INDEX_CBA_VIDEO:
			if (cbaVideoFragment == null)
				cbaVideoFragment = new VideoFragment(1);
			fragment = cbaVideoFragment;
			break;
		case INDEX_CBA_NEWS:
			if (cbaNewsFragment == null)
				cbaNewsFragment = new NewsFragment(1);
			fragment = cbaNewsFragment;
			break;
		}

		curFragmentIndex = index;
		if (fragment != null)
			replaceContent(fragment);
	}

	@Override
	protected void onResume() {
		super.onResume();

		if (nbaGameFragment != null) {
			if (nbaGameFragment.bMatchDay)
				joinRoom();
			// ������������ӹ�ע������ÿ�ζ��������������ݡ�
			if (nbaGameFragment.mToday > 0)
				nbaGameFragment.req(-1, 0);
		}
        stopGuide();
		MobclickAgent.onResume(this);
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				menuAdapter.notifyDataSetChanged();
			}
		}, 200);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	public void treatClickEvent(int id) {

		super.treatClickEvent(id);
		switch (id) {
		case R.id.btn_menu:
			menu.showMenu(true);
			break;
		case R.id.btn_setup:
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NAV,  HuPuRes.UMENG_KEY_SETTING);
			startActivity(new Intent(this, SetupActivity.class));
			break;
		case R.id.guide_1:
			stopGuide();
			break;
		}
	}

	private final int DIALOG_NOTIFY = 1311;

	GameEntity followEntity;

	/** ��ע��ȡ������ */
	public void setFollowGame(GameEntity entity) {

		if (mApp.needNotify || entity.i_isFollow > 0) {
			// byte unFollow = (byte) (entity.i_isFollow > 0 ? 0 : 1);
			byte unFollow = (byte) entity.i_isFollow;
			UMENG_MAP.clear();
			UMENG_MAP.put("date",
					MyUtility.getStartTime(entity.l_date_time * 1000, sdf));
			if (unFollow == 1) {
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_HOME_FOLLOW,
						UMENG_MAP);
			} else {
				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_HOME_UNFOLLOW,
						UMENG_MAP);
			}
			nbaGameFragment.updatefollow(entity);
			followGame(entity.i_gId, unFollow, new HttpHandler(entity));
		} else {

			followEntity = entity;
			showCustomDialog(DIALOG_NOTIFY, R.string.push_title,
					R.string.push_open_notify, 3, R.string.open_notify,
					R.string.cancel);
		}
	}

	/** ������������ */
	private void reqStandings() {
		initParameter();
		sendRequest(HuPuRes.REQ_METHOD_GET_STANDINGS, mParams,
				new HupuHttpHandler(this));
	}

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (o == null)
			return;
		switch (methodId) {
		case HuPuRes.REQ_METHOD_GET_STANDINGS:
			StandingsResp resp = (StandingsResp) o;
			nbaStandingFragment.setData(resp);
			return;

		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
			nbaVideoFragment.stopLoad(false);
			if (o != null)
				nbaVideoFragment.setData(methodId, o);
			break;

		case HuPuRes.REQ_METHOD_GET_NBA_NEWS:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_PRE:
			nbaNewsFragment.stopLoad(false);
			if (o != null)
				nbaNewsFragment.setData(methodId, o);
			break;

		case HuPuRes.REQ_METHOD_GET_CBA_NEWS:
		case HuPuRes.REQ_METHOD_GET_CBA_NEWS_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_NEWS_PRE:
			cbaNewsFragment.stopLoad(false);
			if (o != null)
				cbaNewsFragment.setData(methodId, o);
			break;

		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT:
			cbaVideoFragment.stopLoad(false);
			if (o != null)
				cbaVideoFragment.setData(methodId, o);
			break;

		case HuPuRes.REQ_METHOD_CBA_NEXT:
		case HuPuRes.REQ_METHOD_CBA_PREV:
			cbaGameFragment.setData((CBAResp) o);
			break;

		default:
			// �����б�������
			GamesResp entity = null;
			entity = (GamesResp) o;
			if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER
					&& entity.redirectors != null)
				mApp.setServer(entity.redirectors);
			nbaGameFragment.setData(methodId, entity);
			break;
		}
	}

	@Override
	public void onErrResponse(Throwable error, String content) {
		super.onErrResponse(error, content);

		if (curFragmentIndex == INDEX_NBA_VIDEO) {
			if (nbaVideoFragment != null)
				nbaVideoFragment.stopLoad(false);
		} else if (curFragmentIndex == INDEX_NBA_NEWS) {
			if (nbaNewsFragment != null)
				nbaNewsFragment.stopLoad(false);
		} else if (curFragmentIndex == INDEX_CBA_VIDEO) {
			if (cbaVideoFragment != null)
				cbaVideoFragment.stopLoad(false);
		} else if (curFragmentIndex == INDEX_CBA_NEWS) {
			if (cbaNewsFragment != null)
				cbaNewsFragment.stopLoad(false);
		}
	}

	public boolean sendRequest(int reqType, RequestParams params) {
		return sendRequest(reqType, params, new HupuHttpHandler(this));
	}

	public RequestParams getHttpParams(boolean init) {
		if (init)
			initParameter();
		return mParams;

	}

	/**
	 * �л���ʵʱҳ��
	 * */
	public void switchToLive(GameEntity en, int pos, boolean matchDay) {
		HuPuApp.hasTeam(en.i_home_tid, en.str_home_name);
		HuPuApp.hasTeam(en.i_away_tid, en.str_away_name);
		Intent in = new Intent(this, HupuDataActivity.class);
		in.putExtra("game", en);
		in.putExtra("match", matchDay);
		in.putExtra("pos", pos);
		startActivity(in);
		// startActivity(in);
	}

	long quit_time;

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			// long curtime=System.currentTimeMillis();
			// if (quit_time== 0 || curtime -quit_time> 3000) {
			// showToast("�ٰ�һ���˳�");
			// }
			// else
			// {
			// quit();
			// }
			// quit_time =System.currentTimeMillis();
			if(showGuide)
			{
				stopGuide();
				return true;
			}
			if (menu.isMenuShowing())
				quit();
			else
				menu.showMenu();
			return true;
		}
		return false;
	}

	@Override
	public void onCancelDialog(int dialogId) {
		super.onCancelDialog(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			bShowQuit = false;
	}

	@Override
	public void clickNegativeButton(int dialogId) {
		super.clickNegativeButton(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			bShowQuit = false;
		else if (dialogId == DIALOG_NOTIFY) {
			if (mDialog != null)
				mDialog.cancel();
		}
	}

	@Override
	public void clickPositiveButton(int dialogId) {
		super.clickPositiveButton(dialogId);
		if (DialogRes.DIALOG_QUIT_PROMPT == dialogId)
			quit();
		else if (dialogId == DIALOG_NOTIFY) {
			// ��֪ͨ
			if (mDialog != null)
				mDialog.cancel();
			mApp.setNotify(true);
			setFollowGame(followEntity);
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_SETTING,
					HuPuRes.UMENG_KEY_NOTIFICATIONS_OPEN_CONFIRM);
		}
	}

	int lastFrameIndex;;

	class MenuClick implements OnChildClickListener {

		@Override
		public boolean onChildClick(ExpandableListView parent, View v,
				int groupPosition, int childPosition, long id) {
			// Log.d("MenuClick", "childPosition="+childPosition);
			menuAdapter.setPosition(groupPosition, childPosition);
			int frameIndex = 0;
			if (groupPosition == 0)// NBA
			{
				frameIndex = childPosition;
			} else if (groupPosition == 1)// CBA
			{
				frameIndex = childPosition + 4;
			}

			if (curFragmentIndex == frameIndex) {
				menu.showContent(true);
				return true;
			}
			replaceContent(frameIndex);
			UMENG_MAP.clear();
			switch (frameIndex) {
			case INDEX_NBA_GAME:
				nbaGameFragment.entry();
				mTitle.setText(R.string.STR_TITLE_NBA_GAME);
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_NBA_GAMES);				
				break;
			case INDEX_NBA_NEWS:
				nbaNewsFragment.entry();
				mTitle.setText(R.string.STR_TITLE_NBA_NEWS);
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_NBA_NEWS);
				break;
			case INDEX_NBA_VIDEO:
				mTitle.setText(R.string.STR_TITLE_NBA_VIDEO);
				nbaVideoFragment.entry();
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_NBA_VIDEO);
				break;
			case INDEX_NBA_STANDINGS:
				reqStandings();
				mTitle.setText(R.string.STR_TITLE_NBA_RANK);
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_NBA_STANDINGS);
				break;

			case INDEX_CBA_GAME:
				cbaGameFragment.entry();
				mTitle.setText(R.string.STR_TITLE_CBA_GAME);
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_CBA_GAMES);
				break;
			case INDEX_CBA_NEWS:
				cbaNewsFragment.entry();
				mTitle.setText(R.string.STR_TITLE_CBA_NEWS);
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_CBA_NEWS);
				break;
			case INDEX_CBA_VIDEO:
				mTitle.setText(R.string.STR_TITLE_CBA_VIDEO);
				cbaVideoFragment.entry();
				UMENG_MAP.put(HuPuRes.UMENG_KEY_NAV,HuPuRes.UMENG_KEY_CBA_VIDEO);
				break;
			case INDEX_CBA_STANDINGS:
				break;
			}
			menu.showContent(true);
			MobclickAgent.onEvent(HupuSlidingActivity.this,HuPuRes.UMENG_KEY_NAV,UMENG_MAP);
			return true;
		}

	}

	class HttpHandler extends AsyncHttpResponseHandler {

		private GameEntity mEntity;

		public HttpHandler(GameEntity entity) {
			mEntity = entity;
		}

		@Override
		public void onSuccess(String content, int reqType) {
			super.onSuccess(content, reqType);

			if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME
					|| reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL) {

				FollowResp resp = (FollowResp) JsonPaserFactory.paserObj(
						content, reqType);
				if (resp == null || resp.i_success == 0) {
					// �ύʧ��
					showToast(String.format(SORRY_NOTIFY,
							mEntity.str_home_name, mEntity.str_away_name));
					nbaGameFragment.updateFollow(mEntity.l_date_time,
							mEntity.i_gId, mEntity.i_isFollow > 0 ? 0 : 1);
				} else {
					if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME)
						showToast(String.format(SUCCESS_NOTIFY,
								mEntity.str_home_name, mEntity.str_away_name));
					if (reqType == HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL)
						showToast(CANCEL_NOTIFY);
				}
			}
		}

		@Override
		public void onFailure(Throwable error, String content, int reqType) {
			super.onFailure(error, content, reqType);

		}
	}

	@Override
	public void onSocketError(SocketIOException socketIOException) {

		// ��������������
		if (nbaGameFragment.bMatchDay)
			reconnect(false);
	}

	@Override
	public void onSocketResp(JSONObject obj) {
		// System.out.println("indexact on===" + obj);
		if (obj != null) {
			GamesResp entity = new GamesResp(HuPuRes.REQ_METHOD_GAMES_BY_DATE);
			try {
				entity.paser(obj);
				nbaGameFragment
						.setFragmentData(entity.l_game_day, entity, true);

				if (entity.mGameList.size() > 0
						&& entity.mGameList.get(0).byt_status == 2)
					setScreenLight(true);
				else
					setScreenLight(false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onSocketConnect() {
		// ���ӳɹ��ˣ�����room��
		joinRoom();
	}

}
