package com.hupu.games.activity;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.hupu.games.R;
import com.hupu.games.adapter.TeamsListAdapter;
import com.hupu.games.common.HuPuRes;
import com.pyj.common.DialogRes;
import com.umeng.analytics.MobclickAgent;
/**
 * ���ε�¼ʱ��ӵ�ѡ��ҳ��
 * */
public class HupuLaunchActivity extends HupuBaseActivity {



	private ListView mLvTeams;
	private TeamsListAdapter mAdapterTeams;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		System.out.println("HupuLaunchActivity=========== onCreate"+android.os.Process.myPid());
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_follow_team_init);
		init();
	
	}

	private void init() {
		mAdapterTeams = new TeamsListAdapter(this,1);
		mLvTeams = (ListView) findViewById(R.id.list_team);
		mLvTeams.setAdapter(mAdapterTeams);
		setOnClickListener(R.id.btn_done);
		setOnItemClick(mLvTeams);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			quit();
		}
		return false;
	}
	
	private  void startHome()
	{
		Intent intent = new Intent(this, HupuSlidingActivity.class);
		intent.putExtra("load", true);
		startActivity(intent);
		finish();
	}
	@Override
	public void treatClickEvent(int id) {
		switch (id) {
		case R.id.btn_done:
			mApp.followTeams (mAdapterTeams.getSelectList(),this);
			// ���ݹ�ע��Ϣ
			startHome();
			MobclickAgent.onEvent(this,HuPuRes.UMENG_KEY_GUIDE_DONE) ;		
			break;

		}
		super.treatClickEvent(id);
	}


	@Override
	public void treatItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
		mAdapterTeams.clickItem(pos);

	}


	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
}
