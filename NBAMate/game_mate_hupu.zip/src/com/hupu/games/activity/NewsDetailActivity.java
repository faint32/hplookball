package com.hupu.games.activity;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.util.HashMap;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.webkit.DownloadListener;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.NewsDetailEntity;
import com.hupu.games.fragment.ReportFragment;
import com.hupu.games.handler.HupuHttpHandler;
import com.pyj.activity.BaseActivity;
import com.umeng.analytics.MobclickAgent;

public class NewsDetailActivity extends HupuBaseActivity {

	private WebView mWebView;

	private long nid;

	private TextView txtReplies;

	private int reply;

	View progressbar;

	private int type ;
	
	private int method;
	@TargetApi(8)
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_news);
		nid = getIntent().getLongExtra("nid", -1);
		reply = getIntent().getIntExtra("reply", -1);
		type = getIntent().getIntExtra("type", 0);
		
		if(type ==0)
			method = HuPuRes.REQ_METHOD_GET_NBA_DETAIL;
		else
		{
			method = HuPuRes.REQ_METHOD_GET_CBA_DETAIL;
			((TextView)findViewById(R.id.txt_title)).setText(R.string.STR_TITLE_CBA_NEWS);
		}
		
		if (nid < 0)
			finish();
		reqNews();
		UMENG_MAP.put(HuPuRes.UMENG_KEY_NBA_NEWS,
				HuPuRes.UMENG_KEY_NBA_CLICK_COMMENT);
	
		mWebView = (WebView) findViewById(R.id.webview);
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				Intent in = new Intent(NewsDetailActivity.this,
						WebViewActivity.class);
				in.putExtra("url", url);
				startActivity(in);
				MobclickAgent.onEvent(NewsDetailActivity.this,
						HuPuRes.UMENG_KEY_BROWSER);
				return true;
			}
		});
		txtReplies = (TextView) findViewById(R.id.btn_jump);
		progressbar = findViewById(R.id.probar);

		txtReplies.setText(reply + "����");
		setOnClickListener(R.id.btn_back);
		setOnClickListener(R.id.btn_jump);
	}

	private void reqNews() {
		initParameter();
		mParams.put("nid", "" + nid);
		mParams.put("html", "html");
		
		sendRequest(method, mParams,
				new HupuHttpHandler(this));
	}

	NewsDetailEntity entity;
	static final String mimeType = "text/html";
	static final String encoding = "utf-8";
	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (o != null) {
			progressbar.setVisibility(View.GONE);
			entity = (NewsDetailEntity) o;
			if (entity != null) {
				txtReplies.setText(entity.replies + "����");
				mWebView.loadDataWithBaseURL(null, entity.content, mimeType,
						encoding, null);
				mWebView.postInvalidate();
				// try {
				// String ss=URLEncoder.encode(entity.content,encoding);
				// mWebView.loadData( ss, mimeType, encoding);
				// } catch (UnsupportedEncodingException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }

				// mWebView.reload();
			}

		}
	}

	@Override
	public void onErrResponse(Throwable error, String content) {
		super.onErrResponse(error, content);
		progressbar.setVisibility(View.GONE);
		showToast("û������");
	}

	@Override
	public void treatClickEvent(int id) {

		super.treatClickEvent(id);
		switch (id) {

		case R.id.btn_back:
			finish();
			break;
		case R.id.btn_jump:
			if (entity != null) {

				MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NBA_NEWS,
						UMENG_MAP);
				Intent in = new Intent(this, WebViewActivity.class);
				in.putExtra("url", entity.replyurl);
				startActivity(in);
			}
			break;
		}
	}

	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);

		if (mWebView != null) {
			try {
				mWebView.getClass().getMethod("onResume")
						.invoke(mWebView, (Object[]) null);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);

	}

	@Override
	protected void onDestroy() {

		if (mWebView != null) {
			mWebView.stopLoading();
			mWebView.clearHistory();
		}
		super.onDestroy();
	}

}
