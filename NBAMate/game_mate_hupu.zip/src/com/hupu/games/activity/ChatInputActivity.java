package com.hupu.games.activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.common.SharedPreferencesMgr;

public class ChatInputActivity extends HupuBaseActivity {

	private String userName;
	private EditText edtMsg;
	private int size = 140;
	private String content;
	private EditText edtName;
	private TextView txtNum;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_chat_input);

		userName = SharedPreferencesMgr.getString("username", null);
		
		edtMsg = (EditText) findViewById(R.id.edt_msg);
		edtMsg.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence c, int arg1, int arg2,
					int arg3) {
				size = 140 - (int) calculateWeiboLength(c);
				txtNum.setText(size + "��");
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {

			}

			@Override
			public void afterTextChanged(Editable arg0) {

			}
		});
		txtNum = (TextView) findViewById(R.id.txt_num);
		if (userName == null) {
			showDialog();
		} else {
			showKeyBoard(edtMsg);
		}
		setOnClickListener(R.id.btn_back);
		setOnClickListener(R.id.btn_sent);
	}

	@Override
	public void treatClickEvent(int id) {
		// TODO Auto-generated method stub
		super.treatClickEvent(id);

		switch (id) {
		case R.id.btn_back:
			finish();
			break;
		case R.id.btn_sent:
			if (userName == null)
				showDialog();
			else
				sent();
			break;
		case R.id.btn_nick_submit:
			clickPositiveButton();
			break;
		case R.id.btn_cancel:
			clickNegativeButton();
			break;
		}
	}

	AlertDialog dialog;

	/** ��ʾ�Զ���ĶԻ��� */
	public void showDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this)
				.setCancelable(true).setTitle(R.string.input_nick_name);
		View input = LayoutInflater.from(this).inflate(
				R.layout.dialog_nick_name, null);

		edtName = (EditText) input.findViewById(R.id.edt_nick_name);
		input.findViewById(R.id.btn_nick_submit).setOnClickListener(click);
		input.findViewById(R.id.btn_cancel).setOnClickListener(click);
		builder.setView(input);
		
		dialog = builder.create();
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();
		
		showKeyBoard(edtName);
	}

	public void clickPositiveButton() {

		String ss = edtName.getEditableText().toString();
		if (ss != null) {
			ss=ss.trim();
			int length = ss.length();
			if (length < 3) {
//				showToast("�ǳƱ������2����");
				showToast("�ǳƳ���Ӧ��3��10���ַ�");
				
			} else if (length > 10) {
//				showToast("�ǳƱ���С��10����");
				showToast("�ǳƳ���Ӧ��3��10���ַ�");
			} else {

				if (isRight(ss)) {
					dialog.dismiss();
					userName = ss;
					SharedPreferencesMgr.setString("username", userName);
				} else {
					showToast("ֻ�����뺺�֡���ĸ������");
				}
			}
		}

	}

	public void clickNegativeButton() {
		dialog.dismiss();

	}

	private void sent() {
		content = edtMsg.getEditableText().toString();
	
		if (content == null || ( content.trim().length() == 0)) {
			showToast("����������");
		} else if (size < 0) {
			showToast("��������140��");
		} else {
			Intent data = new Intent();
			data.putExtra("user", userName);
			data.putExtra("content", content);
			setResult(RESULT_OK, data);
			finish();

		}

	}

	/**
	 * ����΢�����ݵĳ��� 1������ == ����Ӣ����ĸ��ռ�ĳ��� ����������Ӣ�ĺ�����
	 * 
	 * @param c
	 *            ��Ҫͳ�Ƶ��ַ�����
	 * @return �����ַ����м���ĳ���
	 */
	public static long calculateWeiboLength(CharSequence c) {

		double len = 0;
		for (int i = 0; i < c.length(); i++) {
			int temp = (int) c.charAt(i);
			if (temp > 0 && temp < 127) {
				len += 0.5;
			} else {
				len++;
			}
		}
		return Math.round(len);
	}

	/** �����Ƿ�ֻ�������֣���ĸ������ */

	public boolean isRight(String str) {

		char[] chars = str.toCharArray();
		char c;
		for (int i = 0; i < chars.length; i++) {
			c = chars[i];
			if (isGB(c) || isChar(c) || isNumeric(c))
				continue;
			return false;
		}
		return true;
	}

	/*** �ж��Ƿ�Ϊ���� */
	public static boolean isGB(char c) {
		// byte[] bytes = ("" + c).getBytes();
		// if (bytes.length == 2) {
		// int[] ints = new int[2];
		// ints[0] = bytes[0] & 0xff;
		// ints[1] = bytes[1] & 0xff;
		// if (ints[0] >= 0x81 && ints[0] <= 0xFE && ints[1] >= 0x40
		// && ints[1] <= 0xFE) {
		// return true;
		// }
		// }
		// return false;
		int v = (int) c;
		if (v >= 19968 && v <= 171941) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isChar(char c) {
		if (((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isNumeric(char c) {
		if (c < 48 || c > 57)
			return false;
		return true;

	}
	
	private void showKeyBoard(View view)
	{
		((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(view, 0);
	}
}
