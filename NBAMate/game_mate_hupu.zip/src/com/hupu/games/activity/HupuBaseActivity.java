package com.hupu.games.activity;

import io.socket.SocketIO;
import io.socket.SocketIOException;
import io.socket.SocketIoHandler;

import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.Toast;

import com.hupu.games.HuPuApp;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.handler.ISocketCallBack;
import com.pyj.activity.BaseActivity;
import com.pyj.common.DeviceInfo;
import com.pyj.common.DialogRes;
import com.pyj.http.AsyncHttpResponseHandler;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

/** ����HuPuGameMateӦ��Activity�Ļ��� */
public class HupuBaseActivity extends BaseActivity {
	/** Ӧ����ľ�� */
	public HuPuApp mApp;
	/** http����Ĳ��� */
	protected RequestParams mParams;

	private static String mToken;
	/** �豸�� */
	private static String mDeviceId;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mApp = (HuPuApp) getApplication();
		if (mParams == null)
			mParams = new RequestParams();
		mDeviceId = DeviceInfo.getDeviceInfo(this);
		// System.out.println("device info="+mDeviceId);
	}

	/**
	 * ����һ��Http������
	 * 
	 * @param methodId
	 *            ������id�����ж���
	 * @param params
	 *            ��������Ĳ���
	 * @param responseHandler
	 *            ������������handler
	 * @return �Ƿ�����������
	 * */
	public boolean sendRequest(int methodId, RequestParams params,
			AsyncHttpResponseHandler responseHandler) {
		return sendRequest(methodId, params, responseHandler, false);
	}

	public boolean sendRequest(int methodId, RequestParams params,
			AsyncHttpResponseHandler responseHandler, boolean showDialog) {
		if (DeviceInfo.isNetWorkEnable(this)) {
			i_curState = STATE_CONNECTING;
			if(methodId == HuPuRes.REQ_METHOD_SENT_CHAT)
			{				
				mApp.mHttpClient.post(this, HuPuRes.getUrl(methodId)+"?client="+DeviceInfo.getDeviceInfo(this), params,
						responseHandler, methodId);
			}
						
			else
			mApp.mHttpClient.get(this, HuPuRes.getUrl(methodId), params,
					responseHandler, methodId);
			// if (showDialog)
			// showDialog(DialogRes.DIALOG_ID_NET_CONNECT);
			return true;
		} else {
			// showDialog(DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE);
			if (showDialog)
				showDialog(DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE);
			else
				Toast.makeText(this, "û�����磬���Ժ����ԡ�", Toast.LENGTH_SHORT).show();
			return false;
		}
	}

	/**
	 * ȡ����ҳ���������������
	 * */
	public void cancelConnection() {
		i_curReqTimes = 0;
		mApp.mHttpClient.cancelRequests(this, true);
	}

	private boolean bBackGround;

	@Override
	protected void onStop() {

		if (i_curState == STATE_SHOW_DIALOG && mDialog.isShowing())
			mDialog.cancel();
		if (i_curReqTimes > 0)
			cancelConnection();
		i_curState = STATE_STOP;
		if (!mApp.isAppOnForeground()) {
			bBackGround = true;
			onBackground();
		}
		super.onStop();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (mApp.isAppOnForeground()) {
			bBackGround = false;
			onForeground();
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if (i_curState == STATE_CONNECTING) {
				// removeDialog(DialogRes.DIALOG_ID_NET_CONNECT);
				cancelConnection();
			}
			finish();
		}
		return false;
	}

	/** �˳�Ӧ�� */
	public void quit() {
		// �˳�socket
		disconnect();
		mApp.quit();
	}

	@Override
	public void onReqResponse(Object o, int methodId) {

		if(o !=null && ((BaseEntity)o).err!=null)
		{
			onErrResponse(null,((BaseEntity)o).err);
		}
	}
	
	
	protected HashMap<String, String> UMENG_MAP = new HashMap<String, String>();
	
	@Override
	public void onErrResponse(Throwable error, String content) {
		super.onErrResponse(error, content);
		UMENG_MAP.clear();
		if(error !=null)
		{
			error.printStackTrace();
			Log.e(getClass().getSimpleName(), error.toString());
			if( error instanceof org.apache.http.conn.ConnectTimeoutException)
			{
				UMENG_MAP.put("http", "timeout");
			}
			else if ( error instanceof ConnectException)
			{
				UMENG_MAP.put("http", "failed");
			}
		}
		else
		{
			UMENG_MAP.put("failed", "failed");
		}
		MobclickAgent.onEvent(this,
				HuPuRes.UMENG_KEY_NETWORK,
				UMENG_MAP);
	}

	public void followTeam(int tid, byte unFollow) {
		initParameter();
		mParams.put(BaseEntity.KEY_TEAM_ID, "" + tid);
		if (unFollow > 0)
			mParams.put(BaseEntity.KEY_UNFOLLOW, "" + unFollow);
		sendRequest(HuPuRes.REQ_METHOD_FOLLOW_TEAM, mParams,
				new HupuHttpHandler(this));
	}

	/**
	 * ��ע��ȡ����������unFollow>0������£�ȡ����ע�����ø�ʵ���������ص����ݡ�
	 * */
	public void followGame(int gId, byte unFollow) {
		followGame(gId, unFollow, new HupuHttpHandler(this));
	}

	/**
	 * ��ע��ȡ����������unFollow>0������£�ȡ����ע
	 * */
	public void followGame(int gId, byte unFollow,
			AsyncHttpResponseHandler handler) {
		mParams.remove(BaseEntity.KEY_UNFOLLOW);
		mParams.put(BaseEntity.KEY_GAME_ID, "" + gId);
		if (unFollow > 0) {
			mParams.put(BaseEntity.KEY_UNFOLLOW, "" + unFollow);
			sendRequest(HuPuRes.REQ_METHOD_FOLLOW_GAME_CANCEL, mParams, handler);
		} else {
			sendRequest(HuPuRes.REQ_METHOD_FOLLOW_GAME, mParams, handler);
		}
	}

	/**
	 * ��ʼ��http���Ͳ��� clientΪ��ѡ��
	 * **/
	public RequestParams initParameter() {
		mParams.clear();
		mParams.put("client", mDeviceId);
		if (mToken != null)
			mParams.put("token", mToken);
		return mParams;
	}

	// ------------------------������ʵʱ�ӿ�---------------------//

	public void registConn(String room) {
		mApp.registActivity(room, this);
	}

	public void reconnect(boolean now) {
		mApp.reconnect(now);
	}

	private String strRoomName;
	/**��ȡ������
	 * @return ������*/
	public String getRoom() {
		return strRoomName;
	}

	public JSONObject jsonRoom;
    /**���÷���*/
	public JSONObject setRoomObj(String room) {
		jsonRoom =getRoomObj();
		strRoomName =room;
		try {
			jsonRoom.put("room", strRoomName);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsonRoom;
	}
	
	/**��ȡroom��������**/
	public JSONObject getRoomObj()
	{
		if (jsonRoom == null) {
			jsonRoom = new JSONObject();

		}
		return jsonRoom;
	}
	
	/**ʹ��Ĭ�ϵĲ������������뷿��**/
	public void joinRoom() {
		mApp.registActivity(strRoomName, this);
		mApp.joinRoom(jsonRoom);
	}
	
	/**���뷿��
	 * @param room ������**/
	public void joinRoom(String room) {
		strRoomName = room;
		mApp.registActivity(strRoomName, this);
		mApp.joinRoom( setRoomObj(room) );
	}

	/**���뷿��
	 * @param room ������**/
	public void emit(String emit,JSONObject obj) {
		mApp.registActivity(strRoomName, this);
		mApp.emit(emit, obj);
	}
	
	/** �뿪room */
	public void leaveRoom() {
		mApp.leaveRoom();
	}

	public void disconnect() {
		mApp.disconnect();
	}

	public void onSocketConnect() {

	}

	public void onSocketDisconnect() {

	}

	public void onSocketError(SocketIOException socketIOException) {

	}

	public void onSocketResp(JSONObject obj) {

	}

	public void setNetTitle() {

	}

	/** ����socket����״̬�� */
	public void updateNetState() {
		Log.d("BaseActivity", "updateNetState  >>>>>>:::::");
	}
	/** ��ʾ�Զ���ĶԻ���*/
	public void showCustomDialog(final int dialogId, int titleId, int msgId,
			int flag, int button1, int button2) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this)
				.setCancelable(true).setTitle(titleId).setMessage(msgId);
		if ((flag & 1) > 0) {
			builder.setPositiveButton(button1,
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							clickPositiveButton(dialogId);
						}
					});
		}
		if ((flag & 2) > 0) {
			builder.setNegativeButton(button2,
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							clickNegativeButton(dialogId);
						}
					});
		}
		mDialog = builder.create();
		mDialog.show();
	}

	public void backToHome() {
		// System.out.println("back home");
		Intent in = new Intent(this, LaunchActivity.class);
		in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(in);
	}

	public void onBackground() {
		mApp.onBackground();
	}

	public void onForeground() {
		// Log.d("baseAct", "onForeground   >>>>>>:::::");
		// SharedPreferencesMgr.init(mApp, "hupugamemate");
		//
		// Intent intent = new Intent(this, HuPuGamemateService.class);
		// intent.putExtra("stop", true);
		// // startService(intent);
		// stopService(intent);
		// Log.d("baseAct", "isServiceRunning   ==true>>>>>>:::::");
		// NotificationManager notificationManager = (NotificationManager)
		// getSystemService(NOTIFICATION_SERVICE);
		// notificationManager.cancelAll();
		mApp.onForeground();
		NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		notificationManager.cancelAll();
	}

	/**
	 * �����жϷ����Ƿ�����.
	 * 
	 * @param context
	 * @param className
	 *            �жϵķ������֣�����+����
	 * @return true ������, false ��������
	 */

	public boolean isServiceRunning(String className) {

		boolean isRunning = false;
		ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		List<ActivityManager.RunningServiceInfo> serviceList = activityManager
				.getRunningServices(Integer.MAX_VALUE);
		if (!(serviceList.size() > 0)) {
			return false;
		}

		for (int i = 0; i < serviceList.size(); i++) {
			if (serviceList.get(i).service.getClassName().equals(className) == true) {
				isRunning = true;
				break;
			}
		}
		return isRunning;

	}

	/** �Ƿ���Ҫ��Ļ����,Ŀǰ���߼��ǣ��Ǳ�������ʱ����Ҫ���� */
	public void setScreenLight(boolean on) {
		
		// ���ø���
		if (on)
			getWindow()
					.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		else
			getWindow().clearFlags(
					WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}
	
}
