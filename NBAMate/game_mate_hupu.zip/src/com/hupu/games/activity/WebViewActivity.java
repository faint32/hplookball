package com.hupu.games.activity;

import java.lang.reflect.InvocationTargetException;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.webkit.DownloadListener;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.common.HuPuRes;
import com.pyj.activity.BaseActivity;
import com.umeng.analytics.MobclickAgent;

public class WebViewActivity extends BaseActivity {

	private WebView mWebView;

	private ImageButton mBtnPre;
	private ImageButton mBtnNext;
	private TextView mTxtTitle;
	private String mStrUrl;

	private View tileBar;
	private View toolBar;
	private View mBtnIn;

	Animation toolbarAnimIn;
	Animation toolbarAnimOut;
	Animation titlebarAnimIn;
	Animation titlebarAnimOut;
	private boolean bVertical;

	@TargetApi(8)
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		mStrUrl = getIntent().getStringExtra("url");
		// getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.layout_webview);
		bVertical = isPortrait();
		mBtnPre = (ImageButton) findViewById(R.id.btn_pre);
		mBtnNext = (ImageButton) findViewById(R.id.btn_next);
		mWebView = (WebView) findViewById(R.id.webview);
		mTxtTitle = (TextView) findViewById(R.id.txt_title);

		tileBar = findViewById(R.id.layout_title_bar);
		toolBar = findViewById(R.id.layout_tool_bar);
		mBtnIn = findViewById(R.id.btn_in);
		MyAnimateListener ma = new MyAnimateListener();
		toolbarAnimIn = AnimationUtils.loadAnimation(this, R.anim.toolbar_in);
		toolbarAnimIn.setAnimationListener(ma);
		toolbarAnimOut = AnimationUtils.loadAnimation(this, R.anim.toolbar_out);
		toolbarAnimOut.setAnimationListener(ma);
		titlebarAnimIn = AnimationUtils.loadAnimation(this, R.anim.titlebar_in);
		titlebarAnimIn.setAnimationListener(ma);
		titlebarAnimOut = AnimationUtils.loadAnimation(this,
				R.anim.titlebar_out);
		// titlebarAnimOut.setAnimationListener(ma);

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				System.out.println("load url =" + url);
				if (url.indexOf(".3gp") != -1 || url.indexOf(".mp4") != -1
						|| url.indexOf(".flv") != -1
						|| url.indexOf("rtsp://") > -1||url.indexOf(".swf") != -1) {
					// Intent intent = new Intent("android.intent.action.VIEW",
					// Uri.parse(url));
					// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					// view.getContext().startActivity(intent);
					showMovie(url);
				} else {
					mStrUrl = url;
					view.loadUrl(url);
				}
				// view.loadUrl(url);
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				setState();
			}

			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				showToast("���س�����");

			}
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				// TODO Auto-generated method stub
				super.onProgressChanged(view, newProgress);
			}

			@Override
			public void onReceivedTitle(WebView view, String title) {
				super.onReceivedTitle(view, title);
				// mTxtTitle.setText(title);
			}
			//
			// @Override
			// public void onShowCustomView(View view, CustomViewCallback
			// callback) {
			// // TODO Auto-generated method stub
			// super.onShowCustomView(view, callback);
			// if (view instanceof FrameLayout) {
			// FrameLayout frame = (FrameLayout) view;
			// if (frame.getFocusedChild() instanceof VideoView) {
			// VideoView video = (VideoView) frame.getFocusedChild();
			// frame.removeView(video);
			// setContentView(video);
			// video.setOnCompletionListener(new OnCompletionListener() {
			//
			// @Override
			// public void onCompletion(MediaPlayer mp) {
			// Log.i("MyWebAct",
			// "LoadData_QRURL --> onCompletion...");
			// mp.stop();
			// // setContentView(R.layout.loaddata_qrurl);
			// }
			// });
			// video.setOnErrorListener(new OnErrorListener() {
			//
			// @Override
			// public boolean onError(MediaPlayer mp, int what,
			// int extra) {
			// Log.i("MyWebAct", "LoadData_QRURL --> onError");
			// return false;
			// }
			// });
			// video.start();
			// }
			// }
			//
			// }
		});

		mWebView.setDownloadListener(new DownloadListener() {

			public void onDownloadStart(String url, String userAgent,
					String contentDisposition, String mimetype,
					long contentLength) {
				if (contentDisposition == null
						|| !contentDisposition.regionMatches(true, 0,
								"attachment", 0, 10)) {
					Intent intent = new Intent(Intent.ACTION_VIEW);
					System.out.println("load url =" + url + "  mimetype="
							+ mimetype);
					intent.setDataAndType(Uri.parse(url), mimetype);
					ResolveInfo info = getPackageManager().resolveActivity(
							intent, PackageManager.MATCH_DEFAULT_ONLY);

					if (info != null) {
						ComponentName myName = getComponentName();
						if (!myName.getPackageName().equals(
								info.activityInfo.packageName)
								|| !myName.getClassName().equals(
										info.activityInfo.name)) {

							try {
								// ʹ��ANDROID���ò�����
								startActivity(intent);
								return;
							} catch (ActivityNotFoundException ex) {
								showToast("��û�а�װ���������뵽Ӧ���г���װ������");
							}
						}
					} else {
						// ���ؿ�ʼ
						// �Զ�������
						 showToast("��û�а�װ���������뵽Ӧ���г���װ������");
					}

				}
			}

		});

		WebSettings ws = mWebView.getSettings();
		ws.setBuiltInZoomControls(true); // ������ʾ���Ű�ť
		ws.setSupportZoom(true); // ֧������
		ws.setJavaScriptEnabled(true);
		ws.setAllowFileAccess(true);
		ws.setUseWideViewPort(true);
		ws.setSupportMultipleWindows(true);
		ws.setRenderPriority(RenderPriority.HIGH);
		// ws.setJavaScriptCanOpenWindowsAutomatically(true);
		ws.setLoadsImagesAutomatically(true);
		// ws.setLightTouchEnabled(true);
		ws.setAppCacheEnabled(true);
		// String as = ws.getUserAgentString();
		// int index = as.indexOf(")");
		// StringBuffer sb = new StringBuffer(as);
		// sb.insert(index, ", compatible iPad");
		// ws.setUserAgentString(sb.toString());
		if (android.os.Build.VERSION.SDK_INT > 7)
			ws.setPluginState(PluginState.ON);
		// else
		ws.setPluginsEnabled(true);
		if (android.os.Build.VERSION.SDK_INT > 6) {
			ws.setAppCacheEnabled(true);
			ws.setLoadWithOverviewMode(true);// completely zoomed out
		}
		ws.setCacheMode(WebSettings.LOAD_DEFAULT);// ���û���ģʽ

		mWebView.loadUrl(mStrUrl);
		

		// mWebView.loadUrl("http://www.whatsmyuseragent.com/");
		setOnClickListener(R.id.btn_browser);
		setOnClickListener(R.id.btn_pre);
		setOnClickListener(R.id.btn_next);
		setOnClickListener(R.id.btn_fresh);
		setOnClickListener(R.id.btn_back);
		setOnClickListener(R.id.btn_out);
		setOnClickListener(R.id.btn_in);
		setState();
	}

	@Override
	public void treatClickEvent(int id) {

		super.treatClickEvent(id);
		switch (id) {
		case R.id.btn_fresh:
			mWebView.reload();
			break;
		case R.id.btn_next:
			goForward();
			break;
		case R.id.btn_pre:
			goBack();
			break;
		case R.id.btn_browser:
			Intent viewIntent = new Intent(Intent.ACTION_VIEW,
					Uri.parse(mStrUrl));
			startActivity(viewIntent);

			break;
		case R.id.btn_back:
			finish();
			break;
		case R.id.btn_out:
			setFullScreen();
			break;
		case R.id.btn_in:
			quitFullScreen();
			break;
		}
	}

	@TargetApi(8)
	private boolean isPortrait() {
		int orientation = 0;
		if (android.os.Build.VERSION.SDK_INT > 7)
			orientation = getWindowManager().getDefaultDisplay().getRotation();
		else
			getWindowManager().getDefaultDisplay().getOrientation();
		if (orientation == Surface.ROTATION_90
				|| orientation == Surface.ROTATION_270) {

			return false;
		}
		return true;
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			bVertical = false;
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_BROWSER_ACTIONS,
					HuPuRes.UMENG_KEY_V2H);
			setFullScreen();
		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			bVertical = true;
			quitFullScreen();
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_BROWSER_ACTIONS,
					HuPuRes.UMENG_KEY_H2V);
		}
	}

	private void setFullScreen() {
		if (bVertical)
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_BROWSER_ACTIONS,
					HuPuRes.UMENG_KEY_V_FULLSCREEN);
		else
			MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_BROWSER_ACTIONS,
					HuPuRes.UMENG_KEY_H_FULLSCREEN);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().getDecorView().invalidate();
		tileBar.setVisibility(View.GONE);
		toolBar.setVisibility(View.GONE);
		// tileBar.setAnimation(titlebarAnimOut);
		toolBar.startAnimation(toolbarAnimOut);
	}

	private void quitFullScreen() {
		tileBar.setAnimation(titlebarAnimIn);
		toolBar.startAnimation(toolbarAnimIn);
		mBtnIn.setVisibility(View.GONE);
		tileBar.setVisibility(View.VISIBLE);
		final WindowManager.LayoutParams attrs = getWindow().getAttributes();
		attrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setAttributes(attrs);
		getWindow()
				.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
	}

	private void goBack() {
		if (mWebView.canGoBack())
			mWebView.goBack();
		setState();

	}

	private void goForward() {
		if (mWebView.canGoForward())
			mWebView.goForward();
		setState();
	}

	private void setState() {
		if (mWebView.canGoBack())
			// mBtnPre.setImageResource(R.drawable.btn_pre);
			mBtnPre.setEnabled(true);
		else
			mBtnPre.setEnabled(false);
		// mBtnPre.setImageResource(R.drawable.btn_pre_disable);
		if (mWebView.canGoForward())
			// mBtnNext.setImageResource(R.drawable.btn_next);
			mBtnNext.setEnabled(true);
		else
			// mBtnNext.setImageResource(R.drawable.btn_next_disable);
			mBtnNext.setEnabled(false);
	}

	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);

		if (mWebView != null) {
			try {
				mWebView.getClass().getMethod("onResume")
						.invoke(mWebView, (Object[]) null);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
		if (isFinishing()) {
			mWebView.loadUrl("about:blank");
			setContentView(new FrameLayout(this));
		}
		if (mWebView != null) {
			// mWebView.stopLoading();
			try {
				mWebView.getClass().getMethod("onPause")
						.invoke(mWebView, (Object[]) null);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void onDestroy() {

		if (mWebView != null) {
			mWebView.stopLoading();
			mWebView.clearHistory();
			// mWebView.destroy();
		}
		super.onDestroy();
	}

	class MyAnimateListener implements AnimationListener {

		@Override
		public void onAnimationEnd(Animation animation) {
			if (animation == toolbarAnimIn)
				toolBar.setVisibility(View.VISIBLE);
			else if (animation == toolbarAnimOut)
				mBtnIn.setVisibility(View.VISIBLE);
			else if (animation == titlebarAnimIn)
				tileBar.setVisibility(View.VISIBLE);

		}

		@Override
		public void onAnimationRepeat(Animation animation) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onAnimationStart(Animation animation) {
			// TODO Auto-generated method stub

		}
	}

	private String getMimeType(String url)
	{
		String extension = MimeTypeMap.getFileExtensionFromUrl(url);
		System.out.println("load extension =" + extension);
		if("3gp".equals(extension))
			return "video/3gpp";
		else if ("mp4".equals(extension))
			return "video/mp4";
		else if ("flv".equals(extension))
			return "video/flv";
		else if ("asf".equals(extension))
			return "video/x-ms-asf";
		return null;
	}
	private void showMovie(String url) {

		Intent intent = null;
        String mime =getMimeType(url);
		if (mime!=null) {
			//����ǲ�����
			intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.parse(url),mime);
			ResolveInfo info = getPackageManager().resolveActivity(intent,
					PackageManager.MATCH_DEFAULT_ONLY);

			if (info != null) {
				ComponentName myName = getComponentName();
				if (!myName.getPackageName().equals(
						info.activityInfo.packageName)
						|| !myName.getClassName()
								.equals(info.activityInfo.name)) {
					try {
						// ʹ��ANDROID���ò�����
						startActivity(intent);
						return;
					} catch (ActivityNotFoundException ex) {
						showToast("��û�а�װ���������뵽Ӧ���г���װ������");
					}
				}
			}
			else
				showToast("��û�а�װ���������뵽Ӧ���г���װ������");
			
		} else {
			
			try {
				intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				startActivity(intent);
			} catch (Exception e) {
				showToast("��û�а�װ��ý�岥�������뵽Ӧ���г���װ������");
				e.printStackTrace();
			}
		}

	}
	// mShowAction = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
	// Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
	// -1.0f, Animation.RELATIVE_TO_SELF, 0.0f);
	// mShowAction.setDuration(500);
	// mHiddenAction = new TranslateAnimation(Animation.RELATIVE_TO_SELF,
	// 0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
	// Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
	// -1.0f);
}
