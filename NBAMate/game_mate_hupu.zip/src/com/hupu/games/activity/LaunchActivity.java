package com.hupu.games.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.hupu.games.R;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.common.SharedPreferencesMgr;
import com.hupu.games.data.AdressEntity;
import com.hupu.games.data.GetFollowTeamsResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.pyj.common.DeviceInfo;
import com.pyj.common.DialogRes;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.ReportPolicy;
import com.umeng.update.UmengUpdateAgent;

/**
 * ��Ӧ��ʱ�ļ���ҳ
 * ��һ ͨ��http����ȡredirect��ip��ַ��
 * �ڶ� ����ǳ���ʹ�û������û�ɾ���˱������ݣ��ȵ������ͬ���¹�ע������б�
 * */
public class LaunchActivity extends HupuBaseActivity {

	
	boolean bFirst;

	private boolean toHome;

	private boolean bGetTeams;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setUMeng();
		bFirst =  mApp.isFirst();//�����߼�
		// bFirst = true;
		setContentView(R.layout.layout_launch);
		// ��wifi�����Ҳ�ܸ���	
//		 loadSocketServer(false);
		if (bFirst) {			
			//�鿴�Ƿ����������á�
			getTeamsFromWeb() ;
		} else {
			bGetTeams=true;
			toHome = true;
			new Handler().postDelayed(new Runnable() {
				
				@Override
				public void run() {
					startToNextScreen();
				}
			},500);
			
		}
	}

	private void setUMeng()
	{
		//ͳ�ƴ�����־
		MobclickAgent.onError(this);
		//�κ�����¶�Ҫ����
		UmengUpdateAgent.setUpdateOnlyWifi(false);
		//ʵʱ����umeng
		MobclickAgent.setDefaultReportPolicy(this, ReportPolicy.REALTIME);
	}
	
	private void startToNextScreen() {
		if (DeviceInfo.isNetWorkEnable(this)) {	
			if (bGetTeams)
			{
				if(toHome)
				{
						//Intent intent = new Intent(this, HuPuIndexActivity.class);
//						Intent intent = new Intent(this, TabIndexActivity.class);
						Intent intent = new Intent(this, HupuSlidingActivity.class);
						intent.putExtra("byIcon", true);// ��ʶ�û��ǵ������ġ�
						intent.putExtra("load", true);
						startActivity(intent);
				}
				else
				{
					Intent intent = new Intent(this, HupuLaunchActivity.class);
					startActivity(intent);
				}
				finish();
			}
		
		} else {
			showDialog(DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE);
		}
	
	}




	@Override
	public void clickPositiveButton(int dialogId) {
		// System.out.println("clickPositiveButton ="+dialogId);
		super.clickPositiveButton(dialogId);
		if (DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE == dialogId) {
				getTeamsFromWeb() ;
		}

	}


	@Override
	public void clickNegativeButton(int dialogId) {

		if (DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE == dialogId) {
			quit();
		}
		super.clickNegativeButton(dialogId);
	}

	@Override
	public void onErrResponse(Throwable error, String content,
			boolean isBackGroundThread) {
		showDialog(DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE);

	}


	@Override
	public void onReqResponse(Object o, int methodId) {
		super.onReqResponse(o, methodId);
		if (methodId == HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS) {
			GetFollowTeamsResp entity = (GetFollowTeamsResp) o;
			if (entity != null && entity.mListTeams != null) {
				bGetTeams=true;
				if(entity.mListTeams.size()>0)
				{
					toHome = true;
					mApp.insertTeamsToDB( entity.mListTeams );
				}				
			}
			startToNextScreen();	
		}
	}

	/** ����������ȡ�û�����ע������б� */
	private void getTeamsFromWeb() {
		initParameter();
		sendRequest(HuPuRes.REQ_METHOD_GET_FOLLOW_TEAMS, mParams,
				new HupuHttpHandler(this),true);
	}
	
	@Override
	protected Dialog onCreateDialog(final int id) {
		int titleId = 0;
		int msgId = 0;
		int flag = 0;
		int left = 0;
		int right = 0;
		if (DialogRes.DIALOG_ID_NETWORK_NOT_AVALIABLE == id) {
			titleId = R.string.STR_ERR_MSG;
			msgId = R.string.MSG_NO_AVAILABLE_NET;
			left = R.string.STR_RETRY;
			right = R.string.STR_QUIT;
			flag = TOW_BUTTONS;
		} else
			return super.onCreateDialog(id);
		AlertDialog.Builder builder = new AlertDialog.Builder(this)
				.setCancelable(true).setTitle(titleId).setMessage(msgId);
		if ((flag & 1) > 0) {
			builder.setPositiveButton(left,
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							clickPositiveButton(id);
						}
					});
		}
		if ((flag & 2) > 0) {
			builder.setNegativeButton(right,
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							clickNegativeButton(id);
						}
					});
		}
		mDialog = builder.create();
		return mDialog;
	}

	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}
}
