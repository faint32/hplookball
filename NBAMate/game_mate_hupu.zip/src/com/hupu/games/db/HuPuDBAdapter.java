package com.hupu.games.db;

import java.util.ArrayList;
import java.util.LinkedList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class HuPuDBAdapter {

	// Database open/upgrade helper
	private HuPuDBHelp dbHelper;
	Context context;
	final int DATABASE_VERSION = 2;
    static final int MAX_RECORD=20; 
	public HuPuDBAdapter(Context _context) {
		context = _context;
		dbHelper = new HuPuDBHelp(context, DATABASE_VERSION);
	}

	SQLiteDatabase db;

	public SQLiteDatabase open() {
		if (db != null && db.isOpen())
			return db;
		try {
			db = dbHelper.getWritableDatabase();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return db;
	}

	public void close() {
		if (db != null && db.isOpen())
			db.close();
	}

	public long insertTeam(int teamId,String teamName) {
		open();
		ContentValues contentValues = new ContentValues();
		contentValues.put(HuPuDBHelp.KEY_TEAM_ID, teamId);
		if(teamName!=null)
			contentValues.put(HuPuDBHelp.KEY_TEAM_NAME, teamName);
		long l = db.insert(HuPuDBHelp.TABLE_TEAM_FOLLOW, null, contentValues);
		db.close();
		return l;
	}
	
	public void insertTeams(LinkedList<Integer> list)
	{
		open();
		db.beginTransaction();        //�ֶ����ÿ�ʼ����
		//���ݲ������ѭ��
        for(int i=0;i<list.size();i++)
        {
        	ContentValues contentValues = new ContentValues();
    		contentValues.put(HuPuDBHelp.KEY_TEAM_ID, list.get(i));
    		 db.insert(HuPuDBHelp.TABLE_TEAM_FOLLOW, null, contentValues);
        }
		db.setTransactionSuccessful();        //�����������ɹ��������û��Զ��ع����ύ
		db.endTransaction();        //������� 
		db.close();
	}
	public long insertGame(String gId,String  startTime) {
		open();
		ContentValues contentValues = new ContentValues();
		contentValues.put(HuPuDBHelp.KEY_GAME_ID, gId);
		contentValues.put(HuPuDBHelp.KEY_GAME_START_TIME, startTime);
		long l = db.insert(HuPuDBHelp.TABLE_GAME_FOLLOW, null, contentValues);
		db.close();
		return l;
	}

	public void insertIsFirst() {
		open();
		ContentValues contentValues = new ContentValues();
		contentValues.put(HuPuDBHelp.KEY_IS_FIRST, 1);
		db.insert(HuPuDBHelp.TABLE_VERSION, null, contentValues);
		db.close();
	}

	public boolean isFirst()
	{
		open();
		Cursor cs=getAllEntries(HuPuDBHelp.TABLE_VERSION) ;
		int size=cs.getCount();
		db.close();
		return size==0;
	}
	

	// �õ����м�¼
	public Cursor getAllEntries(String table_name) {
		return db.query(table_name, null, null, null, null, null, null);
	}

	public int delTeam(int tId) {
		open();
		int i = db.delete(HuPuDBHelp.TABLE_TEAM_FOLLOW, HuPuDBHelp.KEY_TEAM_ID+"='" + tId + "'", null);
		close();
		return i;
	}

	public void delTeams() {
		open();
		db.execSQL("DELETE  FROM "+ HuPuDBHelp.TABLE_TEAM_FOLLOW);
		close();
	}
	
	public int delGame(String gId) {
		open();
		int i = db.delete(HuPuDBHelp.TABLE_GAME_FOLLOW, HuPuDBHelp.KEY_GAME_ID+"='" + gId + "'", null);
		close();
		return i;
	}
	
	
	public LinkedList<Integer> getFollowTeams() {
		LinkedList<Integer> teams = new LinkedList<Integer>();
		open();
		Cursor c = db.rawQuery("select * from " + HuPuDBHelp.TABLE_TEAM_FOLLOW, null);
		if (c.getCount() > 0) {		
			while (c.moveToNext()) {
				teams.add(c.getInt(0));
			}
			c.close();
		}
		close();
		return teams;
	}

	public LinkedList<Integer> getFollowGames() {
		LinkedList<Integer> teams = new LinkedList<Integer>();
		open();
		Cursor c = db.rawQuery("select * from " + HuPuDBHelp.TABLE_GAME_FOLLOW, null);
		if (c.getCount() > 0) {		
			while (c.moveToNext()) {
				teams.add(c.getInt(0));
			}
			c.close();
		}
		close();
		return teams;
	}
	
	public Integer delOverTimeGames(String date)
	{
		open();
		int i = db.delete(HuPuDBHelp.TABLE_GAME_FOLLOW, HuPuDBHelp.KEY_GAME_START_TIME+"<" + date, null);
		close();
		return i;
	}
}
