package com.hupu.games.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HuPuDBHelp extends SQLiteOpenHelper {

	public static final String DB_NAME = "hupu.db";

	public static final String TABLE_VERSION = "t_version";
	public static final String TABLE_TEAM_FOLLOW = "team_follow";
	public static final String TABLE_GAME_FOLLOW = "game_follow";
	public static final String TABLE_FOLLOW_TASK = "follow_task";

	public static final String KEY_TEAM_ID = "tId";

	public static final String KEY_TEAM_NAME = "tName";
	/** ����id */
	public static final String KEY_GAME_ID = "gId";
	/** ������ʼʱ�� */
	public static final String KEY_GAME_START_TIME = "gTime";

	public static final String KEY_ID = "_ID";
	/** 0������1��� */
	public static final String KEY_TYPE = "_type";
	/** 0��ע��1ȡ�� */
	public static final String KEY_IS_FOLLOW = "isFollow";

	public static final String KEY_IS_FIRST = "isFist";
	private static final String CREATE_TEAM_FOLLOW = "create table "
			+ TABLE_TEAM_FOLLOW + " (  " + KEY_TEAM_ID + " INTEGER, "
			+ KEY_TEAM_NAME + "  VARCHAR(25), " + "PRIMARY KEY(" + KEY_TEAM_ID
			+ "));";

	private static final String CREATE_GAME_FOLLOW = "create table "
			+ TABLE_GAME_FOLLOW + " (  " + KEY_GAME_ID + " INTEGER, "
			+ KEY_GAME_START_TIME + " integer, " + "PRIMARY KEY(" + KEY_GAME_ID
			+ "));";

	private static final String CREATE_FOLLOW_TASK = "create table "
			+ TABLE_FOLLOW_TASK + " (  " + KEY_ID + " INTEGER, " + KEY_TYPE
			+ " integer, " + KEY_IS_FOLLOW + " integer, " + "PRIMARY KEY("
			+ KEY_ID + "));";

	private static final String CREATE_VERSION = "create table "
			+ TABLE_VERSION + " (  " + KEY_IS_FIRST + " integer" + ");";

	HuPuDBHelp(Context context, int version) {
		super(context, DB_NAME, null, version);

	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL(CREATE_TEAM_FOLLOW);
		db.execSQL(CREATE_GAME_FOLLOW);
		db.execSQL(CREATE_FOLLOW_TASK);
		db.execSQL(CREATE_VERSION);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		if (newVersion == 2) {
			if (!tabIsExist(CREATE_VERSION))
				db.execSQL(CREATE_VERSION);
		}

	}

	/**
	 * �ж�ĳ�ű��Ƿ����
	 * 
	 * @param tabName
	 *            ����
	 * @return
	 */
	public boolean tabIsExist(String tabName) {
		boolean result = false;
		if (tabName == null) {
			return false;
		}
		SQLiteDatabase db = null;
		Cursor cursor = null;
		try {
			db = this.getReadableDatabase();
			String sql = "select count(*) as c from sqlite_master where type ='table' and name ='"
					+ tabName.trim() + "' ";
			cursor = db.rawQuery(sql, null);
			if (cursor.moveToNext()) {
				int count = cursor.getInt(0);
				if (count > 0) {
					result = true;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return result;
	}
}
