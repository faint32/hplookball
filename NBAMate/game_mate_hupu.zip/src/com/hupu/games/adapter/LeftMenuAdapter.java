package com.hupu.games.adapter;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.hupu.games.R;

public class LeftMenuAdapter extends BaseExpandableListAdapter {

	LayoutInflater inflater;
	private String groups[];
	private static int items[]={  R.drawable.btn_game_selector,
	  R.drawable.btn_news_selector,
	  R.drawable.btn_video_selector,
	  R.drawable.btn_standing_selector};
	
	private static int items_over[]={  R.drawable.btn_game_hover,
		  R.drawable.btn_news_hover,
		  R.drawable.btn_video_hover,
		  R.drawable.btn_standings_hover};
	
	private String[] itemText;

//	private int height;
	
	public LeftMenuAdapter(Context context) {
		inflater = LayoutInflater.from(context);
		groups = context.getResources().getStringArray(R.array.menu_group);
		//items = context.getResources().getIntArray(R.array.menu_item);
		itemText=context.getResources().getStringArray(R.array.menu_item_text);
//		DisplayMetrics metric = new DisplayMetrics();
//		((Activity)context).getWindowManager().getDefaultDisplay().getMetrics(metric);
//        float density = metric.density;  // ��Ļ�ܶȣ�0.75 / 1.0 / 1.5��
//        height =(int)(50*density);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {

		return null;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {

		return 0;
	}

	public void setPosition(int g,int c)
	{
		selectPosition =c;
		selectGroupPosition =g;
		notifyDataSetChanged();
	}
	
	int selectPosition;
	int selectGroupPosition;
	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		View v =inflater.inflate(R.layout.menu_item_child,
				null);
		TextView txt = (TextView) v.findViewById(R.id.img_menu_child);

		if(selectPosition == childPosition && selectGroupPosition ==groupPosition)
		{
			txt.setBackgroundResource(R.drawable.bg_menu_hover);
			txt.setTextColor(0xffffffff);
			txt.setCompoundDrawablesWithIntrinsicBounds(items_over[childPosition], 0, 0, 0);
		}
		else
		{
			txt.setBackgroundResource(R.drawable.item_menu_selector);
			txt.setCompoundDrawablesWithIntrinsicBounds(items[childPosition], 0, 0, 0);
		}
		txt.setText(itemText[childPosition]);
		return v;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
//		if (items != null)
//			return items.length;
//		return 0;
		if(groupPosition ==0)
			return 4;
		else 
			return 3;
	}

	@Override
	public Object getGroup(int groupPosition) {

		return null;
	}

	@Override
	public int getGroupCount() {
		if (groups != null)
			return groups.length;
		return 0;
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		View v =inflater.inflate(R.layout.menu_item_group,
				null);
		TextView tv = (TextView)v.findViewById(R.id.txt_menu_group);
		tv.setText(groups[groupPosition]);
		tv.setBackgroundColor(0);
		return v;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return true;
	}

}
