package com.hupu.games.adapter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.data.CBAData;
import com.hupu.games.data.CBAResp;
import com.hupu.games.data.GameEntity;
import com.pyj.common.MyUtility;
import com.umeng.common.Log;

public class CBAGamesListAdapter extends SectionedBaseAdapter  {


	private LinkedHashMap<String, ArrayList<CBAData>> mListGames;
	private ArrayList<String> mKeys;
	private LayoutInflater mInflater;


	public CBAGamesListAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	


	public void setData(CBAResp en) {
		mListGames =en.mMap;
		mKeys=en.mKeys;
		notifyDataSetChanged();
	}



	private static final int num_res[] = { R.drawable.num0, R.drawable.num1,
			R.drawable.num2, R.drawable.num3, R.drawable.num4, R.drawable.num5,
			R.drawable.num6, R.drawable.num7, R.drawable.num8, R.drawable.num9, };

	private void setSore(Holder holder, int homeScore, int awayScore) {
		int hundred = homeScore / 100;
		int tens = (homeScore % 100) / 10;
		int single = homeScore % 10;

		if (hundred > 0) {
			holder.txtHomeScore1.setVisibility(View.VISIBLE);
			holder.txtHomeScore1.setBackgroundResource(num_res[hundred]);
		} else
			holder.txtHomeScore1.setVisibility(View.GONE);
		if (homeScore >= 10) {
			holder.txtHomeScore2.setVisibility(View.VISIBLE);
			holder.txtHomeScore2.setBackgroundResource(num_res[tens]);
		} else
			holder.txtHomeScore2.setVisibility(View.GONE);
		holder.txtHomeScore3.setBackgroundResource(num_res[single]);

		hundred = awayScore / 100;
		tens = (awayScore % 100) / 10;
		single = awayScore % 10;
		if (hundred > 0) {
			holder.txtAwayScore1.setVisibility(View.VISIBLE);
			holder.txtAwayScore1.setBackgroundResource(num_res[hundred]);
		} else
			holder.txtAwayScore1.setVisibility(View.GONE);
		if (awayScore >= 10) {
			holder.txtAwayScore2.setVisibility(View.VISIBLE);
			holder.txtAwayScore2.setBackgroundResource(num_res[tens]);
		} else
			holder.txtAwayScore2.setVisibility(View.GONE);
		holder.txtAwayScore3.setBackgroundResource(num_res[single]);

	}

	static class Holder {
		// ��һ��
		TextView txtHomeName;
		TextView txtAwayName;

		// �ڶ���
		View layoutScore;
		TextView txtStatus;
		TextView txtHomeScore1;
		TextView txtHomeScore2;
		TextView txtHomeScore3;

		TextView txtAwayScore1;
		TextView txtAwayScore2;
		TextView txtAwayScore3;

		TextView txtInfo;

	}

	static class Header
	{
		TextView txtDate;
	}
	@Override
	public CBAData getItem(int section, int position) {
		if(section ==-1 ||position==-1 )
			return null;
		if(mListGames!= null )
		{
			return mListGames.get(mKeys.get(section)).get(position);
		}
		return null;
	}

	public CBAData getItemAt(int pos) {
		if(mListGames!= null )
		{
			int section =getSectionForPosition(pos);
			int child =getPositionInSectionForPosition(pos);
			return getItem(section,  child);
			
		}
		return null;
	}
	
	@Override
	public long getItemId(int section, int position) {
		
		return 0;
	}

	@Override
	public int getSectionCount() {
		if(mKeys!=null)
			return mKeys.size();
		else
			return 0;
	}

	@Override
	public int getCountForSection(int section) {
		
		if(mListGames!= null )
		{
			String key =mKeys.get(section);
			ArrayList<CBAData> datas =mListGames.get(key);
//			Log.d("head section","section"+section+";  size ="+size );
			return datas.size();
		}
		else
			return 0;
	}

	@Override
	public View getItemView(int section, int position, View convertView,
			ViewGroup parent) {

		CBAData entity = getItem(section,position);
		Holder holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_cba_team, null);
			holder = new Holder();
			holder.txtHomeName = (TextView) convertView
					.findViewById(R.id.txt_home_name);
			holder.txtAwayName = (TextView) convertView
					.findViewById(R.id.txt_away_name);
			holder.txtStatus = (TextView) convertView
					.findViewById(R.id.txt_status);
			holder.txtHomeScore1 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore1);
			holder.txtHomeScore2 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore2);
			holder.txtHomeScore3 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore3);

			holder.txtAwayScore1 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore1);
			holder.txtAwayScore2 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore2);
			holder.txtAwayScore3 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore3);

			holder.layoutScore = convertView.findViewById(R.id.layout_sore);
			holder.txtInfo = (TextView) convertView.findViewById(R.id.txt_info);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		holder.txtHomeName.setText(entity.str_home_name);
		holder.txtAwayName.setText(entity.str_away_name);
		if (entity.byt_status == CBAData.STATUS_WAITING) {
			// �ȴ���ʼ
			holder.layoutScore.setVisibility(View.GONE);
			holder.txtStatus.setVisibility(View.VISIBLE);
			holder.txtStatus.setText(MyUtility
					.getStartTime(entity.l_begin_time * 1000));	
		} else if (entity.byt_status == CBAData.STATUS_START) {
			// �Ѿ���ʼ
			holder.layoutScore.setVisibility(View.VISIBLE);
			holder.txtStatus.setVisibility(View.GONE);
			setSore(holder, entity.i_home_score, entity.i_away_score);		
		} else {
			// ����
			holder.layoutScore.setVisibility(View.VISIBLE);
			holder.txtStatus.setVisibility(View.GONE);
			setSore(holder, entity.i_home_score, entity.i_away_score);
		}
		if (entity.str_process != null)
			holder.txtInfo.setText(entity.str_process);
		return convertView;
	}

	@Override
	public View getSectionHeaderView(int section, View convertView,
			ViewGroup parent) {
		Header header =null;
		if(convertView==null)
		{
			convertView = mInflater.inflate(R.layout.item_cba_header, null);
			header =new Header();
			header.txtDate =(TextView)convertView.findViewById(R.id.txt_date);
			convertView.setTag(header);
		}
		else 
			header=(Header)convertView.getTag();
		if(mKeys!=null)
			header.txtDate.setText(mKeys.get(section));
		return convertView;
	}
}
