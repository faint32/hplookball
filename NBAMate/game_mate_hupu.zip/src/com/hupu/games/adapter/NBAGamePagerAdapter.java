package com.hupu.games.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import com.hupu.games.R;
import com.hupu.games.data.GamesResp;
import com.hupu.games.fragment.GameFragment;
import com.pyj.common.MyUtility;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;

public class NBAGamePagerAdapter extends PagerAdapter {

	private HashMap<Long, GamesResp> mGamesAdapter;

	private LinkedHashMap<Long, GamesListAdapter> mAdapterList;

	/** ʱ���б� */
	LinkedList<Long> dateList;

	private long mToday;

	private int offset;

	public final static int INITSIZE = 250;

	LayoutInflater mLayoutInflater;

	private OnClickListener mClick;

	Context context;

	public NBAGamePagerAdapter(Context ctx, OnClickListener click) {
		context = ctx;
		mLayoutInflater = LayoutInflater.from(ctx);
		mClick = click;
		dateList = new LinkedList<Long>();
		mAdapterList = new LinkedHashMap<Long, GamesListAdapter>();
		mGamesAdapter = new HashMap<Long, GamesResp>();
	}

	@Override
	public int getCount() {
		return INITSIZE << 1;
	}

	public int getRealCount() {
		if (mAdapterList != null)
			return 0;
		return mAdapterList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

	@Override
	public void destroyItem(View container, int position, Object object) {
		((ViewPager) container).removeView((View) object);
	}

	@Override
	public Object instantiateItem(View container, int position) {
		Log.d("instantiateItem", "position");
		View v = mLayoutInflater.inflate(R.layout.fragment_game_list, null);
		ListView listview = (ListView) v.findViewById(R.id.list_games);
		GamesListAdapter adapter = new GamesListAdapter(context, mClick);
		listview.setAdapter(adapter);
		mAdapterList.put(getDate(position), adapter);
		((ViewPager) container).addView(v, 0);
		return v;
	}

	public void setToday(long today) {
		mToday = today;
	}

	public void setDay(long today) {
		dateList.add(today);
	}

	public void setPreDate(List<Long> l) {
		if (l != null) {
			if (!dateList.contains(l.get(0))) {
				dateList.addAll(0, l);
				offset += l.size();
			}
		}
		// this.notifyDataSetChanged();
	}

	public void setNextDate(List<Long> l) {
		if (l != null) {
			if (!dateList.contains(l.get(0)))
				dateList.addAll(dateList.size(), l);
		}
	}

	public boolean hasData(int pos) {
		if (pos - INITSIZE + offset < 0
				|| pos - INITSIZE + offset >= dateList.size()) {
			long date = dateList.get(pos - INITSIZE + offset);
			return mGamesAdapter.get(date) != null;
		}
		return false;
	}

	@Override
	public CharSequence getPageTitle(int position) {
		if (position - INITSIZE + offset < 0
				|| position - INITSIZE + offset >= dateList.size())
			return null;
		long date = dateList.get(position - INITSIZE + offset);
		if (date == mToday)
			return "����";
		return MyUtility.getFormateDate(date * 1000);
	}

	public void setFragmentData(long date, GamesResp entity, boolean keep) {

		if (keep) {
			GamesResp temp = mGamesAdapter.get(date);
			if (temp != null) {
				int size = temp.mGameList.size();
				int oldIndex = 0;
				for (int i = 0; i < size; i++) {
					// ʵʱ�������ݻ��������������˳��仯��������Ҫ��λ�ϴα���ı�����λ�ã�
					oldIndex = temp.mGameIdList
							.indexOf(entity.mGameList.get(i).i_gId);
					// System.out.println("old index="+oldIndex);
					// ʵʱ�������ݻ���������Ĳ�������ע��Ϣ��������Ҫ���ϴα���ı��������ݸ��ƹ�ȥ��
					entity.mGameList.get(i).i_isFollow = temp.mGameList
							.get(oldIndex).i_isFollow;
				}
			}
		}
		mGamesAdapter.put(date, entity);
		GamesListAdapter tmp = mAdapterList.get(date);

		if (tmp != null) {
			tmp.setData(entity.mGameList);
		}

	}

	public GamesResp getData(long date) {
		return mGamesAdapter.get(date);
	}

	/** ���±�����ע��״̬ */
	public void updateFollow(long date, int gId, int follow) {
		GamesListAdapter tmp = mAdapterList.get(date);
		GamesResp temp = mGamesAdapter.get(date);
		int pos = temp.mGameIdList.indexOf(gId);
		if (pos > -1) {
			temp.mGameList.get(pos).i_isFollow = follow;
			tmp.setFollow(pos, follow);
		}
	}

	public int getHeadNum(int cur) {
		return dateList.size() - (cur - INITSIZE + offset);
	}

	public int getTailNum(int cur) {
		return cur - INITSIZE + offset;
	}

	public long getDate(int pos) {
		if (dateList.size() == 0)
			return 0;
		if (pos - INITSIZE + offset < 0
				|| pos - INITSIZE + offset >= dateList.size())
			return -1;
		return dateList.get(pos - INITSIZE + offset);
	}
}
