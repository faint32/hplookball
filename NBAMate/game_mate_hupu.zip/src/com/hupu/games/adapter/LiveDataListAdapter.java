package com.hupu.games.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.common.FinalBitmap;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.LiveEntity;
import com.hupu.games.data.TeamValueEntity;
import com.umeng.common.Log;

public class LiveDataListAdapter extends BaseAdapter {

	private ArrayList<LiveEntity> mLiveList;

	private LayoutInflater mInflater;

	// private String strHomeName;
	// private String strAwayName;
	private int i_homeColor;
	private int i_awayColor;

	private int i_bg_gray;
	private int i_txt_gray;
	FinalBitmap fb;

	OnClickListener click;

	public LiveDataListAdapter(Context context, int homeId, int awayId,
			OnClickListener c) {
		mInflater = LayoutInflater.from(context);
		TeamValueEntity entity = HuPuApp.getTeamData(homeId);
		// strHomeName = entity.str_name;
		i_homeColor = entity.i_color;
		entity = HuPuApp.getTeamData(awayId);
		// strAwayName =entity.str_name;
		i_awayColor = entity.i_color;
		// System.out.println("strHomeName="+strHomeName
		// +"strAwayName="+strAwayName);
		Resources res = context.getResources();
		i_bg_gray = res.getColor(R.color.list_item_bg);
		i_txt_gray = res.getColor(R.color.txt_status);

		click = c;
		fb =FinalBitmap.create(context,HuPuRes.getCahePath(context));
		fb.configLoadingImage(R.drawable.live_default);
	}

	@Override
	public int getCount() {
		if (mLiveList == null)
			return 0;
		return mLiveList.size();
	}

	@Override
	public LiveEntity getItem(int arg0) {
		if (mLiveList == null)
			return null;
		return mLiveList.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	public void setData(ArrayList<LiveEntity> gameList) {
		mLiveList = gameList;
		notifyDataSetChanged();
	}

	public void setData() {
	}

	public ArrayList<LiveEntity> appendData(ArrayList<LiveEntity> gameList) {
		if (mLiveList == null)
			mLiveList = new ArrayList<LiveEntity>();
		mLiveList.addAll(gameList);
		notifyDataSetChanged();
		return mLiveList;
	}

	public ArrayList<LiveEntity> addDataToHead(ArrayList<LiveEntity> gameList) {
		if (mLiveList == null)
			mLiveList = new ArrayList<LiveEntity>();
		mLiveList.addAll(0, gameList);
		notifyDataSetChanged();
		return mLiveList;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// System.out.print("GamesListAdapter getView pos =" + position);
		LiveEntity entity = mLiveList.get(position);
		Holder holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_live_msg, null);
			holder = new Holder();
			holder.txtTeamName = (TextView) convertView
					.findViewById(R.id.txt_team);
			holder.txtTime = (TextView) convertView.findViewById(R.id.txt_time);
			holder.txtEvent = (TextView) convertView
					.findViewById(R.id.txt_event);
			holder.split = convertView.findViewById(R.id.view_split);
			holder.img = (ImageView) convertView.findViewById(R.id.img_live);

			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		if (entity.byt_team == 0) {
			holder.txtTeamName.setVisibility(View.GONE);
			holder.split.setBackgroundColor(0xff666666);
			holder.txtTime.setBackgroundColor(i_bg_gray);
			// holder.txtEvent.setTextColor(i_txt_gray);
			holder.txtEvent.setTextColor(Color.WHITE);
		} else {
			holder.txtTeamName.setVisibility(View.VISIBLE);
			if (entity.byt_team == 1) {
				// holder.txtTeamName.setText(strHomeName);
				holder.txtTeamName.setText("��");
				holder.split.setBackgroundColor(i_homeColor);
			} else {
				// holder.txtTeamName.setText(strAwayName);
				holder.txtTeamName.setText("��");
				holder.split.setBackgroundColor(i_awayColor);
			}
			holder.txtTime.setBackgroundColor(Color.BLACK);
			holder.txtEvent.setTextColor(Color.WHITE);
		}
		holder.txtTime.setText(entity.i_endTime);
		// �仯������ɫ
		if (entity.i_color != -1)
			holder.txtEvent.setTextColor(entity.i_color);
		 System.out.print("str_img_thumb=" +  entity.str_img_thumb);
		// ��ʾͼƬ
		if (entity.str_img_thumb != null) {
			holder.img.setVisibility(View.VISIBLE);		
			Log.d("str_img_thumb", entity.str_img_thumb);
			fb.display(holder.img, entity.str_img_thumb);
			holder.img.setClickable(true);
			holder.img.setTag(entity.str_img);
			holder.img.setOnClickListener(click);
		} else
			holder.img.setVisibility(View.GONE);
		// ������ת

		holder.txtEvent.setClickable(true);
		holder.txtEvent.setOnClickListener(click);
		holder.txtEvent.setTag(entity.str_link);

		
		
		holder.txtEvent.setText(entity.str_event);

		return convertView;
	}

	static class Holder {
		// ��һ��
		TextView txtTeamName;
		TextView txtTime;
		TextView txtEvent;
		View split;
		ImageView img;

	}

}
