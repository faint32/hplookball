package com.hupu.games.adapter;

import java.util.ArrayList;
import java.util.LinkedList;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.data.LiveEntity;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.data.TeamRankEntity;
import com.hupu.games.data.TeamValueEntity;

public class StandingsListAdapter extends BaseAdapter {

	private StandingsResp mResp;

	private LayoutInflater mInflater;

   private int frame;
   
   private int i_color_text;
   
	public StandingsListAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
		i_color_text =context.getResources().getColor(R.color.txt_status);
	}

	@Override
	public int getCount() {
		if (mResp == null)
			return 0;
		if(frame==0)
			return mResp.mListEast.size();
		else
			return mResp.mListWest.size();
	}

	@Override
	public TeamRankEntity getItem(int arg0) {
		if (mResp == null)
			return null;
		if(frame==0)
			return mResp.mListEast.get(arg0);
		else
			return mResp.mListWest.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}


	public void setData(StandingsResp resp) {
		mResp = resp;
		notifyDataSetChanged();
	}

	public void switchToWest()
	{
		frame =1;
		notifyDataSetChanged();
	}
	public void switchToEast(){
		frame =0;
		notifyDataSetChanged();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		TeamRankEntity entity = getItem(position);
		Holder holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_standings, null);
			holder = new Holder();
			holder.txtRank =(TextView)convertView.findViewById(R.id.txt_rank);
			holder.txtTeamName=(TextView)convertView.findViewById(R.id.txt_team);
			holder.txtWin=(TextView)convertView.findViewById(R.id.txt_win);
			holder. txtLost=(TextView)convertView.findViewById(R.id.txt_lost);
			holder.txtDif=(TextView)convertView.findViewById(R.id.txt_dif);
			holder.txtStrk=(TextView)convertView.findViewById(R.id.txt_status);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();

		}
		if(position>7)
		{
		
			convertView.setBackgroundResource(R.drawable.bg_list_standings_2);
			holder.txtRank.setTextColor(i_color_text);
			holder.txtTeamName.setTextColor(i_color_text);
			holder.txtWin.setTextColor(i_color_text);
			holder. txtLost.setTextColor(i_color_text);
			holder.txtDif.setTextColor(i_color_text);
			holder.txtStrk.setTextColor(i_color_text);
	
		}
		else
		{
			
			convertView.setBackgroundResource(R.drawable.bg_list_standings_1);
			holder.txtRank.setTextColor(Color.WHITE);
			holder.txtTeamName.setTextColor(Color.WHITE);
			holder.txtWin.setTextColor(Color.WHITE);
			holder. txtLost.setTextColor(Color.WHITE);
			holder.txtDif.setTextColor(Color.WHITE);
			holder.txtStrk.setTextColor(Color.WHITE);
		}
			
		holder.txtRank.setText(position+1+"");
		holder.txtTeamName.setText(entity.str_name);
		holder.txtWin.setText(entity.i_win+"");
		holder. txtLost.setText(entity.i_lost+"");
		holder.txtDif.setText(entity.i_gb+"");
		holder.txtStrk.setText(entity.str_strk);
		
		return convertView;
	}

	static class Holder {
		// ��һ��
		TextView txtRank;
		TextView txtTeamName;
		TextView txtWin;
		TextView txtLost;
		TextView txtDif;
		TextView txtStrk;
	}

}
