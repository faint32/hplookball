package com.hupu.games.adapter;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONObject;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.hupu.games.R;
import com.hupu.games.HuPuApp;
import com.hupu.games.activity.HupuDataActivity.BoxscoreDatas;
import com.hupu.games.data.BoxScoreResp;
import com.hupu.games.data.PlayerEntity;

/**
 * ����ͳ������
 * */
public class GameDataListAdapter extends SectionedBaseAdapter {

	private LinkedList<PlayerEntity> mListPLay;
	private LinkedList<String> mListPLayerNames;
	// private LinkedHashMap<String, PlayerEntity> mMapPlayer;
	private LayoutInflater mInflater;

	// LinkedHashMap<String, String> mapTitle;
	private LinkedList<String> mListKeys;
	private LinkedList<String> mListTitles;

	private LinkedList<String> mListPortraitKeys;
	private LinkedList<String> mListPortraitTitles;

	private int i_homeId;
	private int i_awayId;
	/** ������Ա���� */
	private int i_homeSize;
	private int i_awaySize;
	private int i_titleSize;

	private LinkedHashMap<String, String> mMapHomeTotal;

	private LinkedHashMap<String, String> mMapAwayTotal;
	// ����������
	private String str_home_fg;
	private String str_home_tp;
	private String str_home_ft;
	// �Ͷ�������
	private String str_away_fg;
	private String str_away_tp;
	private String str_away_ft;

	int fgIndex = -1;
	int tpIndex = -1;
	int ftIndex = -1;
	int clrMain;
	int clrSub;
	int clrTxt;

	private boolean bCBA;
	private String homeName;
	private String awayName;

	public GameDataListAdapter(Context context, int hId, int aId) {
		mInflater = LayoutInflater.from(context);
		i_homeId = hId;
		i_awayId = aId;
		clrMain = context.getResources().getColor(R.color.dark_gray);
		clrSub = context.getResources().getColor(R.color.list_item_bg);
		clrTxt = context.getResources().getColor(R.color.txt_status);
	}

	public GameDataListAdapter(Context context, String home, String away) {
		mInflater = LayoutInflater.from(context);
		bCBA = true;
		homeName = home;
		awayName = away;
		clrMain = context.getResources().getColor(R.color.dark_gray);
		clrSub = context.getResources().getColor(R.color.list_item_bg);
		clrTxt = context.getResources().getColor(R.color.txt_status);
	}

	public void setData(BoxScoreResp data) {
		setTitleMap(data.mMapGlossary, data.mMapPortrait);
		if (data.mListPlayers != null) {
			i_homeSize = data.i_homePlaySize;
			mListPLay = data.mListPlayers;
			mListPLayerNames = new LinkedList<String>();
			for (PlayerEntity entity : mListPLay)
				mListPLayerNames.add(entity.str_player_id);
			i_awaySize = mListPLay.size() - i_homeSize;
			paserTotal(data, false);
			// ����������
			str_home_fg = data.str_home_fg;
			str_home_tp = data.str_home_tp;
			str_home_ft = data.str_home_ft;
			// �Ͷ�������
			str_away_fg = data.str_away_fg;
			str_away_tp = data.str_away_tp;
			str_away_ft = data.str_away_ft;
			notifyDataSetChanged();
		}
	}

	public void paserTotal(BoxScoreResp data, boolean update) {

		if (mMapHomeTotal == null) {
			mMapHomeTotal = new LinkedHashMap<String, String>();
		}
		if (mMapAwayTotal == null) {
			mMapAwayTotal = new LinkedHashMap<String, String>();
		}
		if (data.homeTotals != null) {
			paserTotal(data.homeTotals, mMapHomeTotal, update);
		}
		if (data.awayTotals != null) {
			paserTotal(data.awayTotals, mMapAwayTotal, update);
		}
	}

	private void paserTotal(JSONObject json,
			LinkedHashMap<String, String> list, boolean update) {
		int size =0;
		if(bCBA )
	      size = mListKeys.size();
		else
	      size = mListPortraitKeys.size();
		String key = null;
		String value = null;
		for (int i = 0; i < size; i++) {
			if(bCBA)
				key = mListKeys.get(i);
			else
				key = mListPortraitKeys.get(i);
			value = json.optString(key, null);
			if (value != null)
				list.put(key, value);
		}
	}

	public LinkedList<String> getKeys() {
		return mListKeys;
	}

	public void updateData(BoxScoreResp data) {
		PlayerEntity oldPlayer;
		for (PlayerEntity newPlayer : data.mListPlayers) {
			int index = mListPLayerNames.indexOf(newPlayer.str_player_id);
			if (index > -1) {
				oldPlayer = mListPLay.get(index);
				Set<String> set = newPlayer.mapDatas.keySet();
				for (String key : set) {
					oldPlayer.mapDatas.put(key, newPlayer.mapDatas.get(key));
				}
			}

		}
		paserTotal(data, true);
		Set<String> set = null;

		// ����������\
		if (data.str_home_fg != null)
			str_home_fg = data.str_home_fg;
		if (data.str_home_tp != null)
			str_home_tp = data.str_home_tp;
		if (data.str_home_ft != null)
			str_home_ft = data.str_home_ft;
		// �Ͷ�������
		if (data.str_away_fg != null)
			str_away_fg = data.str_away_fg;
		if (data.str_away_tp != null)
			str_away_tp = data.str_away_tp;
		if (data.str_away_ft != null)
			str_away_ft = data.str_away_ft;
		notifyDataSetChanged();
	}

	/** Ϊ�˻�ȡ�ɷ��������ݹ����ı����ֶ� */
	private void setTitleMap(LinkedHashMap<String, String> m,
			LinkedHashMap<String, String> p) {
		if (m == null)
			return;
		Iterator<Entry<String, String>> lit = m.entrySet().iterator();
		mListKeys = new LinkedList<String>();
		mListTitles = new LinkedList<String>();

		while (lit.hasNext()) {
			Map.Entry<String, String> e = lit.next();
			// System.out.println("key="+e.getKey());
			mListKeys.add(e.getKey());
			mListTitles.add(e.getValue());
		}
		if (p != null) {
			mListPortraitKeys = new LinkedList<String>();
			mListPortraitTitles = new LinkedList<String>();

			lit = p.entrySet().iterator();
			while (lit.hasNext()) {
				Map.Entry<String, String> e = lit.next();
				// System.out.println("key="+e.getKey());
				mListPortraitKeys.add(e.getKey());
				mListPortraitTitles.add(e.getValue());
			}

			fgIndex = mListPortraitKeys.indexOf("fg");
			tpIndex = mListPortraitKeys.indexOf("tp");
			ftIndex = mListPortraitKeys.indexOf("ft");
		}
		if(bCBA || mListPortraitTitles==null)
			i_titleSize = mListTitles.size();
		else
			i_titleSize = mListPortraitTitles.size();
	}

	public void updatemBoxscoreDatas(BoxscoreDatas boxscoreData) {
		boxscoreData.mListPLay = mListPLay;
		boxscoreData.mListPLayerNames = mListPLayerNames;
		boxscoreData.mListKeys = mListKeys;
		boxscoreData.mTitles = mListTitles;
		boxscoreData.i_homeSize = i_homeSize;

		boxscoreData.mMapHomeTotal = mMapHomeTotal;

		boxscoreData.mMapAwayTotal = mMapAwayTotal;
		// ����������
		boxscoreData.str_home_fg = str_home_fg;
		boxscoreData.str_home_tp = str_home_tp;
		boxscoreData.str_home_ft = str_home_ft;
		// �Ͷ�������
		boxscoreData.str_away_fg = str_away_fg;
		boxscoreData.str_away_tp = str_away_tp;
		boxscoreData.str_away_ft = str_away_ft;
	}

	class Holder {
		// View viewHeader;
		// Header header;

		TextView txtPlayerName;
		TextView[] datas;

	}

	class Header {
		TextView txtName;
		TextView[] txtTitles;
		View line_team;
	}

	@Override
	public PlayerEntity getItem(int section, int position) {

		if (mListPLay == null)
			return null;
		return mListPLay.get(section * i_homeSize + position);
	}

	@Override
	public long getItemId(int section, int position) {

		return 0;
	}

	@Override
	public int getSectionCount() {

		return 2;
	}

	@Override
	public int getCountForSection(int section) {
		if (section == 0)
			return i_homeSize + 1;
		else
			return i_awaySize + 1;

	}

	@Override
	public View getItemView(int section, int position, View convertView,
			ViewGroup parent) {
		int staticIndex = section == 1 ? mListPLay.size() - i_homeSize
				: i_homeSize;

		Holder holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_data_child, null);
			holder = new Holder();
			holder.txtPlayerName = (TextView) convertView
					.findViewById(R.id.txt_play_name);
			holder.datas = new TextView[4];
			holder.datas[0] = (TextView) convertView
					.findViewById(R.id.txt_data1);
			holder.datas[1] = (TextView) convertView
					.findViewById(R.id.txt_data2);
			holder.datas[2] = (TextView) convertView
					.findViewById(R.id.txt_data3);
			holder.datas[3] = (TextView) convertView
					.findViewById(R.id.txt_data4);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		if (position > 4 && position < staticIndex) {
			convertView.setBackgroundColor(clrSub);
			holder.txtPlayerName.setTextColor(clrTxt);
		} else {
			convertView.setBackgroundColor(clrMain);
			holder.txtPlayerName.setTextColor(Color.WHITE);
		}
		if (position < staticIndex) {
			PlayerEntity entity = getItem(section, position);
			holder.txtPlayerName.setText(entity.str_name);
			// for (int i = 0; i < 4; i++) {
			// if (i < i_titleSize)
			// holder.datas[i].setText(entity.mapDatas
			// .get(mListPortraitKeys.get(i)));
			// else
			// holder.datas[i].setText("");
			// }

			int index = 0;
			for (int i = i_page << 2; index < 4; i++) {
				if (i < i_titleSize) {
					if (bCBA)
						holder.datas[index].setText(entity.mapDatas
								.get(mListKeys.get(i)));
					else
						holder.datas[index].setText(entity.mapDatas
								.get(mListPortraitKeys.get(i)));
				}

				else
					holder.datas[index].setText("");
				index++;
			}

		} else if (position == staticIndex) {
			// ͳ��
			holder.txtPlayerName.setText("�ܼ�");
			// for (int i = 0; i < holder.datas.length; i++) {
			// if (section == 1)
			// holder.datas[i].setText(mMapAwayTotal.get(mListPortraitKeys
			// .get(i)));
			// else
			// holder.datas[i].setText(mMapHomeTotal.get(mListPortraitKeys
			// .get(i)));
			// }
			int index = 0;
			for (int i = i_page << 2; index < 4; i++) {
				if (i < i_titleSize) {
					if (section == 1) {
						if (bCBA)
							holder.datas[index].setText(mMapAwayTotal
									.get(mListKeys.get(i)));
						else
							holder.datas[index].setText(mMapAwayTotal
									.get(mListPortraitKeys.get(i)));
					} else {
						if (bCBA)
							holder.datas[index].setText(mMapHomeTotal
									.get(mListKeys.get(i)));
						else
							holder.datas[index].setText(mMapHomeTotal
									.get(mListPortraitKeys.get(i)));
					}
				} else
					holder.datas[index].setText("");
				index++;
			}

		} else {
			// holder.txtPlayerName.setText("������");
			// for (int i = 0; i < holder.datas.length; i++) {
			// holder.datas[i].setText("");
			// }
			// if( section == 1)
			// {
			// holder.datas[fgIndex].setText(str_away_fg);
			// holder.datas[tpIndex].setText(str_away_tp);
			// holder.datas[ftIndex].setText(str_away_ft);
			// }
			// else
			// {
			// holder.datas[fgIndex].setText(str_home_fg);
			// holder.datas[tpIndex].setText(str_home_tp);
			// holder.datas[ftIndex].setText(str_home_ft);
			// }
		}
		return convertView;
	}

	@Override
	public View getSectionHeaderView(int section, View convertView,
			ViewGroup parent) {
		Header holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_data_header, null);
			holder = new Header();
			holder.txtTitles = new TextView[4];
			holder.txtName = (TextView) convertView.findViewById(R.id.txt_name);
			holder.txtTitles[0] = (TextView) convertView
					.findViewById(R.id.txt_title1);
			holder.txtTitles[1] = (TextView) convertView
					.findViewById(R.id.txt_title2);
			holder.txtTitles[2] = (TextView) convertView
					.findViewById(R.id.txt_title3);
			holder.txtTitles[3] = (TextView) convertView
					.findViewById(R.id.txt_title4);
			// holder.line_team = convertView.findViewById(R.id.line_team);
			convertView.setTag(holder);
		} else {
			holder = (Header) convertView.getTag();
		}

		if (section == 0) {
			if (bCBA)
				holder.txtName.setText(homeName + "��Ա");
			else
				holder.txtName.setText(HuPuApp.getTeamData(i_homeId).str_name
						+ "��Ա");
			// holder.line_team
			// .setBackgroundColor(HuPuApp.getTeamData(i_homeId).i_color);
		} else {
			if (bCBA)
				holder.txtName.setText(awayName + "��Ա");
			else
				holder.txtName.setText(HuPuApp.getTeamData(i_awayId).str_name
						+ "��Ա");
			// holder.line_team
			// .setBackgroundColor(HuPuApp.getTeamData(i_awayId).i_color);
		}

		// for (int i = 0; i < 4; i++) {
		// if (i < i_titleSize)
		// holder.txtTitles[i].setText(mListPortraitTitles.get(i));
		// else
		// holder.txtTitles[i].setText("");
		// }
		int index = 0;
		for (int i = i_page * 4; index < 4; i++) {

			if (i < i_titleSize)
			{
				if(bCBA)
					holder.txtTitles[index].setText(mListTitles.get(i));
				else
					holder.txtTitles[index].setText(mListPortraitTitles.get(i));
			}
			else
				holder.txtTitles[index].setText("");
			index++;
		}
		return convertView;
	}

	private int i_page;

	public void prePage() {

		if (i_page > 0) {
			i_page--;
			notifyDataSetChanged();
		}
		// System.out.println("prePage="+i_page);
	}

	public void nextPage() {
		if (i_page * 4 + 4 < i_titleSize) {
			i_page++;
			notifyDataSetChanged();
		}
		// System.out.println("nextPage="+i_page);
	}
}
