package com.hupu.games.adapter;

import java.util.ArrayList;
import java.util.LinkedList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.hupu.games.R;
import com.hupu.games.HuPuApp;
import com.hupu.games.data.GameEntity;
import com.pyj.common.MyUtility;

public class GamesListAdapter extends BaseAdapter {

	private LinkedList<GameEntity> mListGames;

	private LayoutInflater mInflater;
	private OnClickListener mClick;

	public GamesListAdapter(Context context, OnClickListener c) {
		mInflater = LayoutInflater.from(context);
		mClick = c;
	}

	@Override
	public int getCount() {
		if (mListGames == null)
			return 0;
		return mListGames.size();
	}

	@Override
	public GameEntity getItem(int arg0) {
		if (mListGames == null)
			return null;
		return mListGames.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	public void setData(LinkedList<GameEntity> gameList) {
		mListGames = gameList;
		notifyDataSetChanged();
	}

	public void setFollow(int pos, int follow) {
		if (mListGames.get(pos).i_isFollow != follow) {
			mListGames.get(pos).i_isFollow = follow;
		
		}
		notifyDataSetChanged();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// System.out.print("GamesListAdapter getView pos =" + position);
		GameEntity entity = mListGames.get(position);
		Holder holder = null;
		if (convertView == null) {
			//
			convertView = mInflater.inflate(R.layout.item_team, null);
			holder = new Holder();
			holder.txtHomeName = (TextView) convertView
					.findViewById(R.id.txt_home_name);
			holder.txtAwayName = (TextView) convertView
					.findViewById(R.id.txt_away_name);
			holder.txtStatus = (TextView) convertView
					.findViewById(R.id.txt_status);
			holder.txtHomeScore1 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore1);
			holder.txtHomeScore2 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore2);
			holder.txtHomeScore3 = (TextView) convertView
					.findViewById(R.id.txt_home_scrore3);

			holder.txtAwayScore1 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore1);
			holder.txtAwayScore2 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore2);
			holder.txtAwayScore3 = (TextView) convertView
					.findViewById(R.id.txt_away_scrore3);

			holder.layoutScore = convertView.findViewById(R.id.layout_sore);
			holder.btnFollow = (ImageView) convertView
					.findViewById(R.id.btn_follow);
			holder.txtInfo = (TextView) convertView.findViewById(R.id.txt_info);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		holder.txtHomeName.setText(entity.str_home_name);
		setIcon(holder.txtHomeName, entity.i_home_tid);
		holder.txtAwayName.setText(entity.str_away_name);
		setIcon(holder.txtAwayName, entity.i_away_tid);
		if (entity.byt_status == GameEntity.STATUS_WAITING) {
			// �ȴ���ʼ
			holder.layoutScore.setVisibility(View.GONE);
			holder.txtStatus.setVisibility(View.VISIBLE);
			holder.txtStatus.setText(MyUtility
					.getStartTime(entity.l_begin_time * 1000));
			if(entity.i_live>0)
				holder.txtStatus.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.live_2);
			else
				holder.txtStatus.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0,0);
			// holder.btnFollow .setBackgroundResource(resid);
			holder.btnFollow.setVisibility(View.VISIBLE);
			holder.btnFollow.setTag(position);
			holder.btnFollow.setOnClickListener(mClick);
			if (entity.i_isFollow == 1) {
//				holder.btnFollow.setBackgroundResource(R.drawable.btn_bg_black);
//				holder.btnFollow.setImageResource(R.drawable.btn_txt_followed);
				holder.btnFollow.setImageResource(R.drawable.btn_dated);
			} else {
//				holder.btnFollow.setBackgroundResource(R.drawable.btn_bg_red);
//				holder.btnFollow.setImageResource(R.drawable.btn_txt_follow);
				holder.btnFollow.setImageResource(R.drawable.btn_date);
			}
			holder.txtInfo.setVisibility(View.GONE);
		} else if (entity.byt_status == GameEntity.STATUS_START) {
			// �Ѿ���ʼ
			holder.layoutScore.setVisibility(View.VISIBLE);
			holder.txtStatus.setVisibility(View.GONE);
			holder.btnFollow.setVisibility(View.GONE);
			setSore(holder, entity.i_home_score, entity.i_away_score);
			holder.txtInfo.setVisibility(View.VISIBLE);
			if (entity.str_process != null)
				holder.txtInfo.setText(entity.str_process);
			if(entity.i_live>0)
				holder.txtInfo.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.live);
			else
				holder.txtInfo.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
		} else {
			// ����
			holder.layoutScore.setVisibility(View.VISIBLE);
			holder.txtStatus.setVisibility(View.GONE);
			holder.btnFollow.setVisibility(View.GONE);
			holder.txtInfo.setVisibility(View.VISIBLE);
			holder.txtInfo.setText(R.string.finished);
			holder.txtInfo.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
			setSore(holder, entity.i_home_score, entity.i_away_score);
		}

		return convertView;
	}

	private void setIcon(TextView tv, int res) {
		tv.setCompoundDrawablesWithIntrinsicBounds(
				HuPuApp.getTeamData(res).i_logo_small, 0, 0, 0);
	}

	private static final int num_res[] = { R.drawable.num0, R.drawable.num1,
			R.drawable.num2, R.drawable.num3, R.drawable.num4, R.drawable.num5,
			R.drawable.num6, R.drawable.num7, R.drawable.num8, R.drawable.num9, };

	private void setSore(Holder holder, int homeScore, int awayScore) {
		int hundred = homeScore / 100;
		int tens = (homeScore % 100) / 10;
		int single = homeScore % 10;

		if (hundred > 0 &&  hundred<10) {
			holder.txtHomeScore1.setVisibility(View.VISIBLE);
			holder.txtHomeScore1.setBackgroundResource(num_res[hundred]);
		} else
			holder.txtHomeScore1.setVisibility(View.GONE);
		if (homeScore >= 10) {
			holder.txtHomeScore2.setVisibility(View.VISIBLE);
			holder.txtHomeScore2.setBackgroundResource(num_res[tens]);
		} else
			holder.txtHomeScore2.setVisibility(View.GONE);
		holder.txtHomeScore3.setBackgroundResource(num_res[single]);

		hundred = awayScore / 100;
		tens = (awayScore % 100) / 10;
		single = awayScore % 10;
		if (hundred > 0) {
			holder.txtAwayScore1.setVisibility(View.VISIBLE);
			holder.txtAwayScore1.setBackgroundResource(num_res[hundred]);
		} else
			holder.txtAwayScore1.setVisibility(View.GONE);
		if (awayScore >= 10) {
			holder.txtAwayScore2.setVisibility(View.VISIBLE);
			holder.txtAwayScore2.setBackgroundResource(num_res[tens]);
		} else
			holder.txtAwayScore2.setVisibility(View.GONE);
		holder.txtAwayScore3.setBackgroundResource(num_res[single]);

	}

	static class Holder {
		// ��һ��
		TextView txtHomeName;
		TextView txtAwayName;

		// �ڶ���
		View layoutScore;
		TextView txtStatus;
		TextView txtHomeScore1;
		TextView txtHomeScore2;
		TextView txtHomeScore3;

		TextView txtAwayScore1;
		TextView txtAwayScore2;
		TextView txtAwayScore3;

		// ������
		ImageView btnFollow;
		TextView txtInfo;

	}
}
