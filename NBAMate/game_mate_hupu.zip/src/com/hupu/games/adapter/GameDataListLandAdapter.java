package com.hupu.games.adapter;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hupu.games.R;
import com.hupu.games.HuPuApp;
import com.hupu.games.activity.HupuDataActivity.BoxscoreDatas;
import com.hupu.games.data.PlayerEntity;

/**
 * ����ͳ������
 * */
public class GameDataListLandAdapter extends BaseAdapter {

	private LinkedList<PlayerEntity> mListPLay;

	private LayoutInflater mInflater;

	/** ������Ա���� */
	private int i_homeSize;

	BoxscoreDatas mData;
	
	int fgIndex=-1;
	int tpIndex=-1;
	int ftIndex=-1;
	int clrMain;
	int clrSub;
	int clrTxt;
	public GameDataListLandAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
		clrMain = context.getResources().getColor(R.color.dark_gray);
		clrSub = context.getResources().getColor(R.color.list_item_bg);
		clrTxt= context.getResources().getColor(R.color.txt_status);
	}

	public void setData(BoxscoreDatas boxscoreData) {
		if(i_homeSize ==0)
		{
			i_homeSize = boxscoreData.i_homeSize;
			fgIndex =boxscoreData.mListKeys.indexOf("fg");
			tpIndex=boxscoreData.mListKeys.indexOf("tp");
			ftIndex=boxscoreData.mListKeys.indexOf("ft");
		}
			mListPLay = boxscoreData.mListPLay;
			mData =boxscoreData;
			notifyDataSetChanged();
	}



	class Holder {
		TextView txtPlayerName;
		TextView[] datas;
	}

	private int mMode;
	private static int AWAY_MODE = 1;

	public void changeMode(int mode) {
		if (mode != mMode) {
			mMode = mode;
			notifyDataSetChanged();
		}
	}

	@Override
	public int getCount() {
		if (mListPLay != null) {
			if (mMode == AWAY_MODE)		
				return mListPLay.size() - i_homeSize+2;
			return i_homeSize +2;
		}
		return 0;
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PlayerEntity getItem(int position) {

		if (mListPLay == null)
			return null;
		return mListPLay.get(position);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		int index = mMode == AWAY_MODE ? i_homeSize : 0;
		int staticIndex = mMode == AWAY_MODE ? mListPLay.size()- i_homeSize : i_homeSize;
	

		Holder holder = null;
		if (convertView == null) {
			//
			LinearLayout v = (LinearLayout) mInflater.inflate(
					R.layout.item_data_child_land, null);
			convertView = v;
			holder = new Holder();
			holder.txtPlayerName = (TextView) convertView
					.findViewById(R.id.txt_play_name);
			holder.datas = new TextView[mData.mListKeys.size()];
			LinearLayout.LayoutParams llp = null;
			String key =null;
			for (int i = 0; i < holder.datas.length; i++) {
				View child = mInflater
						.inflate(R.layout.static_child_land, null);
				holder.datas[i] = (TextView) child.findViewById(R.id.txt_child);
				key =mData.mListKeys.get(i);
				if(key.equals("fg") || key.equals("ft")||key.equals("tp") )
					llp = new LinearLayout.LayoutParams(0,
							-2, 10);
				else if (key.equals("mins") ||key.equals("pts") )
					llp = new LinearLayout.LayoutParams(0,
							-2, 7);
				else
					llp = new LinearLayout.LayoutParams(0,
							-2, 5);
			
				v.addView(child, llp);
			}
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		PlayerEntity entity =null;
		if(position>4 && position<staticIndex)
		{
			convertView.setBackgroundColor(clrSub);
			holder.txtPlayerName .setTextColor(clrTxt);
		}
		else
		{
			convertView.setBackgroundColor(clrMain);
			holder.txtPlayerName .setTextColor(Color.WHITE);
		}
		if(position<staticIndex)
		{
			entity = getItem(index + position);
			holder.txtPlayerName.setText(entity.str_name);
			for (int i = 0; i < holder.datas.length; i++) {
				holder.datas[i].setText(entity.mapDatas.get(mData.mListKeys.get(i)));
			}
		}
		else if(position==staticIndex)
		{
			//ͳ��
			holder.txtPlayerName.setText("�ܼ�");
			for (int i = 0; i < holder.datas.length; i++) {
				if(mMode == AWAY_MODE)
					holder.datas[i].setText(mData.mMapAwayTotal.get( mData.mListKeys.get(i) ));
				else
					holder.datas[i].setText(mData.mMapHomeTotal.get( mData.mListKeys.get(i) ));
			}
		}
		else
		{
			holder.txtPlayerName.setText("������");
			for (int i = 0; i < holder.datas.length; i++) {
				holder.datas[i].setText("");
			}
			//������
			if(mMode == AWAY_MODE)
			{
				holder.datas[fgIndex].setText(mData.str_away_fg);
				holder.datas[tpIndex].setText(mData.str_away_tp);
				holder.datas[ftIndex].setText(mData.str_away_ft);
			}
			else
			{
				holder.datas[fgIndex].setText(mData.str_home_fg);
				holder.datas[tpIndex].setText(mData.str_home_tp);
				holder.datas[ftIndex].setText(mData.str_home_ft);
			}
		}

			
		
		return convertView;
	}

}
