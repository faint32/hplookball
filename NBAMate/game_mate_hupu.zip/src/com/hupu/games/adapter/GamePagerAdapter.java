package com.hupu.games.adapter;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.fragment.GameFragment;
import com.pyj.common.MyUtility;
import com.umeng.common.Log;

/**
 * 
 * */
public class GamePagerAdapter extends FragmentStatePagerAdapter {

	HashMap<Long, GamesResp> mapEntity;
	LinkedHashMap<Long, GameFragment> mFragmentList;
	// LinkedHashMap<Integer, GameFragment> mFragmentList1;
	/** ʱ���б� */
	LinkedList<Long> dateList;
	FragmentActivity act;

	public final static int INITSIZE = 250;

	public GamePagerAdapter(FragmentActivity fa) {
		super(fa.getSupportFragmentManager());
		act = fa;
		mapEntity = new HashMap<Long, GamesResp>();
		mFragmentList = new LinkedHashMap<Long, GameFragment>();
		dateList = new LinkedList<Long>();
	}

	private int offset;

	@Override
	public GameFragment getItem(int pos) {
//		Log.d(" GameFragment"," getItem pos=" + pos + "offset=" + offset);
//		 System.out.println(" Fragment getItem index=" + (pos-INITSIZE+offset));
		if (pos - INITSIZE + offset < 0
				|| pos - INITSIZE + offset >= dateList.size())
			return GameFragment.newInstance(0, this);
		long date = dateList.get(pos - INITSIZE + offset);
		// System.out.println(" Fragment getItem pos=" + pos + "date="
		// + MyUtility.getFormateDate(date * 1000));
		GameFragment tmp = GameFragment.newInstance(date, this);
		GamesResp entity = mapEntity.get(date);
		if (entity != null)
			tmp.setData(entity);
		mFragmentList.put(date, tmp);
		return tmp;
	}

	public long getDate(int pos) {
		if (dateList.size() == 0)
			return 0;
		if (pos - INITSIZE + offset < 0
				|| pos - INITSIZE + offset >= dateList.size())
			return -1;
		return dateList.get(pos - INITSIZE + offset);
	}

	@Override
	public int getCount() {
		// System.out.println(" getCount="+dateList.size());
		// return dateList.size();
		return INITSIZE << 1;
	}


	public int getRealCount() {
		if(dateList !=null)
			return dateList.size() ;
		return 0;
	}
	public int getHeadNum(int cur) {
		// System.out.println("headNum="+(dateList.size()-cur-INITSIZE+offset));
		return dateList.size() - (cur - INITSIZE + offset);
	}

	public int getTailNum(int cur) {
		return cur - INITSIZE + offset;
	}

	public GamesResp getData(long date) {
		// System.out.println("GamesResp getData ="+date
		// +" ;;;;mapEntity size ="+mapEntity.size());
		return mapEntity.get(date);
	}

	public void setFragmentData(long date, GamesResp entity, boolean keep) {
//		 System.out.println("setFragment date="
//		 + MyUtility.getFormateDate(date * 1000));
		if (keep) {
			GamesResp temp = mapEntity.get(date);
			if (temp != null) {
				int size = temp.mGameList.size();
				int oldIndex = 0;
				for (int i = 0; i < size; i++) {
					// ʵʱ�������ݻ��������������˳��仯��������Ҫ��λ�ϴα���ı�����λ�ã�
					oldIndex = temp.mGameIdList
							.indexOf(entity.mGameList.get(i).i_gId);
					// System.out.println("old index="+oldIndex);
					// ʵʱ�������ݻ���������Ĳ�������ע��Ϣ��������Ҫ���ϴα���ı��������ݸ��ƹ�ȥ��
					entity.mGameList.get(i).i_isFollow = temp.mGameList
							.get(oldIndex).i_isFollow;
				}
			}
		}

		mapEntity.put(date, entity);
		// int index = dateList.indexOf(date);
		// System.out.println("date index=" + index);
		GameFragment tmp = mFragmentList.get(date);
		if (tmp != null) {
			
			if (tmp.isDetached() || tmp.isRemoving())
				mFragmentList.remove(date);
			else
			{
				if(tmp.bBlank)
					tmp.initLater(date, this);
				tmp.setData(entity);
			}
		}

	}

	/** ���±�����ע��״̬ */
	public void updateFollow(long date, int gId, int follow) {
		GameFragment tmp = mFragmentList.get(date);
		GamesResp temp = mapEntity.get(date);
		int pos = temp.mGameIdList.indexOf(gId);
		if (pos > -1) {
			temp.mGameList.get(pos).i_isFollow = follow;
			if (tmp != null) {
				if (tmp.isDetached() || tmp.isRemoving())
					mFragmentList.remove(date);
				else
					tmp.setFollowInfo(pos, follow);
			}
		}
	}

	// public void setToHead(GameFragment gf)
	// {
	// list.add(0, gf);
	// notifyDataSetChanged();
	// }
	//
	// public void setToTail(GameFragment gf)
	// {
	// list.add(gf);
	// notifyDataSetChanged();
	// }
	private long mToday;

	public void setToday(long today) {
		mToday = today;
	}

	public void setDay(long today) {
		dateList.add(today);
	}

	public void setPreDate(List<Long> l) {
		if (l != null) {
			if(!dateList.contains(l.get(0)))
			{
				dateList.addAll(0, l);
				offset += l.size();
			}			
		}
		// this.notifyDataSetChanged();
	}

	public void setNextDate(List<Long> l) {
		if (l != null) {
			if(!dateList.contains(l.get(0)))
				dateList.addAll(dateList.size(), l);
		}
	}

	public boolean hasData(int pos) {
		if (pos - INITSIZE + offset < 0
				|| pos - INITSIZE + offset >= dateList.size()) {
			long date = dateList.get(pos - INITSIZE + offset);
			return mapEntity.get(date) != null;
		}
		return false;
	}

	public void update(int pos) {

	}

	@Override
	public CharSequence getPageTitle(int position) {
		if (position - INITSIZE + offset < 0
				|| position - INITSIZE + offset >= dateList.size())
			return null;
		long date = dateList.get(position - INITSIZE + offset);
		if (date == mToday)
			return "����";
		return MyUtility.getFormateDate(date * 1000);
	}

	@Override
	public int getItemPosition(Object object) {
		GameFragment temp = (GameFragment) object;
		int index = dateList.indexOf(temp.l_date);
		// System.out.println("getItemPosition index=" + index);
		if (index > -1)
			return index;

		return FragmentStatePagerAdapter.POSITION_NONE;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		// System.out.println("1111remove item index =" + position);
		if (position >= container.getChildCount())
			return;
		// ((ViewPager) container).removeView(((GameFragment)
		// object).getView());
		// System.out.println("222remove item index =" + position);
		super.destroyItem(container, position, object);
	}

}
