package com.hupu.games.adapter;

import java.util.LinkedList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.common.FinalBitmap;
import com.hupu.games.data.NewsEntity;
import com.hupu.games.data.VideoEntity;

/**
 * ����ͳ������
 * */
public class NewsListAdapter extends BaseAdapter {

	private LinkedList<NewsEntity> mListData;

	private LayoutInflater mInflater;

	public NewsListAdapter(Context context) {
		mInflater = LayoutInflater.from(context);

	}

	public void setData(LinkedList<NewsEntity> data) {
		mListData = data;
		notifyDataSetChanged();
	}

	class Holder {
		TextView txtContent;
		TextView txtTitle;
		TextView txtNum;

	}

	@Override
	public NewsEntity getItem(int position) {

		if (mListData == null)
			return null;
		return mListData.get(position);
	}

	@Override
	public long getItemId(int position) {

		return 0;
	}

	@Override
	public int getCount() {

		if (mListData == null)
			return 0;
		return mListData.size();
	}

	@Override
	public View getView(int pos, View contentView, ViewGroup arg2) {
		Holder item = null;
		NewsEntity entity = mListData.get(pos);
		if (contentView == null) {
			contentView = mInflater.inflate(R.layout.item_news, null);
			item = new Holder();
			item.txtContent = (TextView) contentView
					.findViewById(R.id.txt_content);
			item.txtTitle = (TextView) contentView.findViewById(R.id.txt_title);
			item.txtNum = (TextView) contentView.findViewById(R.id.txt_nums);
			contentView.setTag(item);
		} else {
			item = (Holder) contentView.getTag();
		}
		item.txtTitle.setText(entity.title);
		item.txtContent.setText(entity.summary);

		item.txtNum.setText("" + entity.replies);

		return contentView;
	}

}
