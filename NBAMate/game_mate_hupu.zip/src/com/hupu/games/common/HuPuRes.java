package com.hupu.games.common;

import java.io.File;
import java.util.Calendar;

import android.content.Context;
import android.os.Environment;



public class HuPuRes {

	
	
	private static String cache_path;
	public static final String getCahePath(Context ctx)
	{
		if(cache_path==null)
		{
			cache_path = Environment.MEDIA_MOUNTED.equals(Environment
					.getExternalStorageState()) ? getExternalCacheDir(ctx)
					.getPath() : ctx.getCacheDir().getPath();
		}	
		return cache_path;
	}
	/**
	 * ��ȡ�����ⲿ�Ļ���Ŀ¼
	 * 
	 * @param context
	 * @return
	 */
	public static File getExternalCacheDir(Context context) {
		final String cacheDir = "/hupu/games/cache/";
		return new File(Environment.getExternalStorageDirectory().getPath()
				+ cacheDir);
	}
	

	public final static String BASE_URL = "http://games.mobileapi.hupu.com/1/2.0.0/";

	public final static String REQ_URL_REDIRECTOR = "http://games.mobileapi.hupu.com/redirector/";
	
//	 public final static String BASE_URL =
//	 "http://games-test.mobileapi.hupu.com/1/2.0.0/";
//	public final static String REQ_URL_REDIRECTOR="http://games-test.mobileapi.hupu.com/redirector/";
	
	//��̩
//	public final static String BASE_URL =
//			 "http://btdata.mobileapi.hupu.com/1/2.0.0/";
//	public final static String REQ_URL_REDIRECTOR="http://btdata.mobileapi.hupu.com/redirector/";
//
	public final static int REQ_METHOD_GET_TEAMS = 1;
	public final static String REQ_URL_GET_TEAMS = BASE_URL + "nba/getTeam";
	
	public final static int REQ_METHOD_REDIRECTOR = 51;
	public final static int REQ_METHOD_FOLLOW_TEAM = 52;
	public final static int REQ_METHOD_FOLLOW_TEAM_CANCEL = 53;
	public final static String REQ_URL_FOLLOW_TEAM = BASE_URL + "nba/followTeam";

	public final static int REQ_METHOD_BOX_SCORE = 4;
	public final static String REQ_URL_BOX_SCORE = BASE_URL + "nba/getBoxscore";

	public final static int REQ_METHOD_GAMES_BY_GID = 5;
	/** �ɷ��������������һ��ı�������,������ǰ����������� */
	public final static int REQ_METHOD_NBA_GAMES_BY_SERVER = 6;
	/** ָ���������ڵı�������,������ǰ��������� */
	public final static int REQ_METHOD_NBA_GAMES_BY_PRE = 7;
	/** ָ���������ڵı�������,�����غ���������� */
	public final static int REQ_METHOD_NBA_GAMES_BY_NEXT = 8;
	/** ָ���������ڵı�������,������ǰ����������� */
	public final static int REQ_METHOD_GAMES_BY_DATE = 9;
	public final static int REQ_METHOD_GAMES_REAL_TIME = 10;
	public final static String REQ_URL_GAMES = BASE_URL + "nba/getGames";

	public final static int REQ_METHOD_GET_PLAY_LIVE_ASC = 11;
	public final static int REQ_METHOD_GET_PLAY_LIVE_DESC = 12;
	public final static String REQ_URL_GET_PLAY_LIVE = BASE_URL
			+ "nba/getPlaybyplay";

	public final static int REQ_METHOD_GET_RECAP = 21;
	public final static String REQ_URL_GET_RECAP = BASE_URL + "nba/getRecap";

	public final static int REQ_METHOD_FOLLOW_GAME = 31;
	public final static int REQ_METHOD_FOLLOW_GAME_CANCEL = 32;
	public final static String REQ_URL_FOLLOW_GAME = BASE_URL + "nba/followGame";

	public final static int REQ_METHOD_GET_FOLLOW_TEAMS = 41;
	public final static String REQ_URL_GET_FOLLOW_TEAMS = BASE_URL
			+ "nba/getUserFollowTeams";

	public final static int REQ_METHOD_SET_FOLLOW_TEAMS = 3;
	public final static String REQ_URL_SET_FOLLOW_TEAMS = BASE_URL
			+ "nba/followBatchTeam";

	public final static int REQ_METHOD_GET_STANDINGS= 61;
	public final static String REQ_URL_GET_STANDINGS = BASE_URL
			+ "nba/getStandings";
	
	
	public final static int REQ_METHOD_GET_NBA_VIDEO_GAME= 71;
//	public final static int REQ_METHOD_GET_NBA_VIDEO_GAME_PRE= 72;
	public final static int REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT= 73;
	public final static int REQ_METHOD_GET_NBA_VIDEO_HOT= 74;
	public final static int REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT= 75;
//	public final static int REQ_METHOD_GET_VIDEO_HOT_PRE= 76;
	public final static String REQ_URL_GET_NBA_VIDEO = BASE_URL
			+ "nba/getVideo";
	
	public final static int REQ_METHOD_GET_CBA_VIDEO_GAME= 76;
	public final static int REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT= 77;
	public final static int REQ_METHOD_GET_CBA_VIDEO_HOT= 78;
	public final static int REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT= 79;
	public final static String REQ_URL_GET_CBA_VIDEO = BASE_URL
			+ "cba/getVideo";
	
	public final static int REQ_METHOD_GET_NBA_NEWS= 81;
	public final static int REQ_METHOD_GET_NBA_NEWS_NEXT= 82;
	public final static int REQ_METHOD_GET_NBA_NEWS_PRE= 83;	
	public final static String REQ_URL_GET_NBA_NEWS = BASE_URL
			+ "nba/getNews";

	
	public final static int REQ_METHOD_GET_NBA_DETAIL= 84;
	public final static String REQ_URL_GET_NBA_NEWS_DETAIL = BASE_URL
			+ "nba/getNewsDetail";
	
	public final static int REQ_METHOD_GET_CBA_NEWS= 85;
	public final static int REQ_METHOD_GET_CBA_NEWS_NEXT= 86;
	public final static int REQ_METHOD_GET_CBA_NEWS_PRE= 87;	
	public final static String REQ_URL_GET_CBA_NEWS = BASE_URL
			+ "cba/getNews";
	
	public final static int REQ_METHOD_GET_CBA_DETAIL= 88;
	public final static String REQ_URL_GET_CBA_NEWS_DETAIL = BASE_URL
			+ "cba/getNewsDetail";
	
	public final static int REQ_METHOD_CBA_NEXT= 90;
	public final static int REQ_METHOD_CBA_PREV= 91;
	public final static int REQ_METHOD_CBA_BY_ID= 92;
	public final static String REQ_URL_GET_CBA = BASE_URL
			+ "cba/getGames";
	
	public final static int REQ_METHOD_CBA_BOX_SCORE = 93;
	public final static String REQ_URL_CBA_BOX_SCORE = BASE_URL + "cba/getBoxscore";
	

	public final static int REQ_METHOD_NBA_CHAT = 100;
	public final static int REQ_METHOD_NBA_CHAT_MORE = 101;
	public final static int REQ_METHOD_NBA_CHAT_NEW = 102;
	public final static String REQ_URL_NBA_CHAT = BASE_URL + "nba/getChat";
	
	public final static int REQ_METHOD_SENT_CHAT = 103;
	public final static String REQ_URL_SENT_CHAT = BASE_URL + "chat/sendChat";

	
	public static String getUrl(int mId) {
		switch (mId) {
		case REQ_METHOD_GET_TEAMS:
			return REQ_URL_GET_TEAMS;

		case REQ_METHOD_FOLLOW_TEAM:
		case REQ_METHOD_FOLLOW_TEAM_CANCEL:
			return REQ_URL_FOLLOW_TEAM;

		case REQ_METHOD_SET_FOLLOW_TEAMS:
			return REQ_URL_SET_FOLLOW_TEAMS;

		case REQ_METHOD_BOX_SCORE:
			return REQ_URL_BOX_SCORE;

		case REQ_METHOD_GAMES_BY_GID:
		case REQ_METHOD_NBA_GAMES_BY_SERVER:
		case REQ_METHOD_NBA_GAMES_BY_PRE:
		case REQ_METHOD_NBA_GAMES_BY_NEXT:
		case REQ_METHOD_GAMES_BY_DATE:
			return REQ_URL_GAMES;
		default:
			return null;

		case REQ_METHOD_GET_STANDINGS:
			return REQ_URL_GET_STANDINGS;
			
		case REQ_METHOD_GET_PLAY_LIVE_ASC:
		case REQ_METHOD_GET_PLAY_LIVE_DESC:
			return REQ_URL_GET_PLAY_LIVE;

		case REQ_METHOD_GET_RECAP:
			return REQ_URL_GET_RECAP;

		case REQ_METHOD_FOLLOW_GAME:
		case REQ_METHOD_FOLLOW_GAME_CANCEL:
			return REQ_URL_FOLLOW_GAME;

		case REQ_METHOD_GET_FOLLOW_TEAMS:
			return REQ_URL_GET_FOLLOW_TEAMS;
		case REQ_METHOD_REDIRECTOR:
			return REQ_URL_REDIRECTOR;
			
		case REQ_METHOD_GET_NBA_VIDEO_GAME:		
		case REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case REQ_METHOD_GET_NBA_VIDEO_HOT:
		case REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
			return REQ_URL_GET_NBA_VIDEO;
		
		case REQ_METHOD_GET_CBA_VIDEO_GAME:
		case REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT:
		case REQ_METHOD_GET_CBA_VIDEO_HOT:;
		case REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT:
			return REQ_URL_GET_CBA_VIDEO ;
					
		case REQ_METHOD_GET_NBA_NEWS:
		case REQ_METHOD_GET_NBA_NEWS_NEXT:
		case REQ_METHOD_GET_NBA_NEWS_PRE:
			return REQ_URL_GET_NBA_NEWS;
		case REQ_METHOD_GET_NBA_DETAIL:
			return REQ_URL_GET_NBA_NEWS_DETAIL;
		
		case REQ_METHOD_GET_CBA_NEWS:
		case REQ_METHOD_GET_CBA_NEWS_NEXT:
		case REQ_METHOD_GET_CBA_NEWS_PRE:
			return REQ_URL_GET_CBA_NEWS;
		case REQ_METHOD_GET_CBA_DETAIL:
			return REQ_URL_GET_CBA_NEWS_DETAIL;
			
		case REQ_METHOD_CBA_NEXT:
		case REQ_METHOD_CBA_PREV:
		case REQ_METHOD_CBA_BY_ID:
			return REQ_URL_GET_CBA;
			
		case REQ_METHOD_CBA_BOX_SCORE :
			return REQ_URL_CBA_BOX_SCORE ;
			
		case REQ_METHOD_NBA_CHAT :
		case REQ_METHOD_NBA_CHAT_MORE :
		case REQ_METHOD_NBA_CHAT_NEW :
		   return REQ_URL_NBA_CHAT;
		   
		case  REQ_METHOD_SENT_CHAT:
			return REQ_URL_SENT_CHAT ;
		}
	}

	public static final String SOCKET_SERVER_DEFAULT = "http://192.168.8.49:8080/nba_v1";
	public static final String ROOM_NBA_HOME = "NBA_HOME";
	public static final String ROOM_PLAYBYPLAY = "NBA_PLAYBYPLAY";
	public static final String ROOM_NBA_BOXSCORE = "NBA_BOXSCORE";
	public static final String ROOM_NBA_CHAT = "CHAT";
	
	public static void setServer(String s1, String s2) {
		if (s1 != null && s1.indexOf("http") < 0) {
			socket_server = "http://" + s1 + "/nba_v1";
			socket_backup = "http://" + s2 + "/nba_v1";
		}

	}

	static String strClient = "xxx";
	static String strToken = "";

	public static String getDefaultServer() {
		if(socket_server!=null)
			return socket_server;
		if (socket_server == null
				&& SharedPreferencesMgr.getString("default_server", null) != null) {
			socket_server = "http://"
					+ SharedPreferencesMgr.getString("default_server", null)
					+ "/nba_v1";
			return socket_server;
		}
		return null;
	}

	public static String getBackUpServer() {
		if(socket_backup!=null)
			return null;
		if (socket_backup == null
				&& SharedPreferencesMgr.getString("backup_server", null) != null) {
			socket_backup = "http://"
					+ SharedPreferencesMgr.getString("backup_server", null)
					+ "/nba_v1";
			return socket_backup;
		}
		return null;
	}

	private static String socket_server;
	private static String socket_backup;

	/** url�Ĳ��� */
	public static String getParameter() {
		return "?client=" + strClient +"&t="
				+ System.currentTimeMillis()/ 1000 + "&type=1";
	}

	public static void setClient(String client) {
		strClient = client;
	}

	public static String UMENG_KEY_GUIDE_DONE = "guideDone";
	public static String UMENG_KEY_GUIDE_FOLLOW = "guideFollow";
	public static String UMENG_KEY_SETTING_FOLLOW = "settingsFollow";
	public static String UMENG_KEY_SWIPE_LEFT = "homeSwipeLeft";
	public static String UMENG_KEY_SWIPE_RIGHT = "homeSwipeRight";
	public static String UMENG_KEY_HOME_FOLLOW = "homeFollow";
	public static String UMENG_KEY_HOME_UNFOLLOW = "homeUnfollow";
	public static String UMENG_KEY_HOME_TAP_GAME = "homeTapOneGame";
	public static String UMENG_KEY_GAME_TAP_TAB = "gameTapTab";
	public static String UMENG_KEY_GAME_FOLLOW = "gameFollow";
	public static String UMENG_KEY_GAME_UNFOLLOW = "gameUnfollow";
	public static String UMENG_KEY_BROWSER = "browser";
	public static String UMENG_KEY_NOTIFICATION_CLICK = "notificationsClick";
	public static String UMENG_KEY_NOTIFICATION_SEND = "notificationsSent";
	public static String UMENG_KEY_TV_OPEN = "gameTvOpen";
	public static String UMENG_KEY_BROWSER_ACTIONS = "browserActions";
	public static String UMENG_KEY_V2H = "v2h";
	public static String UMENG_KEY_H2V = "H2V";
	public static String UMENG_KEY_V_FULLSCREEN="vFullScreen";
	public static String UMENG_KEY_H_FULLSCREEN ="hFullScreen";
	public static String UMENG_KEY_INDEX_TAB_ACTIONS = "tabBar";
	public static String UMENG_KEY_NBA_GAMES = "nbaGames";
	public static String UMENG_KEY_CBA_GAMES = "cbaGames";
	public static String UMENG_KEY_NBA_STANDINGS = "nbaStandings";
	public static String UMENG_KEY_CBA_STANDINGS = "cbaStandings";
	public static String UMENG_KEY_NETWORK = "network";
	
	public static String UMENG_KEY_FAILED = "failed";
	public static String UMENG_KEY_TIMEOUT = "timeout";
	public static String UMENG_KEY_TIPS = "tip";
	public static String UMENG_KEY_GAMEBOX_SCORE = "gameBoxscore";	
	public static String UMENG_KEY_GAMEBOX_H2V = "gameBoxscoreH2V";
	public static String UMENG_KEY_GAME_PLAY= "gamePlaybyplay";
	public static String UMENG_KEY_REFRESH = "refresh";
	
	public static String UMENG_KEY_NBA_VIDEO = "nbaVideo";
	public static String UMENG_KEY_CBA_VIDEO = "cbaVideo";
	public static String UMENG_KEY_NBA_CHAT = "nbaChat";
	public static String UMENG_KEY_VIDEO = "video";
	public static String UMENG_KEY_NEWS = "news";
	public static String UMENG_KEY_CBA = "cba";
	public static String UMENG_KEY_VIDEO_HOT = "hot";
	public static String UMENG_KEY_VIDEO_GAME = "game";
	public static String UMENG_LOAD_MORE = "loadMore";
	public static String UMENG_OPEN = "open";
	
	public static String UMENG_KEY_NBA_NEWS= "nbaNews";
	public static String UMENG_KEY_CBA_NEWS= "cbaNews";
	
	public static String UMENG_KEY_SETTING = "setting";
	public static String UMENG_KEY_NAV="nav";
	
	public static String UMENG_KEY_NOTIFICATIONS_CLOSE= "notificationsClose";
	public static String UMENG_KEY_NOTIFICATIONS_OPEN= "notificationsOpen";
	public static String UMENG_KEY_NOTIFICATIONS_OPEN_CONFIRM= "notificationsOpenViaConfirm";
	
	public static String UMENG_KEY_NBA_CLICK_COMMENT= "clickCommentBtn";
	
	public static String UMENG_KEY_CBA_LIVE= "cbaGameLive";
	


	
}
