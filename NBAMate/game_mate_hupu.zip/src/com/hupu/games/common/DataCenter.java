package com.hupu.games.common;

import com.hupu.games.data.CBAResp;
import com.hupu.games.data.GamesResp;
import com.hupu.games.data.StandingsResp;

public class DataCenter {

	public void treatDataResponse(int methodId)
	{
		
		switch (methodId) {
		
		}

	}

}
