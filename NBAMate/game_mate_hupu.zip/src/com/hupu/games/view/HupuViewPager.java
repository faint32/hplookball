package com.hupu.games.view;

import java.text.AttributedCharacterIterator.Attribute;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

public class HupuViewPager extends ViewPager {

	public HupuViewPager(Context context) {
		super(context);		
		
	}
	
	public HupuViewPager(Context context,AttributeSet set ) {
		super(context,set);
	
	}
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent arg0) {
//		Log.d("HupuViewPager", "onInterceptTouchEvent");
		return false;
	}

	@Override
	public boolean onTouchEvent(MotionEvent arg0) {
//		Log.d("HupuViewPager", "onTouchEvent");
	    return false;
	}
	
	
}
