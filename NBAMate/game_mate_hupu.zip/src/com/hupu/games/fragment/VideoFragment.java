package com.hupu.games.fragment;

import java.util.HashMap;
import java.util.LinkedList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

import com.hupu.games.R;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.StandingsListAdapter;
import com.hupu.games.adapter.VideoListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.data.VideoEntity;
import com.hupu.games.data.NewsResp;
import com.hupu.games.data.VideoResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.view.RefreshListView;
import com.hupu.games.view.RefreshListView.RefreshListener;
import com.hupu.games.view.XListView;
import com.hupu.games.view.XListView.IXListViewListener;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

@SuppressLint("ValidFragment")
public class VideoFragment extends BaseFragment {



	private XListView mListVideo;
	private Button mGameVideo;

	private Button mRecommandVideo;

	private VideoListAdapter mVideoAdapter;

	private LinkedList<VideoEntity> mGameData;

	private LinkedList<VideoEntity> mHotData;

	private int frame;

	private long lastGameVid;

	private long lastHotVid;

	/** ���ˢ�±�����Ƶ��ʱ�� */
	private long mLastGameTime;
	/** ���ˢ���Ƽ���Ƶ��ʱ�� */
	private long mLastHotTime;
	/***/
	private static final long TEN_MINS = 600000;
	/***/
	boolean bNeedFreshGame;
	/***/
	boolean bNeedFreshHot;

	private Click click;

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	private RequestParams mParams;

	private int methodGame;
	private int methodHot;
	private int methodGameNext;
	private int methodHotNext;

	private int gameType;
	String ukey;
	public VideoFragment()
	{
		methodGame = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME;
		methodHot = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT;
		methodGameNext = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT;
		methodHotNext = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT;
		ukey =HuPuRes.UMENG_KEY_NBA_VIDEO; 
	}
	
	public VideoFragment(int type) {
		gameType = type;
		if (type == 0) {
			// nba
			methodGame = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME;
			methodHot = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT;
			methodGameNext = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT;
			methodHotNext = HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT;
			ukey =HuPuRes.UMENG_KEY_NBA_VIDEO; 
		} else {
			// cba
			methodGame = HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME;
			methodHot = HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT;
			methodGameNext = HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT;
			methodHotNext = HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT;
			ukey =HuPuRes.UMENG_KEY_CBA_VIDEO; 
		}
	}



	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.fragment_video, container, false);
		mGameVideo = (Button) v.findViewById(R.id.btn_video_game);
		mRecommandVideo = (Button) v.findViewById(R.id.btn_video_hot);
		click = new Click();

		mGameVideo.setOnClickListener(click);
		mRecommandVideo.setOnClickListener(click);

		if(gameType ==1)
		{
			v.findViewById(R.id.layout_top).setVisibility(View.GONE);
		}
		mListVideo = (XListView) v.findViewById(R.id.list_video);

		if (mVideoAdapter == null) {
			mVideoAdapter = new VideoListAdapter(getActivity());
		}

		ListClick listClick = new ListClick();
		mListVideo.setOnItemClickListener(listClick);
		mListVideo.setXListViewListener(new pullListener());
		mListVideo.setAdapter(mVideoAdapter);
		// ��ʼ��ʱ����Ҫˢ��
		mListVideo.setPullLoadEnable(false, false);
		if (bFirstCreate) {
			bFirstCreate = false;
			reqNewData(false);
		}
		return v;
	}

	/** ��ȡ�������� */
	public void reqNewData(boolean isMan) {

		if (frame == 0) {
			if (mGameData == null)
				mListVideo.setPullLoadEnable(false, false);
			if (!isMan)
				mListVideo.setFreshState();
			reqVideoData(methodGame, 0, "game");
		} else {
			if (mHotData == null)
				mListVideo.setPullLoadEnable(false, false);
			if (!isMan)
				mListVideo.setFreshState();
			reqVideoData(methodHot, 0, "hot");
		}
	}

	/** ������Ƶ���� */
	private void reqVideoData(int reqid, long vid, String type) {
		mParams = mAct.getHttpParams(true);
		mParams.put("type", type);
		if (vid > 0)
			mParams.put("vid", "" + vid);
		switch (reqid) {
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_NBA_VIDEO_HOT_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_GAME_NEXT:
		case HuPuRes.REQ_METHOD_GET_CBA_VIDEO_HOT_NEXT:
			mParams.put("direc", "next");
			break;
		}
		mAct.sendRequest(reqid, mParams);
	}

	int pageGame;
	int pageHot;

	/** ��ȡ�������� */
	private void reqMoreData() {
		UMENG_MAP.clear();
		if (frame == 0) {
			UMENG_MAP.put(HuPuRes.UMENG_LOAD_MORE, "" + pageGame++);
			MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);
			reqVideoData(methodGameNext, lastGameVid, "game");
		} else {
			UMENG_MAP.put(HuPuRes.UMENG_LOAD_MORE, "" + pageHot++);
			MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);
			reqVideoData(methodHotNext, lastHotVid, "hot");
		}
	}

	private boolean bFirstCreate;

	/**
	 * ��������ҳ���л�����
	 * */
	public void entry() {
		if (mAct == null) {
			bFirstCreate = true;
		} else {
			long curTime = System.currentTimeMillis();
			if (curTime - mLastGameTime > TEN_MINS) {
				bNeedFreshGame = true;
			}
			if (curTime - mLastHotTime > TEN_MINS) {
				bNeedFreshHot = true;
			}

			if (frame == 0 && bNeedFreshGame || frame == 1 && bNeedFreshHot) {
				reqNewData(false);
			}
		}

	}

	/**
	 * ��ֵ��ˢ��
	 * */
	public void setData(int method, Object o) {

		VideoResp resp = (VideoResp) o;
		if (resp.nextDataExists > 20)
			mListVideo.setPullLoadEnable(true, false);
		else {
			mListVideo.setPullLoadEnable(false, true);
			mAct.showToast("û�и�����Ƶ��");
		}

		if (method == methodGame) {
			mLastGameTime = System.currentTimeMillis();
			bNeedFreshGame = false;
		} else if (method == methodGameNext) {
			if (mGameData == null)
				method =methodGame;
		} else if (method == methodHot) {
			mLastHotTime = System.currentTimeMillis();
			bNeedFreshHot = false;
		} else if (method == methodHotNext) {
			if (mHotData == null)
				method = methodHot;
		}

		// ---
		if (method == methodGame) {
			mGameData = resp.mList;
			pageGame = 0;
		} else if (method == methodGameNext) {
			mGameData.addAll(resp.mList);
		} else if (method == methodHot) {
			mHotData = resp.mList;
			pageHot = 0;
		} else if (method == methodHotNext) {
			mHotData.addAll(resp.mList);
		}

		if (method < methodHot)
			lastGameVid = resp.lastVId;
		else
			lastHotVid = resp.lastVId;
		refreshListViewData(method < methodHot ? 0 : 1);

	}

	/** ֹͣ���ض��� */
	public void stopLoad(boolean bDelay) {
		// Log.d("video", "stopLoad");
		mListVideo.stopRefresh();
		mListVideo.stopLoadMore();
	}

	/** ˢ���б����� */
	private void refreshListViewData(int type) {
		if (type == 0 && frame == 0)
			mVideoAdapter.setData(mGameData);
		if (type == 1 && frame == 1)
			mVideoAdapter.setData(mHotData);
	}

	private class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
			case R.id.btn_video_game:
				frame = 0;
				refreshListViewData(0);
				if (mGameData != null)
					mListVideo.setSelection(0);
				if (mGameData == null || bNeedFreshGame)
					reqNewData(false);

				mGameVideo.setTextColor(Color.WHITE);
				mGameVideo.setBackgroundResource(R.drawable.btn_red_standing);
				mRecommandVideo
						.setBackgroundResource(R.drawable.btn_gray_standing_hover);
				mRecommandVideo.setTextColor(Color.GRAY);
				break;
			case R.id.btn_video_hot:
				frame = 1;
				refreshListViewData(1);
				if (mHotData != null)
					mListVideo.setSelection(0);
				if (mHotData == null || bNeedFreshHot) {
					reqNewData(false);
				}

				mRecommandVideo.setTextColor(Color.WHITE);
				mRecommandVideo
						.setBackgroundResource(R.drawable.btn_red_standing);
				mGameVideo
						.setBackgroundResource(R.drawable.btn_gray_standing_hover);
				mGameVideo.setTextColor(Color.GRAY);
				break;
			}

		}
	}

	/** ����listview �����������ļ��� */
	class pullListener implements IXListViewListener {

		@Override
		public void onRefresh() {
			reqNewData(true);
		}

		@Override
		public void onLoadMore() {
			reqMoreData();
		}

	}

	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
			if (pos < 1)
				return;
			UMENG_MAP.clear();
			if(gameType ==0)
			{
				UMENG_MAP.put(ukey,
						frame == 0 ? HuPuRes.UMENG_KEY_VIDEO_GAME
								: HuPuRes.UMENG_KEY_VIDEO_HOT);
				MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);
			}
			else
			{
				UMENG_MAP.put(ukey,HuPuRes.UMENG_OPEN);
				MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);
			}
			
			Intent in = new Intent(getActivity(), WebViewActivity.class);
			in.putExtra("url", mVideoAdapter.getItem(pos - 1).fromurl);
			startActivity(in);
		}

	}
}
