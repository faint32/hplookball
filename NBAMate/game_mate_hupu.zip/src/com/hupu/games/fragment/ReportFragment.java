package com.hupu.games.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.Recap;
import com.umeng.analytics.MobclickAgent;

public class ReportFragment extends BaseFragment {

	private WebView mWebView;
	private TextView mTxtTitle;
	
	View mProgressBar;
	
	private Recap data;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if(savedInstanceState!=null)
		{
			if(data== null )
				data=(Recap)savedInstanceState.getSerializable("data");
		}
		View v =inflater.inflate(R.layout.fragment_report, null);
		mWebView=(WebView)v.findViewById(R.id.web_content);
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				Intent in =new Intent(getActivity(),WebViewActivity.class);
				 in.putExtra("url", url);
				startActivity(in);
				MobclickAgent.onEvent(ReportFragment.this.getActivity(), HuPuRes.UMENG_KEY_BROWSER);

				return true;
			}

		});
		mTxtTitle=(TextView)v.findViewById(R.id.txt_report_title);
		mProgressBar=v.findViewById(R.id.probar);
		if(data!=null)
			setData(data);
		return v;
	}
	
	private static final String mimeType = "text/html";
	private static final String encoding = "utf-8";

	public void setData(Recap d)
	{
		data=d;
		if(mProgressBar!=null )
			mProgressBar.setVisibility(View.GONE);
		if(data!=null && mTxtTitle!=null)
		{
			mTxtTitle.setText(data.str_title);
			mWebView.loadDataWithBaseURL(null, getContent(data.str_content), mimeType,
					encoding, null);
		}
	}
	
	private String getContent(String c)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("<html xmlns=\"http://www.w3.org/1999/xhtml\">"
				+ "<head>"
				+ "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
				+ "<title></title>"
				+"</head>" + "<body>"
				+c
			    +"</body></html>");
		return sb.toString();
	}
	@Override
    public void onSaveInstanceState(Bundle outState) {
		if(data!=null)
			outState.putSerializable("data", data);
        super.onSaveInstanceState(outState);
        setUserVisibleHint(true);
    }
}
