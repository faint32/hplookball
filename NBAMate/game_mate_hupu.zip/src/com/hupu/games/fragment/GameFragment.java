package com.hupu.games.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.hupu.games.R;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.adapter.GamePagerAdapter;
import com.hupu.games.adapter.GamesListAdapter;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;

@SuppressLint("ValidFragment")
public class GameFragment extends BaseFragment {

	private GamesListAdapter mListAdapter;
	private OnClickListener mClick;
	private ListView mLvGames;
	public long l_date;
	private View mProgressBar;
	GamePagerAdapter mPageAdapter;
	private GamesResp entity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// System.out.println("GameFragment oncreate");
		super.onCreate(savedInstanceState);
		mClick = new Click();
		mListAdapter = new GamesListAdapter(getActivity(), mClick);
	}

	public static GameFragment newInstance(long date, GamePagerAdapter gpa) {
		GameFragment temp = new GameFragment(date, gpa);
		return temp;
	}

	public GameFragment(long date, GamePagerAdapter gpa) {
		super();
		l_date = date;
		mPageAdapter = gpa;

	}

	public GameFragment() {
		super();
		bQuit = true;
	}

	public void initLater(long date, GamePagerAdapter gpa) {
		l_date = date;
		mPageAdapter = gpa;
		mListAdapter = new GamesListAdapter(getActivity(), mClick);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater
				.inflate(R.layout.fragment_game_list, container, false);
		mLvGames = (ListView) v.findViewById(R.id.list_games);
		mLvGames.setAdapter(mListAdapter);
		mLvGames.setOnItemClickListener(new ListClick());
		mProgressBar = v.findViewById(R.id.probar);
		// getData();
		if (entity != null) {
			if (mProgressBar != null)
				mProgressBar.setVisibility(View.GONE);
			mListAdapter.setData(entity.mGameList);
		}
		return v;
	}

	// @Override
	// public void onResume() {
	//
	// super.onResume();
	// if (entity != null) {
	// if (mProgressBar != null)
	// mProgressBar.setVisibility(View.GONE);
	// mListAdapter.setData(entity.gameList);
	// }
	// }

	public void getData() {
		if (mPageAdapter != null)
			entity = mPageAdapter.getData(l_date);
		// System.out.println("getData entity");
	}

	public void setData(GamesResp en) {
		if (mProgressBar != null) {
			mProgressBar.setVisibility(View.GONE);
		}
		entity = en;
		if (entity != null && mListAdapter != null) {
			mListAdapter.setData(entity.mGameList);
		}
	}

	/** ���±�����ע��״̬ */
	public void setFollowInfo(int pos, int follow) {
		mListAdapter.setFollow(pos, follow);
	}

	// @Override
	// public void onSaveInstanceState(Bundle outState) {
	// super.onSaveInstanceState(outState);
	// setUserVisibleHint(true);
	// }

	@Override
	public void onResume() {
		// System.out.println(" game fragment onresume");
		super.onResume();
	}

	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
			// System.out.println("ListClick lick pos=" + pos);
			((TabIndexActivity) getActivity()).switchToLive(
					mListAdapter.getItem(pos), pos);
		}

	}

	class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int pos = (Integer) v.getTag();
			GameEntity entity = mListAdapter.getItem(pos);
			entity.i_isFollow = entity.i_isFollow > 0 ? 0 : 1;
			mListAdapter.notifyDataSetChanged();
			((TabIndexActivity) getActivity()).setFollowGame(entity);
		}
	}

}
