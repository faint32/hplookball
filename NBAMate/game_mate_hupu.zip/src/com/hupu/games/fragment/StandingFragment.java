package com.hupu.games.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import com.hupu.games.R;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.adapter.StandingsListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.pyj.http.RequestParams;

public class StandingFragment extends BaseFragment {


	private ListView mLvStandings;


	private Button mBtnWest;

	private Button mBtnEast;

	private StandingsListAdapter mStandingAdapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		mAct = (HupuSlidingActivity) getActivity();
		super.onActivityCreated(savedInstanceState);
	}

	Click click;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.fragment_standing, container, false);
		mBtnWest = (Button) v.findViewById(R.id.btn_west);
		mBtnEast = (Button) v.findViewById(R.id.btn_east);
		click = new Click();
		mBtnWest.setOnClickListener(click);
		mBtnEast.setOnClickListener(click);
		mLvStandings = (ListView) v.findViewById(R.id.list_standings);
		if (mStandingAdapter == null) {
			mStandingAdapter = new StandingsListAdapter(getActivity());
		}
		if (savedInstanceState != null) {
			data = (StandingsResp) savedInstanceState.getSerializable("data");
			setData(data);
		}
		mLvStandings.setAdapter(mStandingAdapter);
		return v;
	}
	
	
	public void setData(StandingsResp resp) {
		if(mStandingAdapter!=null)
			mStandingAdapter.setData(resp);
	}

	StandingsResp data;

	@Override
	public void onSaveInstanceState(Bundle outState) {
		if (data != null)
			outState.putSerializable("data", data);
		super.onSaveInstanceState(outState);
	}

	private class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
			case R.id.btn_west:
				mStandingAdapter.switchToWest();
				if(mStandingAdapter!=null && mStandingAdapter.getCount()>0)
					mLvStandings.setSelection(0);
				

				mBtnWest.setTextColor(Color.WHITE);
				mBtnWest.setBackgroundResource(R.drawable.btn_red_standing);
				mBtnEast.setBackgroundResource(R.drawable.btn_gray_standing_hover);
				mBtnEast.setTextColor(Color.GRAY);
				break;
			case R.id.btn_east:
				mStandingAdapter.switchToEast();
				if(mStandingAdapter!=null && mStandingAdapter.getCount()>0)
					mLvStandings.setSelection(0);
				
				mBtnEast.setTextColor(Color.WHITE);
				mBtnEast.setBackgroundResource(R.drawable.btn_red_standing);
				mBtnWest.setBackgroundResource(R.drawable.btn_gray_standing_hover);
				mBtnWest.setTextColor(Color.GRAY);
				break;
			}
		}
	}

	

}
