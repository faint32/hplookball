package com.hupu.games.fragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.hupu.games.R;
import com.hupu.games.activity.CBAGameActivity;
import com.hupu.games.activity.HupuDataActivity;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.CBAGamesListAdapter;
import com.hupu.games.adapter.GamePagerAdapter;
import com.hupu.games.adapter.GamesListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.CBAData;
import com.hupu.games.data.CBAResp;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.view.PinnedHeaderListView;
import com.pyj.common.MyUtility;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

public class NbaGameFragment extends BaseFragment {

	// private LinkedHashMap<Long,GamesListAdapter> mListAdapterMap;

	private GamesListAdapter mListAdapter;

	private HashMap<Long, GamesResp> mGamesMap;

	private View mProgressBar;

	private TextView mBtnNext;
	private TextView mBtnPrev;

	HupuSlidingActivity mAct;

	private TextView mTxtDate;

	/** ʱ���б� */
	LinkedList<Long> dateList;

	/** �����������ʱ�� */
	public long mToday;

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	/** ��ǰ�����ڼ�ҳ */
	private int mCurIndex;

	private boolean bHasNext = true;

	private boolean bHasPre = true;

	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"yyyy-MM-dd", java.util.Locale.CHINESE);

	private GamesResp mEntity;

	RequestParams mParams;

	/** ��ǰ����ı��������� */
	private long l_curDay;

	/** ����ı����б��Ķ��У���Ҫ�������ظ�����ͬһ��ı��� */
	private ArrayList<String> mListReqQue;

	/** �����ǲ��Ǳ����� */
	public boolean bMatchDay;

	// int offset;

	boolean bFirstCreate;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		dateList = new LinkedList<Long>();
		mGamesMap = new HashMap<Long, GamesResp>();
		mListReqQue = new ArrayList<String>();
		setRetainInstance(true);
	}

	ListView listview;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.fragment_nba_games, null);
		mAct = (HupuSlidingActivity) getActivity();
		Click click = new Click();

		mBtnNext = (TextView) v.findViewById(R.id.btn_nba_next);
		mBtnPrev = (TextView) v.findViewById(R.id.btn_nba_pre);
		mTxtDate = (TextView) v.findViewById(R.id.txt_nba_cur);
		listview = (ListView) v.findViewById(R.id.list_games);
		mProgressBar = v.findViewById(R.id.probar);

		mBtnNext.setOnClickListener(click);
		mBtnPrev.setOnClickListener(click);

		if (mListAdapter == null) {
			mListAdapter = new GamesListAdapter(mAct, click);
		} else {
			// �ָ�����
			setTitle();
			if (mToday != 0)
				mProgressBar.setVisibility(View.GONE);
		}

		listview.setAdapter(mListAdapter);
		listview.setOnItemClickListener(new ListClick());

		if (bFirstCreate) {
			bFirstCreate = false;
			req(0, 0);
		}

		return v;
	}

	public void setDay(long today) {
		dateList.add(today);
	}

	public void setPreDate(List<Long> l) {
		if (l != null) {
			if (!dateList.contains(l.get(0))) {
				dateList.addAll(0, l);
				// offset += l.size();
				mCurIndex += l.size();
			}
		}
	}

	public void setNextDate(List<Long> l) {
		if (l != null) {
			if (!dateList.contains(l.get(0)))
				dateList.addAll(dateList.size(), l);
		}
	}

	/**
	 * ����http�����б�����
	 * */
	public void req(long date, int direct) {

		if (date < 0)
			date = l_curDay;
		if (mProgressBar != null) {
			if (mGamesMap.get(date) == null)
				mProgressBar.setVisibility(View.VISIBLE);
			else
				mProgressBar.setVisibility(View.GONE);
		}
		if (mListReqQue.contains(date + ""))
			return;
		int reqType;
		mParams = mAct.getHttpParams(true);

		// ����ʱ����Ϣ��ȡ���һ�����Ϣ
		if (date > 0) {
			l_curDay = date;
			mParams.put(BaseEntity.KEY_DATE, "" + date);
			if (direct > 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_NEXT);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT;
			} else if (direct < 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_PREV);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE;
			} else
				reqType = HuPuRes.REQ_METHOD_GAMES_BY_DATE;
		} else
			reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER;

		if (mAct.sendRequest(reqType, mParams))
			mListReqQue.add(date + "");
		else
			mListReqQue.clear();
	}

	private void prev() {
		MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_SWIPE_LEFT, UMENG_MAP);
		if (mCurIndex == 0)
			return;
		mCurIndex--;

		long date = dateList.get(mCurIndex);
		GamesResp resp = mGamesMap.get(date);
		if (resp == null) {
			mListAdapter.setData(null);
		} else {
			mListAdapter.setData(resp.mGameList);
			listview.setSelection(0);
		}

		if (getTailNum(mCurIndex) == 2 && bHasPre) {
			req(date, -1);
		} else {
			req(date, 0);
		}
		setTitle();
	}

	private void next() {
		MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_SWIPE_RIGHT, UMENG_MAP);
		mCurIndex++;
		if (mCurIndex >= dateList.size()) {
			mCurIndex--;
			return;
		}
		long date = dateList.get(mCurIndex);
		GamesResp resp = mGamesMap.get(date);
		if (resp == null) {
			mListAdapter.setData(null);
		} else {
			mListAdapter.setData(resp.mGameList);
			listview.setSelection(0);
		}
		if (getHeadNum(mCurIndex) == 2 && bHasNext) {
			req(date, 1);
		} else {
			req(date, 0);
		}

		setTitle();
	}

	public int getHeadNum(int cur) {
		return dateList.size() - cur;
	}

	public int getTailNum(int cur) {
		return cur;
	}

	public CharSequence getPageTitle(int position) {
		if (position < 0 || position >= dateList.size())
			return null;
		long date = dateList.get(position);
		if (date == mToday)
			return "����";
		return MyUtility.getFormateDate(date * 1000);
	}

	private void setTitle() {
		Log.d("setTitle", "mCurIndex=" + mCurIndex);
		mBtnNext.setText(getPageTitle(mCurIndex + 1));
		mBtnPrev.setText(getPageTitle(mCurIndex - 1));
		mTxtDate.setText(getPageTitle(mCurIndex));
	}

	public void setData(int methodId, GamesResp entity) {
		if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER) {
			if (bMatchDay = entity.isMatchDay) {
				mAct.joinRoom();// ����Ǳ����գ���ʼsocket����
				if (entity.mGameList.size() > 0
						&& entity.mGameList.get(0).byt_status == 2)
					mAct.setScreenLight(true);
				else
					mAct.setScreenLight(false);
			}
		} else {
			if (entity.mGameList != null) {
				mListReqQue.remove("" + entity.mGameList.get(0).l_date_time);
			}
		}

		if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER) {
			if (entity != null && entity.mGameList != null) {
				mToday = entity.l_server_day;
				l_curDay=entity.l_game_day;
				mEntity = entity;
				setDay(mEntity.l_game_day);
				setPreDate(mEntity.preList);
				setNextDate(mEntity.nextList);
				setFragmentData(mEntity.l_game_day, entity, false);
			}
		} else {

			if (entity.mGameList == null)
				return;
			if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT) {
				int retSize = entity.nextList.size();
				if (retSize < 2)
					bHasNext = false;
				else
					setNextDate(entity.nextList.subList(1, retSize));
			} else if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE) {
				int retSize = entity.preList.size();
				if (retSize < 2)
					bHasPre = false;
				else {
					setPreDate(entity.preList.subList(0, retSize - 2));
				}
			}
			setFragmentData(entity.mGameList.get(0).l_date_time, entity, false);
		}

		setTitle();
	}

	public void setFragmentData(long date, GamesResp entity, boolean keep) {

		if (keep) {
			GamesResp temp = mGamesMap.get(date);
			if (temp != null) {
				int size = temp.mGameList.size();
				int oldIndex = 0;
				for (int i = 0; i < size; i++) {
					// ʵʱ�������ݻ��������������˳��仯��������Ҫ��λ�ϴα���ı�����λ�ã�
					oldIndex = temp.mGameIdList
							.indexOf(entity.mGameList.get(i).i_gId);
					// System.out.println("old index="+oldIndex);
					// ʵʱ�������ݻ���������Ĳ�������ע��Ϣ��������Ҫ���ϴα���ı��������ݸ��ƹ�ȥ��
					entity.mGameList.get(i).i_isFollow = temp.mGameList
							.get(oldIndex).i_isFollow;
				}
			}
		}
		mGamesMap.put(date, entity);
		if (date == l_curDay || l_curDay == 0) {
			if (mProgressBar != null)
				mProgressBar.setVisibility(View.GONE);
			mListAdapter.setData(entity.mGameList);
		}

	}

	/** ���±�����ע��״̬ */
	public void updateFollow(long date, int gId, int follow) {

		GamesResp temp = mGamesMap.get(date);
		int pos = temp.mGameIdList.indexOf(gId);
		if (pos > -1) {
			temp.mGameList.get(pos).i_isFollow = follow;
			if (date == l_curDay)
				mListAdapter.setFollow(pos, follow);
		}
	}

	public void entry() {
		if (mAct == null)
			bFirstCreate = true;
		else {
			if (l_curDay == 0)
				req(0, 0);
		}
	}

	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {

			GameEntity data = mListAdapter.getItem(pos);

			if (data != null) {
				mAct.switchToLive(data, pos, bMatchDay);
			}
		}

	}

	class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
			case R.id.btn_nba_next:
				next();
				break;
			case R.id.btn_nba_pre:
				prev();
				break;
			case R.id.btn_follow:
				int pos = (Integer) v.getTag();
				GameEntity entity = mListAdapter.getItem(pos);
				// entity.i_isFollow = entity.i_isFollow > 0 ? 0 : 1;
				// mListAdapter.notifyDataSetChanged();
				mAct.setFollowGame(entity);
				break;
			}
		}
	}

	public void updatefollow(GameEntity entity) {
		entity.i_isFollow = entity.i_isFollow > 0 ? 0 : 1;
		mListAdapter.notifyDataSetChanged();
	}
}
