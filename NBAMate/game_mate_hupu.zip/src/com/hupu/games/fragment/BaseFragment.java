package com.hupu.games.fragment;

import com.hupu.games.activity.HupuSlidingActivity;
import com.pyj.http.RequestParams;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;

public class BaseFragment extends Fragment {
	protected boolean bQuit;

	protected HupuSlidingActivity mAct;

	protected boolean bFirstCreate;

	public boolean bBlank;


	protected RequestParams mParams;
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		if(activity instanceof HupuSlidingActivity)
			mAct = (HupuSlidingActivity) activity;
//		Log.d("onAttach", getClass().getName());
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
//		Log.d("onCreate", getClass().getName());
	}



	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		if (bQuit)
			// ((BaseActivity)getActivity()).quit();
			bBlank = true;
	}


}
