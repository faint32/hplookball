package com.hupu.games.fragment;

import java.util.Arrays;
import java.util.LinkedList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.hupu.games.HuPuApp;
import com.hupu.games.R;
import com.hupu.games.activity.HupuDataActivity.BoxscoreDatas;
import com.hupu.games.adapter.GameDataListAdapter;
import com.hupu.games.data.BoxScoreResp;
import com.hupu.games.data.MatchEntity;
import com.hupu.games.data.PlayerEntity;
import com.hupu.games.view.PinnedHeaderListView;

/**
 * ͳ��ҳ��
 * */
@SuppressLint("ValidFragment")
public class StatisticFragment extends BaseFragment {

	/** ���ͳ������ */
	private PinnedHeaderListView mLvDatas;

	private GameDataListAdapter mDataListAdapter;

	private TableLayout mTable;

	private Activity mAct;

	private int i_homeId;
	private int i_awayId;

	// private BoxScoreResp data;
	// private TextView[] arrHomeScore;
	// private TextView[] arrAwayScore;
	/**
	 * �ȷ�ͳ�Ʊ�����
	 * */
	private String[] arrTitles;
	/**
	 * �ȷ�ͳ��keyֵ
	 * */
	private LinkedList<String> listKeys;

	View mProgressBar;
	private BoxScoreResp mData;
	/**
	 * �ȷ�ͳ�Ʊ��������ж�����
	 * */
	private int i_columnSize;
	/** ����ж��ٴμ�ʱ�� */
	private static final int MAX_OT_SIZE = 5;
	/** ��ʼ��ʱ�ܷ����ڵ�����λ�� */
	private static final int COLUMN_TOTAL_INDEX = 5;

	private static final int TITLE_TOTAL_INDEX = 9;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mAct = getActivity();
		if (arrTitles == null) {
			listKeys = new LinkedList<String>();
			arrTitles = mAct.getResources().getStringArray(R.array.title_score);
			listKeys.addAll(Arrays.asList(mAct.getResources().getStringArray(
					R.array.key_score)));
		}
		mDataListAdapter = new GameDataListAdapter(getActivity(), i_homeId,
				i_awayId);

	}

	private View.OnTouchListener gestureListener;

	public StatisticFragment(int h, int a, OnTouchListener o) {
		super();
		i_homeId = h;
		i_awayId = a;
		gestureListener = o;

	}

	public StatisticFragment() {
		super();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
//		Log.d("StatisticFragment", "onCreateView");
		View v = inflater.inflate(R.layout.fragment_statistics, container,
				false);

		mProgressBar = v.findViewById(R.id.probar);
		mTable = (TableLayout) v.findViewById(R.id.table_score);
		mLvDatas = (PinnedHeaderListView) v.findViewById(R.id.list_players);
		mLvDatas.setAdapter(mDataListAdapter);
		mLvDatas.setOnTouchListener(gestureListener);
		initRow();
		return v;
	}

	public void entry() {
//		initRow();
//		if (mData != null)
//		{
//			setData(mData,true);
//		}
	}

	boolean bGetData;

	public void addData(boolean b) {
		bGetData = b;
		if (bGetData && mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
	}

	public void setData(BoxScoreResp data,boolean byMan) {
		bGetData = true;
		if (mProgressBar != null && !byMan)
			mProgressBar.setVisibility(View.GONE);
		mData = data;
		// ��Ҫ������title
		if (data != null && mLvDatas != null) {

			mLvDatas.setVisibility(View.VISIBLE);
			mTable.setVisibility(View.VISIBLE);

			mDataListAdapter.setData(data);

			setTableData(data.mEntityHome, data.mEntityAway);
		}
	}

	public LinkedList<String> getKeys() {
		if (mDataListAdapter != null)
			return mDataListAdapter.getKeys();
		return null;
	}

	public void updateData(BoxScoreResp data) {

		setTableData(data.mEntityHome, data.mEntityAway);
		mDataListAdapter.updateData(data);
	}

	public void updateBoxScoreData(BoxscoreDatas boxscoreData) {
		if (mDataListAdapter != null)
			mDataListAdapter.updatemBoxscoreDatas(boxscoreData);
	}

	/** ���ñ������ݣ���Ҫ��̬���Ӽ�ʱ���� */
	public void setTableData(MatchEntity entityHome, MatchEntity entityAway) {
		// arrHomeScore = new TextView[9];
		// arrAwayScore = new TextView[9];
		int otTime = 0;
		if (entityHome != null)
			otTime = entityHome.otTimes;
		if (entityAway != null)
			otTime = entityAway.otTimes > otTime ? entityAway.otTimes : otTime;
		if (otTime > i_columnSize - 6 && otTime <= MAX_OT_SIZE) {
			// �м�ʱ���Զ�����,�������ֻ������5��
			int size = entityHome.otTimes + 6 - i_columnSize;
			for (int i = 0; i < size; i++) {
				// System.out.println("add colum=" );
				addColumn();
			}
		}
		String ss = null;
		for (int i = 0; i < i_columnSize; i++) {
			if (i == 0) {
				getTextView(1, 0).setText(
						HuPuApp.getTeamData(i_homeId).str_name);
				getTextView(2, 0).setText(
						HuPuApp.getTeamData(i_awayId).str_name);
			} else {
				if (i == i_columnSize - 1) {
					if (entityHome != null) {
						ss = entityHome.mapScore.get(listKeys.getLast());
						if (ss != null && !"".equals(ss))
							getTextView(1, i).setText(ss);
					}

					if (entityAway != null) {
						ss = entityAway.mapScore.get(listKeys.getLast());
						if (ss != null && !"".equals(ss))
							getTextView(2, i).setText(ss);
					}

				} else {
					if (entityHome != null) {
						ss = entityHome.mapScore.get(listKeys.get(i - 1));
						if (ss != null && !"".equals(ss))
							getTextView(1, i).setText(ss);
					}

					if (entityAway != null) {

						ss = entityAway.mapScore.get(listKeys.get(i - 1));
						if (ss != null && !"".equals(ss))
							getTextView(2, i).setText(ss);
					}
				}
			}
		}
	}

	/** ��ʼ������ */
	private void initRow() {
		mTable.removeAllViews();
		// TableRow.LayoutParams lp = new TableRow.LayoutParams(0,
		// TableRow.LayoutParams.WRAP_CONTENT,1);
		TableRow.LayoutParams lp = new TableRow.LayoutParams();
		lp.setMargins(0, 0, 1, 1);
		for (int rowIndex = 0; rowIndex < 3; rowIndex++) {// ����

			TableRow row = new TableRow(mAct);
			for (int column = 0; column < 6; column++) {// 6��
				TextView tv = buildTextView(rowIndex);
				if (rowIndex == 0) {
					if (column == COLUMN_TOTAL_INDEX)// �ܷ�
					{
						tv.setText(arrTitles[TITLE_TOTAL_INDEX]);
						// lp.weight = 1;
					} else if (column > 0) {
						tv.setText(arrTitles[column - 1]);
						// lp.weight = 0;
					}
				}
				row.addView(tv, lp);
			}
			mTable.addView(row);
			// mTable.addView(row, new TableLayout.LayoutParams());

		}
		i_columnSize = 6;
		// addColumn();
	}

	private void addColumn() {
		TableRow row;
		for (int rowIndex = 0; rowIndex < 3; rowIndex++) {
			row = (TableRow) mTable.getChildAt(rowIndex);
			TextView tv = buildTextView(0);
			if (rowIndex == 0) {
				tv.setText(arrTitles[TITLE_TOTAL_INDEX]);
				tv.setTextColor(colorTitle);
				((TextView) row.getChildAt(i_columnSize - 1))
						.setText(arrTitles[i_columnSize - 2]);
			} else
				tv.setTextColor(Color.WHITE);
			TableRow.LayoutParams lp = new TableRow.LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			lp.weight = 1;
			lp.setMargins(0, 0, 1, 1);
			row.addView(tv, lp);
		}
		i_columnSize++;
	}

	int colorTitle;

	/**
	 * @param type
	 *            0 ��ʾ���� 1��ʾ����
	 * */
	private TextView buildTextView(int type) {
		TextView tv = new TextView(mAct);
		tv.setBackgroundResource(R.drawable.shape_gray);
		if (type == 0) {
			if (colorTitle == 0)
				colorTitle = getActivity().getResources().getColor(
						R.color.table_title);
			tv.setTextColor(colorTitle);
		} else
			tv.setTextColor(Color.WHITE);
		tv.setGravity(Gravity.CENTER_HORIZONTAL);

		return tv;
	}

	private TextView getTextView(int row, int column) {
		return (TextView) ((TableRow) mTable.getChildAt(row))
				.getChildAt(column);
	}

	public void showNextPage() {
		mDataListAdapter.nextPage();
	}

	public void showPrePage() {
		mDataListAdapter.prePage();
	}
}
