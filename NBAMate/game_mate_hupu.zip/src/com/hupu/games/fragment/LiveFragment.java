package com.hupu.games.fragment;

import java.util.ArrayList;
import java.util.LinkedList;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.hupu.games.R;
import com.hupu.games.activity.HupuDataActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.LiveDataListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.LiveEntity;
import com.hupu.games.data.LiveResp;
import com.hupu.games.view.XListView;
import com.hupu.games.view.XListView.IXListViewListener;
import com.umeng.analytics.MobclickAgent;
import com.umeng.common.Log;

@SuppressLint("ValidFragment")
public class LiveFragment extends BaseFragment {

	private XListView mLvLive;

	private LiveDataListAdapter mListAdapter;

	private int i_homeId;
	private int i_awayId;

	private View mProgressBar;

	private ArrayList<LiveEntity> mListMsg;

	HupuDataActivity mAct;

	View nodata;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mListAdapter = new LiveDataListAdapter(getActivity(), i_homeId,
				i_awayId, new Click());
		mAct = (HupuDataActivity) getActivity();
	}

	@SuppressLint("ValidFragment")
	public LiveFragment(int h, int a) {
		super();
		i_homeId = h;
		i_awayId = a;
	}

	public LiveFragment() {
		super();
		bQuit = true;
	}

	boolean start;
	/**�����Ƿ�ʼ��*/
	public void isStart(boolean s)
	{
		start =s;
		if(start && nodata!=null)
			nodata.setVisibility(View.GONE);
	}
	@Override
	public void onSaveInstanceState(Bundle outState) {
		// outState.putSerializable("data", mListMsg);

		super.onSaveInstanceState(outState);
		setUserVisibleHint(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// if(savedInstanceState!=null)
		// {
		// if(mListMsg== null )
		// mListMsg=(ArrayList<LiveEntity>
		// )savedInstanceState.getSerializable("data");
		// }
		View v = inflater.inflate(R.layout.fragment_live, container, false);
		mProgressBar = v.findViewById(R.id.probar);
		nodata=v.findViewById(R.id.txt_no_data);
		mLvLive = (XListView) v.findViewById(R.id.list_live);
		
		mLvLive.setXListViewListener(new pullListener());
		mLvLive.setPullLoadEnable(false,false);
		mLvLive.setAdapter(mListAdapter);
		
		if (mListMsg != null || bGetData) {
			mListAdapter.setData(mListMsg);
		}

		if ( (bGetData && mProgressBar != null) || !start)
			mProgressBar.setVisibility(View.GONE);
		if(start)
			nodata.setVisibility(View.GONE);
		return v;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
	}

	public void setData(ArrayList<LiveEntity> gameList) {
		bGetData = true;
		if (mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
		mListMsg = gameList;
		if (mListAdapter != null) {
			mListAdapter.setData(gameList);
		}

	}

	/** ���ӵ��б�β�� */
	public void appendData(ArrayList<LiveEntity> gameList) {
		if (mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
		if (mListAdapter != null)
			mListMsg = mListAdapter.appendData(gameList);
	}

	/** ���ӵ��б�ͷ�� */
	public void addData(ArrayList<LiveEntity> gameList) {
		if (mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
		if (mListAdapter != null)
			mListMsg = mListAdapter.addDataToHead(gameList);

	}

	boolean bGetData;

	public void addData(boolean b) {
		bGetData = b;
		if (bGetData && mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
	}

	public void updateData(LiveResp data) {

		bGetData = true;
		if (mProgressBar != null)
			mProgressBar.setVisibility(View.GONE);
		if (data.mListDel == null && data.mListAdd == null) {
			// addData(data.dataList );
			return;
		}
		int delSize = data.mListDel.size();
		int addSize = data.mListAdd.size();
		int rowSize = delSize > addSize ? delSize : addSize;

		int colunmSize = 0;
		int[] indexArr;
		if (rowSize > 0) {
			LinkedList<LiveEntity> entityList;
			if (mListMsg == null)
				mListMsg = new ArrayList<LiveEntity>();
			for (int i = 0; i < rowSize; i++) {
				if (i < delSize) {
					indexArr = data.mListDel.get(i);
					colunmSize = indexArr.length;
					// ɾ��
					for (int j = colunmSize - 1; j > -1; j--) {
						mListMsg.remove(indexArr[j]);
					}
				}
				if (i < addSize) {
					// ����
					indexArr = data.mListAdd.get(i);
					entityList = data.mListMsg.get(i);
					colunmSize = indexArr.length;
					int msgSize = 0;
					for (int j = 0; j < colunmSize; j++) {
						msgSize = mListMsg.size();
						if (indexArr[j] > msgSize)
							mListMsg.add(entityList.get(j));
						else
							mListMsg.add(indexArr[j], entityList.get(j));
					}
				}
			}
			mListAdapter.setData(mListMsg);
		}

	}

	private void refresh() {
		if (mListAdapter != null && mListAdapter.getCount() > 0)
			mAct.reqFresh();
		else
			stopLoad();
	}

	public void stopLoad() {
		if (mLvLive != null)
			mLvLive.stopRefresh();
	}

	class pullListener implements IXListViewListener {

		Handler handler=new Handler();
		@Override
		public void onRefresh() {
			handler.postDelayed(new Runnable() {				
				@Override
				public void run() {
					refresh();
				}
			}, 800);		
		}

		@Override
		public void onLoadMore() {

		}
	}

	Dialog mImgDialog;
	WebView webview;
	Handler mImgHandler;

	View progress;
	public void showImgDialog(final String url) {
		if (url == null)
			return;
		if (mImgHandler == null)
			mImgHandler = new Handler();

		if(mImgDialog!=null && mImgDialog.isShowing())
		{
			mImgDialog.dismiss();
		}
		View v = LayoutInflater.from(getActivity()).inflate(
				R.layout.dialog_img, null);
		progress = v.findViewById(R.id.probar);

		v.findViewById(R.id.mask).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mImgDialog.cancel();
			}
		});
		// gifView = (GifView) v.findViewById(R.id.btn_close);
		// gifView.setGifImageType(GifImageType.WAIT_FINISH);

		webview = (WebView) v.findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webview.setBackgroundColor(Color.argb(0, 0, 0, 0));
		webview.setVisibility(View.INVISIBLE);
		webview.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				super.onProgressChanged(view, newProgress);
				if (newProgress >= 100)
				{
					progress.setVisibility(View.GONE);
					webview.setVisibility(View.VISIBLE);
				}		
			}

		});
		mImgHandler.postDelayed(new Runnable() {
			
			@Override
			public void run() {
				webview.loadDataWithBaseURL(null, String.format(IMG_URL, url),
						"text/html", "utf-8", null);
			}
		}, 300);
	

		mImgDialog = new Dialog(getActivity(), R.style.MyWebDialog) ;
		mImgDialog.setContentView(v);
		// mImgDialog.setCanceledOnTouchOutside(true);
		// mImgDialog.setCancelable(true);
		mImgDialog.getWindow().setGravity(Gravity.CENTER);
		mImgDialog.show();
		mImgDialog.getWindow().setLayout(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);

	}

	class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			if (v instanceof TextView) {
				String url = (String) v.getTag();
				if (url != null) {
					Intent in = new Intent(getActivity(), WebViewActivity.class);
					in.putExtra("url", url);
					startActivity(in);
				}
				MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_GAME_PLAY,
						HuPuRes.UMENG_KEY_BROWSER);
				
			} else if (v instanceof ImageView) {

				String url = (String) v.getTag();
				showImgDialog(url);
			}

		}

	}

	public final static String IMG_URL = 
			"<div style=\"display:table\" id=\"JPicWrap\">"
			+ "<div style=\"display:table-cell;text-align:center;vertical-align:middle;horizontal-align:middle\">"
			+ "<img src=\"%s\" alt=\"\">"
			+ "</div>"
			+ "</div>"
			+ "<script type=\"text/javascript\">"
			+ "window.onload = function(){"
			+ "clientH = document.documentElement.clientHeight||document.body.clientHeight;"
			+ "document.getElementById('JPicWrap').style.height = clientH+'px';"
			+ "clientW = document.documentElement.clientWidth||document.body.clientWidth;"
			+ "document.getElementById('JPicWrap').style.width = clientW+'px';"
			+ "}" + "</script>";

	public class ImagePreviewDialog extends Dialog {
		private ImageView mImageView;

		public ImagePreviewDialog(Context context, int theme) {
			super(context, theme);
			Window win = getWindow();
			WindowManager.LayoutParams wAttrs = win.getAttributes();
			win.setFlags(0, WindowManager.LayoutParams.FLAG_DIM_BEHIND);
			win.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
			setCanceledOnTouchOutside(true);
		}

		@Override
		protected void onCreate(Bundle savedInstanceState) {
			Context ctxt = getContext();
			mImageView = new ImageView(ctxt);
			mImageView.setLayoutParams(new LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
			setContentView(mImageView);
		}

	}

}
