package com.hupu.games.fragment;

import java.util.HashMap;
import java.util.LinkedList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

import com.hupu.games.R;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.NewsDetailActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.NewsListAdapter;
import com.hupu.games.adapter.StandingsListAdapter;
import com.hupu.games.adapter.VideoListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.NewsEntity;
import com.hupu.games.data.StandingsResp;
import com.hupu.games.data.VideoEntity;
import com.hupu.games.data.NewsResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.view.RefreshListView;
import com.hupu.games.view.RefreshListView.RefreshListener;
import com.hupu.games.view.XListView;
import com.hupu.games.view.XListView.IXListViewListener;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

@SuppressLint("ValidFragment")
public class NewsFragment extends BaseFragment {

	private XListView mListNews;

	private NewsListAdapter mNewsAdapter;

	private LinkedList<NewsEntity> mNewsData;

	private long lastNewsId;

	/** ���ˢ�µ�ʱ�� */
	private long mLastNewsTime;

	/***/
	private static final long TEN_MINS = 600000;
	/***/
	boolean bNeedFresh;

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	int type;

	private int methodNews;

	private int methodNewsNext;

	public NewsFragment() {
		methodNews = HuPuRes.REQ_METHOD_GET_NBA_NEWS;
		methodNewsNext = HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT;
		ukey = HuPuRes.UMENG_KEY_NBA_NEWS;
	}

	public NewsFragment(int t) {
		type = t;
		if (type == 0) {
			methodNews = HuPuRes.REQ_METHOD_GET_NBA_NEWS;
			methodNewsNext = HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT;
			ukey = HuPuRes.UMENG_KEY_NBA_NEWS;
		} else {
			methodNews = HuPuRes.REQ_METHOD_GET_CBA_NEWS;
			methodNewsNext = HuPuRes.REQ_METHOD_GET_CBA_NEWS_NEXT;
			ukey = HuPuRes.UMENG_KEY_CBA_NEWS;
		}

	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.fragment_news, container, false);

		mListNews = (XListView) v.findViewById(R.id.list_news);

		if (mNewsAdapter == null) {
			mNewsAdapter = new NewsListAdapter(getActivity());
		}

		ListClick listClick = new ListClick();
		mListNews.setOnItemClickListener(listClick);
		mListNews.setXListViewListener(new pullListener());
		mListNews.setAdapter(mNewsAdapter);
		// ��ʼ��ʱ����Ҫˢ��
		mListNews.setPullLoadEnable(false, false);
		if (bFirstCreate) {
			bFirstCreate = false;
			reqNewData(false);
		}
		return v;
	}

	@Override
	public void onResume() {
		super.onResume();

	}

	/** ��ȡ�������� */
	public void reqNewData(boolean isMan) {

		if (!isMan)
			mListNews.setFreshState();
		reqNewsData(methodNews, 0);
	}

	int page;

	/** ��ȡ�������� */
	public void reqMoreData() {
		UMENG_MAP.clear();

		UMENG_MAP.put(HuPuRes.UMENG_LOAD_MORE, "" + page++);
		MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);
		reqNewsData(methodNewsNext, lastNewsId);
	}

	/** ������������ */
	private void reqNewsData(int reqId, long nId) {
		mParams = mAct.getHttpParams(true);
		if (nId > 0)
			mParams.put("nid", "" + nId);
		switch (reqId) {
		case HuPuRes.REQ_METHOD_GET_NBA_NEWS_NEXT:
			mParams.put("direc", "next");
			break;
		}
		mAct.sendRequest(reqId, mParams);
	}

	/**
	 * ��������ҳ���л�����
	 * */
	public void entry() {
		if (mAct == null)
			bFirstCreate = true;
		else {
			long curTime = System.currentTimeMillis();
			if (mLastNewsTime == 0 || curTime - mLastNewsTime > TEN_MINS) {
				bNeedFresh = true;
			}
			if (bNeedFresh) {
				reqNewData(false);
			}
		}
	}

	/**
	 * ��ֵ��ˢ��
	 * */
	public void setData(int method, Object o) {

		NewsResp resp = (NewsResp) o;
		// Log.d("data size=", ""+resp.mList.size());

		if (resp.nextDataExists > 20)
			mListNews.setPullLoadEnable(true, false);
		else {
			mListNews.setPullLoadEnable(false, true);
			mAct.showToast("û�и���������");
		}

		if (method == methodNewsNext) {
			if (mNewsData == null)
				method = methodNews;
		} else {
			mLastNewsTime = System.currentTimeMillis();
			bNeedFresh = false;
		}

		if (method == methodNewsNext) {
			// mNewsData.addAll(0, resp.mList);
			mNewsData.addAll(resp.mList);
		} else {
			mNewsData = resp.mList;
			page = 0;
		}

		lastNewsId = resp.lastNId;
		mNewsAdapter.setData(mNewsData);
	}

	/** ֹͣ���ض��� */
	public void stopLoad(boolean bDelay) {
		// Log.d("video", "stopLoad");
		mListNews.stopRefresh();
		mListNews.stopLoadMore();
	}

	/** ����listview �����������ļ��� */
	class pullListener implements IXListViewListener {

		@Override
		public void onRefresh() {
			reqNewData(true);
		}

		@Override
		public void onLoadMore() {
			reqMoreData();
		}

	}

	String ukey;

	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
			if (pos < 1)
				return;
			UMENG_MAP.clear();

			UMENG_MAP.put(ukey, HuPuRes.UMENG_OPEN);
			MobclickAgent.onEvent(mAct, ukey, UMENG_MAP);

			Intent in = new Intent(getActivity(), NewsDetailActivity.class);
			in.putExtra("nid", mNewsAdapter.getItem(pos - 1).nid);
			in.putExtra("reply", mNewsAdapter.getItem(pos - 1).replies);
			in.putExtra("type", type);
			startActivity(in);
		}

	}
}
