package com.hupu.games.fragment;

import java.util.HashMap;
import java.util.LinkedList;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.hupu.games.R;
import com.hupu.games.activity.CBAGameActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.CBAGamesListAdapter;
import com.hupu.games.adapter.GamePagerAdapter;
import com.hupu.games.adapter.GamesListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.CBAData;
import com.hupu.games.data.CBAResp;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.hupu.games.handler.HupuHttpHandler;
import com.hupu.games.view.PinnedHeaderListView;

public class CBAGameFragment extends BaseFragment {

	private CBAGamesListAdapter mListAdapter;

	private PinnedHeaderListView mLvGames;

	private View mProgressBar;

	LinkedList<String> mListRounds;
	/** keyΪ������valueΪ���ֵ����� */
	private HashMap<String, CBAResp> mMaps;

	/** ��ǰ������ */
	private int curRound;
	private int nextRound;
	private int preRound;
	
	private Button mBtnNext;
	private Button mBtnPrev;
	
	
	
	private TextView mTxtRound;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mMaps =new HashMap<String, CBAResp>();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.fragment_cba, container, false);

		Click  click=new Click ();
		mBtnNext =(Button)v.findViewById(R.id.btn_cba_next);
		mBtnPrev=(Button)v.findViewById(R.id.btn_cba_pre);
		mTxtRound =(TextView)v.findViewById(R.id.txt_round);
		
		mBtnNext.setOnClickListener(click);
		mBtnPrev.setOnClickListener(click);
		
		mLvGames = (PinnedHeaderListView) v.findViewById(R.id.list_cba_games);
		mProgressBar = v.findViewById(R.id.probar);
		
		if(mListAdapter ==null)
			mListAdapter = new CBAGamesListAdapter(getActivity());
		else
		{
			CBAResp resp =mMaps.get(""+curRound);
			if(resp!=null)
			{
				setData(resp);
			}
			else
			{
				reqCBA(HuPuRes.REQ_METHOD_CBA_NEXT,0);	
			}
		}
		mLvGames.setAdapter(mListAdapter);
		mLvGames.setOnItemClickListener(new ListClick());
		
		if (bFirstCreate) {
			bFirstCreate = false;
			reqCBA(HuPuRes.REQ_METHOD_CBA_NEXT,0);	
		}
		
		return v;
	}


	public void setData(CBAResp en) {
		if (mProgressBar != null) {
			mProgressBar.setVisibility(View.GONE);
		}

		if (en != null) {
			curRound = en.curRound;
			preRound =en.prevRound;
			nextRound=en.nextRound;

			if(preRound==0)
			{
				mBtnPrev.setEnabled(false);
				mBtnPrev.setText("");
			}
			else
			{
				mBtnPrev.setEnabled(true);
//				mBtnPrev.setText(R.string.str_pre_round);
				mBtnPrev.setText(en.prevTitle);
			}
			
			
			if(nextRound==0)
			{
				mBtnNext.setEnabled(false);
				mBtnNext.setText("");
			}
			else
			{
				mBtnNext.setEnabled(true);
//				mBtnNext.setText(R.string.str_next_round);
				mBtnNext.setText(en.nextTitle);
			}
			
			mTxtRound.setText(en.curTitle);
			mListAdapter.setData(en);
			mLvGames.setSelection(0);
			mMaps.put(""+curRound, en);
		}
	}

	private void prev() {
		
		if( preRound>0)
		{
			if(mMaps!=null  )
			{
				CBAResp resp =mMaps.get(""+preRound);
				if(resp!=null)
				{
					setData(resp);
					return;
				}
			}
			reqCBA(HuPuRes.REQ_METHOD_CBA_PREV,preRound);
		}
	}

	private void next() {
		if( nextRound>0)
		{
			if(mMaps!=null  )
			{
				CBAResp resp =mMaps.get(""+nextRound);
				if(resp!=null)
				{
					setData(resp);
					return;
				}
			}
			reqCBA(HuPuRes.REQ_METHOD_CBA_NEXT,nextRound);
		}
	}

	public void entry()
	{
		if(mAct == null )
		{
			bFirstCreate =true;
			
		}
		else if(curRound==0)
		{
			reqCBA(HuPuRes.REQ_METHOD_CBA_NEXT,0);			
		}		
	}
	
	private void reqCBA(int method ,int round)
	{
		mParams =mAct.getHttpParams(true);
		if(round>0)
			mParams.put("round", ""+round);
		mAct.sendRequest(method, mParams);
	}
	
	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {

//			Log.d("ListClick", "pos="+pos);
			CBAData data =mListAdapter.getItemAt(pos);
			if(data !=null)
			{
				Intent in =new Intent(getActivity(),CBAGameActivity.class);
				in.putExtra("data", data);
				startActivity(in);
			}
		}

	}

	class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			if (id == R.id.btn_cba_next) {
				next();
			} else {
				prev();
			}

		}

	}

}
