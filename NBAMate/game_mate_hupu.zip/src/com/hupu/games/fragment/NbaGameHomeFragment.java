package com.hupu.games.fragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.crypto.Mac;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;

import com.hupu.games.R;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.adapter.GamePagerAdapter;
import com.hupu.games.adapter.NBAGamePagerAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.BaseEntity;
import com.hupu.games.data.GameEntity;
import com.hupu.games.data.GamesResp;
import com.pyj.common.MyUtility;
import com.pyj.http.RequestParams;
import com.umeng.analytics.MobclickAgent;
import com.viewpagerindicator.TitlePageIndicator;

public class NbaGameHomeFragment extends Fragment {

	private ViewPager mPager;

	public NBAGamePagerAdapter mPageAdapter;

	private TitlePageIndicator mIndicator;

	/** �Ƿ����ɳ������õ���ת���ɳ������õ���ת�������������� */
	private boolean isByMan;

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	/** ��ǰ�����ڼ�ҳ */
	private int mCurIndex;

	private boolean bHasNext = true;
	private boolean bHasPre = true;

	private HupuSlidingActivity mAct;
	public static SimpleDateFormat sdf = new java.text.SimpleDateFormat(
			"yyyy-MM-dd", java.util.Locale.CHINESE);

	private long l_today;
	
	private GamesResp mEntity;

	RequestParams mParams;

	/** ��ǰ����ı��������� */
	private long l_curDay;

	/** ����ı����б��Ķ��У���Ҫ�������ظ�����ͬһ��ı��� */
	private ArrayList<String> mListReqQue;

	/** �����ǲ��Ǳ����� */
	private boolean bMatchDay;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mAct = (HupuSlidingActivity) getActivity();
		mListReqQue = new ArrayList<String>();
		if(l_curDay == 0)
			req(0, 0);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.fragment_nba_games, container, false);
		mPager = (ViewPager) v.findViewById(R.id.pager_games);
		mIndicator = (TitlePageIndicator) v.findViewById(R.id.indicator_games);
		if (mPageAdapter == null) {
			mPageAdapter = new NBAGamePagerAdapter(mAct ,new Click());
			mIndicator.setOnPageChangeListener(new PageChange());
		}
		mPager.setAdapter(mPageAdapter);
		if (mEntity != null)
			setInitData();
		return v;
	}

    public void entry()
    {
    	
    }

	private void setInitData() {
		mPageAdapter.setToday(l_today);
		mPageAdapter.setDay(mEntity.l_game_day);
		mPageAdapter.setPreDate(mEntity.preList);
		mPageAdapter.setNextDate(mEntity.nextList);
		mPageAdapter.setFragmentData(mEntity.l_game_day, mEntity, false);
		isByMan = true;
		mIndicator.setViewPager(mPager, mPageAdapter.INITSIZE);
	}

	public void setData(int methodId, GamesResp entity) {

		if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER) {
			if (bMatchDay = entity.isMatchDay) {
				mAct.joinRoom();// ����Ǳ����գ���ʼsocket����
				if (entity.mGameList.size() > 0
						&& entity.mGameList.get(0).byt_status == 2)
					mAct.setScreenLight(true);
				else
					mAct.setScreenLight(false);
			}
		} else {
			if (entity.mGameList != null) {
				mListReqQue
						.remove("" + entity.mGameList.get(0).l_date_time);
			}
		}
		
		
		if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER) {
			if (entity != null && entity.mGameList != null) {
				l_today = entity.l_server_day;
				mEntity = entity;
				if (mPageAdapter != null)
					setInitData();
			}
		} else {

			if (entity.mGameList == null)
				return;
			if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT) {
				int retSize = entity.nextList.size();
				if (retSize < 2)
					bHasNext = false;
				else
					mPageAdapter.setNextDate(entity.nextList
							.subList(1, retSize));
			} else if (methodId == HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE) {
				int retSize = entity.preList.size();
				if (retSize < 2)
					bHasPre = false;
				else {
					isByMan = true;
					mPageAdapter.setPreDate(entity.preList.subList(0,
							retSize - 2));
				}
			}
			mPageAdapter.setFragmentData(entity.mGameList.get(0).l_date_time,
					entity, false);
		}
	}

	public void setData(long date, GamesResp entity, boolean keep) {
		
		mPageAdapter.setFragmentData(entity.l_game_day, entity, true);
	}

	
	
	
	class PageChange extends ViewPager.SimpleOnPageChangeListener {

		@Override
		public void onPageSelected(int pos) {
			if (isByMan)// ����Ѿ����˹����õ���ת����Ҫ������������
			{
				isByMan = false;
				return;
			}
			long date = mPageAdapter.getDate(pos);
			if (date == -1) {
				if (!bHasNext) {
					mAct.showToast("������ʱû�б�����");
					mPager.setCurrentItem(pos - 1);
				}
				return;
			}
			UMENG_MAP.put("date", MyUtility.getStartTime(
					mPageAdapter.getDate(pos) * 1000, sdf));
			if (pos > mCurIndex) {
				// ����
				MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_SWIPE_RIGHT,
						UMENG_MAP);
			} else {
				// ����
				MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_SWIPE_LEFT,
						UMENG_MAP);
			}
			mCurIndex = pos;
			if (!mPageAdapter.hasData(pos)) {

				if (mPageAdapter.getHeadNum(mCurIndex) == 2 && bHasNext)
					req(date, 1);
				else if (mPageAdapter.getTailNum(mCurIndex) == 2 && bHasPre)
					req(date, -1);
				else
					// System.out.print("onPageSelected  date ="+mPageAdapter.getDate(pos));
					req(date, 0);
			}
		}
	}


	public void updateFollow(long date, int gameId, int follow) {
		mPageAdapter.updateFollow(date, gameId, follow);
	}

	/**
	 * ����http�����б�����
	 * */
	public void req(long date, int direct) {
	
		if (mListReqQue.contains(date + ""))
			return;
		int reqType;
		mParams =mAct.getHttpParams(true);
		// ����ʱ����Ϣ��ȡ���һ�����Ϣ
		if (date > 0) {
			l_curDay = date;
			mParams.put(BaseEntity.KEY_DATE, "" + date);
			if (direct > 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_NEXT);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_NEXT;
			} else if (direct < 0) {
				mParams.put(BaseEntity.KEY_DIREC, BaseEntity.KEY_PREV);
				reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_PRE;
			} else
				reqType = HuPuRes.REQ_METHOD_GAMES_BY_DATE;
		} else
			reqType = HuPuRes.REQ_METHOD_NBA_GAMES_BY_SERVER;

		if (mAct.sendRequest(reqType, mParams))
			mListReqQue.add(date + "");
		else
			mListReqQue.clear();
	}
	
	class Click implements OnClickListener {

		@Override
		public void onClick(View v) {
			int pos = (Integer) v.getTag();
//			GameEntity entity = mListAdapter.getItem(pos);
//			entity.i_isFollow = entity.i_isFollow > 0 ? 0 : 1;
//			mListAdapter.notifyDataSetChanged();
//			((TabIndexActivity) getActivity()).setFollowGame(entity);
		}
	}
}
