package com.hupu.games.fragment;

import java.util.HashMap;
import java.util.LinkedList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.hupu.games.R;
import com.hupu.games.activity.HupuBaseActivity;
import com.hupu.games.activity.HupuDataActivity;
import com.hupu.games.activity.WebViewActivity;
import com.hupu.games.adapter.ChatListAdapter;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.data.ChatEntity;
import com.hupu.games.data.ChatResp;
import com.hupu.games.data.SingleCBAData;
import com.hupu.games.fragment.VideoFragment.ListClick;
import com.hupu.games.view.XListView;
import com.hupu.games.view.XListView.IXListViewListener;
import com.umeng.analytics.MobclickAgent;

public class ChatFragment extends BaseFragment {

	// private View mProgressBar;

	HupuDataActivity mAct;

	LinkedList<ChatEntity> mDataList;

	ChatListAdapter mAdapter;

	/***/
	private int oldChatID;
	/***/
	private int newChatID;

	private XListView mListViewChat;

	private HashMap<String, String> UMENG_MAP = new HashMap<String, String>();

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.fragment_chat, container, false);
		mListViewChat = (XListView) v.findViewById(R.id.list_chat);
		hint = v.findViewById(R.id.hint_layout);
		mAct = (HupuDataActivity) getActivity();
		// mProgressBar = v.findViewById(R.id.probar);
		mDataList = new LinkedList<ChatEntity>();
		mAdapter = new ChatListAdapter(getActivity());
		mListViewChat.setAdapter(mAdapter);
		ListClick listClick = new ListClick();
		mListViewChat.setOnItemClickListener(listClick);
		mListViewChat.setXListViewListener(new pullListener());
		mListViewChat.setPullLoadEnable(false,false);
		return v;
	}

	boolean isFirst = true;
	View hint;

	/** ����ˢ������ */
	public void setData(ChatResp data) {

		// mProgressBar.setVisibility(View.GONE);

		// ����Ϣ���ص�����£���Ҫ���ж���������Ϣ������ˢ����Ϣ�����Ǽ��ظ������Ϣ
		if (data.pid_old == 0) {
			// ˢ��
			// �趨ƫ����
			mDataList = data.mList;
			newChatID = data.pid;
			oldChatID = data.pid - mDataList.size();
//			Log.d("setData", "newChatID=" + newChatID + " oldChatID= "
//					+ oldChatID +" szie"+mDataList.size());
			if (mDataList.size() < 20 || oldChatID <2)
			{
				mListViewChat.setPullLoadEnable(false,true);
			}
			else
				mListViewChat.setPullLoadEnable(true,false);

		} else {
			if (data.direc.equals("next")) {
				// ���͹���������
				newChatID = data.pid;
				mDataList.addAll(0, data.mList);
			} else {
				// ���ظ���
				oldChatID = data.pid - data.mList.size();
				mDataList.addAll(data.mList);
				if (oldChatID < 2)
					mListViewChat.setPullLoadEnable(false,true);
				// mAct.showToast("û�и��������¼��");
//				Log.d("setData", "load more  oldChatID= "
//						+ oldChatID);
			}
		}
		if (mDataList == null || mDataList.size() == 0)
			hint.setVisibility(View.VISIBLE);
		else
			hint.setVisibility(View.GONE);
		mAdapter.setData(mDataList);
		page = 0;
	}

	public int getLastId() {
		return newChatID;
	}

	public void setLastId(int id) {
		newChatID = id;
	}

	/** �����ݼ��� */
	public void addData(ChatResp data) {
		mAdapter.setData(mDataList);
	}

	/** �����ݼ��� */
	public void addData(String name, String content) {

		ChatEntity entity = new ChatEntity();
		//entity.username = "�ο�-" + name;
		entity.username = name;
		entity.content = content;
		mDataList.add(0, entity);
		mAdapter.notifyDataSetChanged();
		if(hint!=null)
			hint.setVisibility(View.GONE);
		// mListViewChat.setSelectionAfterHeaderView() ;
		// mListViewChat.invalidate();
	}

	/** ����������� */
	public void clearData() {
		mDataList.clear();
		mAdapter.setData(mDataList);
	}

	/** ��ȡ�������� */
	public void reqNewData() {
		if (mDataList == null)
			mListViewChat.setPullLoadEnable(false,false);
		
		mAct.reqChatData(0);
	
	}

	Handler handler = new Handler();

	/** ��ȡ�������� */
	public void reqNewDataDelay(boolean isMan) {
		if (mDataList == null)
			mListViewChat.setPullLoadEnable(false,false);
		if (!isMan) {
			mListViewChat.setFreshState();
		}
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				mAct.reqChatData(0);
			}
		}, 800);
	}

	int page;

	/** ��ȡ�������� */
	public void reqMoreData() {
//		Log.d("reqMoreData", "oldChatID=" + oldChatID);
		UMENG_MAP.clear();
		UMENG_MAP.put(HuPuRes.UMENG_LOAD_MORE, "" + page++);
		MobclickAgent.onEvent(mAct, HuPuRes.UMENG_KEY_NBA_CHAT, UMENG_MAP);
		mAct.reqChatData(oldChatID);
	}

	/** ����listview �����������ļ��� */
	class pullListener implements IXListViewListener {

		@Override
		public void onRefresh() {
			reqNewDataDelay(true);
		}

		@Override
		public void onLoadMore() {
			reqMoreData();
		}

	}

	/** ����listview��������� */
	class ListClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
			// if(pos<1)
			// return;
			// Intent in =new Intent(getActivity(),WebViewActivity.class);
			// in.putExtra("url", mAdapter.getItem(pos-1).fromurl);
			// startActivity(in);
		}

	}

	public void stopLoad() {
		if (mListViewChat != null) {
			mListViewChat.stopRefresh();
			mListViewChat.stopLoadMore();
		}
	}
}
