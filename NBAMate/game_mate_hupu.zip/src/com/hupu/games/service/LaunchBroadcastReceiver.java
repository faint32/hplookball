package com.hupu.games.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.hupu.games.common.HuPuRes;
import com.hupu.games.common.SharedPreferencesMgr;

public class LaunchBroadcastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
//		Log.d("LaunchBroadcastReceiver", "action===" + intent.getAction());
		SharedPreferencesMgr.init(context, "hupugamemate");
		if(SharedPreferencesMgr.getBoolean("notify", true))
		{
			startLater(context);
		}
//		else
//			Log.d("LaunchBroadcastReceiver", "no notify");

	}

	/** ��ʱ���� */
	private void startLater(Context context) {
//		Log.d("LaunchBroadcastReceiver", "startLater   >>>>>>:::::"
//				+ android.os.Process.myPid());
		AlarmManager am = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(context, HuPuGamemateService.class);
		intent.putExtra("startCon", true);
		PendingIntent pendingIntent = PendingIntent.getService(context, 0,
				intent, 0);
		long interval = 60000; // 1����
		long firstWake = System.currentTimeMillis() + interval;
		am.set(AlarmManager.RTC_WAKEUP, firstWake, pendingIntent);
	}

}
