package com.hupu.games.service;

import io.socket.SocketIO;
import io.socket.SocketIOException;
import io.socket.SocketIoHandler;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CallLog.Calls;
import android.util.Log;

import com.hupu.games.R;
import com.hupu.games.activity.HupuSlidingActivity;
import com.hupu.games.activity.TabIndexActivity;
import com.hupu.games.common.HuPuRes;
import com.hupu.games.common.SharedPreferencesMgr;
import com.hupu.games.data.AdressEntity;
import com.hupu.games.data.JsonPaserFactory;
import com.hupu.games.data.NotificationEntity;
import com.hupu.games.handler.ISocketCallBack;
import com.pyj.common.DeviceInfo;
import com.pyj.http.AsyncHttpClient;
import com.pyj.http.AsyncHttpResponseHandler;
import com.umeng.analytics.MobclickAgent;

public class HuPuGamemateService extends Service implements ISocketCallBack,
		UncaughtExceptionHandler {

	private SocketIoHandler mSocketHandler;
	
	private SocketIO socketClient;

	Handler handler;
	/** �����ļ�� */
	private final int RECON_INTEVAL = 30000;
	private String s1;
	private String s2;

	private static int err_count;
	/**���Ĵ������*/
	private static final int MAX_ERR_TIMES = 5;
	
	private static String curServer;
	private boolean callStopConn;
	private boolean callStopService;
	
	long restart_interval = 180000; // 3����

	@Override
	public void onCreate() {
//		Log.d("HuPuGamemateService", "onCreate"+android.os.Process.myPid());
		super.onCreate();
		handler = new Handler();
		Thread.setDefaultUncaughtExceptionHandler(this);
		SharedPreferencesMgr.init(this, "hupugamemate");
	}



	@Override
	public void onDestroy() {
//		Log.d("HuPuGamemateService", "onDestroy"+android.os.Process.myPid());
		if (callStopService) {
			kill();
		} else {
			restartLater(restart_interval);// ǿ�ƹر�
		}
		super.onDestroy();
	}

	/** ��ʱ���� */
	private void restartLater(long later) {
		cancelAlarm() ;

		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		long firstWake = System.currentTimeMillis() + later;
		am.set(AlarmManager.RTC_WAKEUP, firstWake, getPendingIntent());
	
	}

	private PendingIntent getPendingIntent() {
		Intent intent = new Intent(getApplicationContext(),
				HuPuGamemateService.class);
		if (s1 != null)
			intent.putExtra("server1", s1);
		if (s2 != null)
			intent.putExtra("server2", s2);
		intent.putExtra("startCon", true);
		return PendingIntent.getService(this, 0, intent,  PendingIntent.FLAG_UPDATE_CURRENT);
	}

	private void cancelAlarm() {
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.cancel(getPendingIntent());
	}

	@Override
	public void onStart(Intent intent, int startId) {
//		Log.d("HuPuGamemateService", "onStart"+android.os.Process.myPid());
		super.onStart(intent, startId);
		if (intent!=null  && intent.getBooleanExtra("stop", false)) {
//			callStopConnection();
			callStopService();
			return;
		}
		cancelAlarm();
		HuPuRes.setClient(DeviceInfo.getDeviceInfo(getApplicationContext()));
		boolean bStartCon = intent.getBooleanExtra("startCon", false);
		if (bStartCon) {
			callStopConn = false;
			try {
				// �����㲥��ڽ���
				s1 = intent.getStringExtra("server1");
				s2 = intent.getStringExtra("server2");
				if (s1 == null) {
					s1 = HuPuRes.getDefaultServer();
					s2 = HuPuRes.getBackUpServer();
				}
				if (s1 != null)
					curServer = s1;
			} catch (Exception e) {
				e.printStackTrace();
			}
			initConn();
		}

	}

	/** ���û�з�������ַ���ӷ�����ȥ��ȡ�� */
	private void loadSocketAdd() {
		AsyncHttpClient mHttpClient = new AsyncHttpClient();
		mHttpClient.get(this,
				HuPuRes.getUrl(HuPuRes.REQ_METHOD_REDIRECTOR), null,
				new ServersHandler(), HuPuRes.REQ_METHOD_REDIRECTOR);
	}

	// --------------------------------�������------------------------------------//
	JSONObject obj = new JSONObject();

	/** ��ʼ��socketio������ */
	public void startPush() {
		if (socketClient != null && socketClient.isConnected()) {
			socketClient.emit("setup", obj);
			// socketClient.emit("notific",obj);
		} else
			initConn();
	}

	/** ��ʼ��socketio������ */
	public void initConn() {
//		Log.d("HuPuGamemateService", "initConn");
		if (!DeviceInfo.isNetWorkEnable(this))
		{
			//û����������
			reconnect();
			return;
		}
		if (curServer == null) {
			loadSocketAdd();
			return;
		}
		if (err_count == MAX_ERR_TIMES)
		{
//			curServer = null;
			switchServer();
		}
		try {
			if (socketClient != null && socketClient.isConnected())
			{
				startPush();
				return;
			}
			//����������
			socketClient = new SocketIO(curServer, "true");
			if (mSocketHandler == null)
				mSocketHandler = new SocketIoHandler(this);
			socketClient.connect(mSocketHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void disconnect() {
		if (socketClient != null && socketClient.isConnected())
			socketClient.disconnect();
	}

	@Override
	public void onSocketConnect() {
		err_count = 0;

		// startPush();
	}

	@Override
	public void onSocketDisconnect() {
	
		if (!callStopConn) {
			reconnect();

		}

	}

	private void reconnect() {
		long interval=30000;
		if (DeviceInfo.isNetWorkEnable(this)) {			
				interval = RECON_INTEVAL*(err_count+1);
		} else {
//			restartLater(restart_interval) ;
//			callStopService();
			interval =restart_interval;
		}
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				initConn();// ����
			}
		}, interval);
		
	}

	@Override
	public void onSocketError(SocketIOException socketIOException) {

	
		if (!callStopConn) {
			// ���������Ͽ����ӵ������ ����
			err_count++;
			reconnect();
		}

	}

	/** �л���������ַ */
	private void switchServer() {
		err_count = 0;
		if (curServer != null) {
			if (curServer.equals(s1))
				curServer = s2;
			if (curServer.equals(s2))
				curServer = s1;
		}
	}

	// {"name":"setup","args":[{"countdown":"52319","frequency":"3600"}]}
	/** �������������ʼ���ж�� */
	int countDown;
	/** �´����ӵ�ʱ�� */
	int frequency;

	@Override
	public void onSocketResp(JSONObject obj) {
		if(isAppOnForeground())
		{
			callStopConnection();
			return;
		}
		if (obj != null) {
			try {
				if (obj.has("aps")) {
					// ����
					NotificationEntity entity = new NotificationEntity();
					entity.paser(obj);
					showNotification(entity);
				} else {
					// Ƶ��
					countDown = obj.optInt("countdown");
					frequency = obj.optInt("frequency");
					updateFrequency();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/** ����Ƶ�� */
	private void updateFrequency() {
		if (frequency > 1800) {
//			System.out.println("updateFrequency =====stop");
			restartLater(frequency * 1000);
//			restartLater(10000);
			callStopService();
		}
	}

	/***
	 * ��ʾ����֪ͨ
	 * 
	 */
	private void showNotification(NotificationEntity entity) {

//		 Log.d("test", "notificationId   >>>>>>:::::" + entity.i_id);

		NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Resources resource = getResources();
		Notification notification = new Notification(R.drawable.ic_launcher,
				resource.getString(R.string.app_name),
				System.currentTimeMillis());
		// notification.flags |= Notification.FLAG_ONGOING_EVENT;
		// notification.flags |= Notification.FLAG_NO_CLEAR;

		notification.flags |= Notification.FLAG_SHOW_LIGHTS;
		notification.flags |= Notification.FLAG_AUTO_CANCEL;
		// notification.defaults = Notification.DEFAULT_LIGHTS;
		notification.ledARGB = Color.BLUE;
		notification.ledOnMS = 5000;
		notification.tickerText = entity.strContent;
		if (entity.strSound == null || entity.strSound.equals("")
				|| entity.strSound.equals("0"))
			notification.defaults = Notification.DEFAULT_LIGHTS;
		else
			notification.defaults |= Notification.DEFAULT_SOUND;
		Intent intent = null;
//		Log.d("notificatiion", entity.strUrl);
		if (entity.i_type == 0) {
			intent = new Intent(Intent.ACTION_VIEW, Uri.parse(entity.strUrl));
		} else {
			intent = new Intent(getApplicationContext(),
					HupuSlidingActivity.class);
			intent.putExtra("click", true);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.addFlags(Intent.FILL_IN_DATA);
			intent.addCategory(Intent.CATEGORY_LAUNCHER);
			// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
					| Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
		}

		PendingIntent contentItent = PendingIntent.getActivity(this,
				entity.i_id, intent, 0);
		notification.setLatestEventInfo(this, entity.strTitle,
				entity.strContent, contentItent);

		notificationManager.notify(entity.i_id, notification);
		MobclickAgent.onEvent(this, HuPuRes.UMENG_KEY_NOTIFICATION_SEND);
	}

	private void callStopService()
	{
		callStopService =true;
//		callStopConnection() ;
		stopSelf();
	}
	
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
//		Log.d("HuPuGamemateService",
//				"uncaughtException   >>>>>>:::::" + ex.toString());
		ex.printStackTrace();
		restartLater(restart_interval);
		 kill();
	}

	void kill()
	{

		try {
			Thread.sleep(300);
			int pid = android.os.Process.myPid();
			android.os.Process.killProcess(pid);
			System.exit(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * **/
	class ServersHandler extends AsyncHttpResponseHandler {

		@Override
		public void onFinish() {
			super.onFinish();
		}

		@Override
		public void onSuccess(String content, int reqType) {
			super.onSuccess(content, reqType);
			AdressEntity entity = (AdressEntity) JsonPaserFactory.paserObj(
					content, reqType);
			if (entity != null && entity.mArrAdress != null) {
				s1 = entity.mArrAdress[0];
				SharedPreferencesMgr.setString("default_server",
						entity.mArrAdress[0]);
				if (entity.mArrAdress.length > 1) {
					SharedPreferencesMgr.setString("backup_server",
							entity.mArrAdress[1]);
					s2 = entity.mArrAdress[1];
				}
				if (s1 != null)
					curServer = s1;
				HuPuRes.setServer(entity.mArrAdress[0], entity.mArrAdress[1]);
				initConn();
//				Log.d("ServersHandler", "default_server =" + s1);
			} else
				reconnect();
		}

		@Override
		public void onFailure(Throwable error, String content, int reqType) {
			reconnect();
		}
	}

	
	/**
	 * �����Ƿ���ǰ̨����
	 * 
	 * @return
	 */
	public boolean isAppOnForeground() {
		// Returns a list of application processes that are running on the
		// device

		ActivityManager activityManager = (ActivityManager) getApplicationContext()
				.getSystemService(Context.ACTIVITY_SERVICE);
		String packageName = getApplicationContext().getPackageName();

		List<RunningAppProcessInfo> appProcesses = activityManager
				.getRunningAppProcesses();

		if (appProcesses == null)
			return false;

		for (RunningAppProcessInfo appProcess : appProcesses) {
			// The name of the process that this object is associated with.
			if (appProcess.processName.equals(packageName)
					&& appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
				return true;
			}
		}

		return false;
	}
	
	
	
	
	// ��������ͨ��bindService ����֪ͨ��Serviceʱ�÷���������
	@Override
	public IBinder onBind(Intent intent) {
		serviceBinder = new MyServiceBinder();
		return serviceBinder;
	}

	// ��������ͨ��unbindService����֪ͨ��Serviceʱ�÷���������
	@Override
	public boolean onUnbind(Intent intent) {
//		Log.d("HuPuGamemateService", "onUnbind>>>>>>::::: ");
		serviceBinder = null;
		return super.onUnbind(intent);
	}

	@Override
	public void onRebind(Intent intent) {

		super.onRebind(intent);
	}

	public MyServiceBinder serviceBinder;

	public class MyServiceBinder extends Binder {
		public HuPuGamemateService getService() {
			return HuPuGamemateService.this;
		}
	}

	public void startConnection(String sv1, String sv2) {
//		Log.d("HuPuGamemateService", "startConnection   >>>>>>::::: s1=" + s1);
		callStopConn = false;
		if (sv1 != null) {
			s1 = sv1;
			s1 = sv2;
			curServer = s1;
		}

		HuPuRes.setClient(DeviceInfo.getDeviceInfo(getApplicationContext()));
		initConn();
	}

	public void callStopConnection() {
//		Log.d("HuPuGamemateService", "stopConnection");
		callStopConn = true;
		disconnect();
	}
}
