package com.hupu.games.handler;


import io.socket.SocketIOException;

import org.json.JSONObject;

public interface ISocketCallBack {

	public void onSocketConnect() ;

	public void onSocketDisconnect() ;


	public void onSocketError(SocketIOException socketIOException);
	
	
	public void onSocketResp(JSONObject obj);

}
