package com.hupu.games.handler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.hupu.games.activity.HupuBaseActivity;
import com.hupu.games.data.JsonPaserFactory;
import com.pyj.activity.BaseActivity;
import com.pyj.http.AsyncHttpResponseHandler;
import com.pyj.http.JsonHttpResponseHandler;

public class HupuHttpHandler extends AsyncHttpResponseHandler {

	private BaseActivity a;
	public HupuHttpHandler(BaseActivity act)
	{
		a=act;
	}

	@Override
	public void onFinish() {
		super.onFinish();
	}

	@Override
	public void onSuccess(String content, int reqType) {
		super.onSuccess(content, reqType);
		if(a!=null && !a.isFinishing())
		{
			
			a.onReqResponse(JsonPaserFactory.paserObj(content, reqType), reqType);
		}
	}

	@Override
	public void onFailure(Throwable error, String content, int reqType) {
		super.onFailure(error, content, reqType);
		if(a!=null && !a.isFinishing())
		{
			a.onErrResponse(error, content);
		}
	}


	
}
