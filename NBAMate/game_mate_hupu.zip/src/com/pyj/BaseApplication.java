package com.pyj;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.ArrayList;

import android.app.Activity;
import android.app.Application;
import android.util.Log;

import com.pyj.common.DeviceInfo;

public class BaseApplication extends Application implements UncaughtExceptionHandler{


	private ArrayList<Activity> actList;
	
	static String pakage;
	
	private Thread.UncaughtExceptionHandler mDefaultHandler;
	
	public BaseApplication()
	{
		DeviceInfo.init(this);
		actList =new ArrayList<Activity>();
		mDefaultHandler =Thread.getDefaultUncaughtExceptionHandler(); 
		Thread.setDefaultUncaughtExceptionHandler(this);
		
	}

	public  int getVerCode() {
		int verCode = -1;
		try {
			verCode = getPackageManager().getPackageInfo(
					getPackageName(), 0).versionCode;
			Log.i("GBA", "vercode == " + verCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return verCode;
	}

	public  String getVerName() {
		String verName = "";
		try {
			verName = getPackageManager().getPackageInfo(
					getPackageName(), 0).versionName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return verName;
	}
	
	/**
	 * �˳�
	 * */
	public void quit() {
		// ��������������
		//client.cancelAll();
		// ����ֻ�Ӧ����Ϣ

		int version = android.os.Build.VERSION.SDK_INT;
//		if (version <= 7) {
//			System.out.println("   version  < 7");
//			ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
//			manager.restartPackage(getPackageName());
//		} else {
//            
//		}
		for(Activity act:actList)
		{
			if(!act.isFinishing())
				act.finish();
		}
		actList.clear();
		int pid = android.os.Process.myPid();
		android.os.Process.killProcess(pid);
		System.exit(0);
	}
	public void addActivitToStack(Activity act)
	{
		actList.add(act);
	}
	public void removeFromStack(Activity act)
	{
		actList.remove(act);
	}

	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		ex.printStackTrace();
		Log.e("MyApp===", ""+ex.toString());
		if( ! treatErr( ex)  && mDefaultHandler!=null)
			mDefaultHandler.uncaughtException(thread, ex);
		else
			quit() ;
		
	}
	
	public boolean treatErr(Throwable ex)
	{
		return false;
	}
	
}
