package net.tsz.afinal.common;


import android.os.Build;
/**
 * 鐢ㄤ簬鍒ゆ柇褰撳墠绯荤粺鐨勭増鏈� * @author michael yang
 * 鍦╯dk4.1涓嬬紪璇戞墠鑳介�杩� */
public class Utils {
    private Utils() {};

    public static boolean hasFroyo() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO;
    }

    public static boolean hasGingerbread() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD;
    }

    public static boolean hasHoneycomb() {
        return Build.VERSION.SDK_INT >= 11;
    }

    public static boolean hasHoneycombMR1() {
        return Build.VERSION.SDK_INT >= 12;
    }

    public static boolean hasJellyBean() {
        return Build.VERSION.SDK_INT >= 16;
    }
}
